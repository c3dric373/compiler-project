./ifcc $1
gcc ret42.s
./a.out
echo $?
