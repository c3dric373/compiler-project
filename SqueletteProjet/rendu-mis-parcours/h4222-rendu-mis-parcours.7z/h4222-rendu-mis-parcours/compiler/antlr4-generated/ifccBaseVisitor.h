
// Generated from ifcc.g4 by ANTLR 4.7.2

#pragma once


#include "antlr4-runtime.h"
#include "ifccVisitor.h"


/**
 * This class provides an empty implementation of ifccVisitor, which can be
 * extended to create a visitor which only needs to handle a subset of the available methods.
 */
class  ifccBaseVisitor : public ifccVisitor {
public:

  virtual antlrcpp::Any visitAxiom(ifccParser::AxiomContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitProg(ifccParser::ProgContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitBlocinstr(ifccParser::BlocinstrContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitInstrdecl(ifccParser::InstrdeclContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitInstrdef(ifccParser::InstrdefContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitInstraffct(ifccParser::InstraffctContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitInstrif(ifccParser::InstrifContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitInstrwhile(ifccParser::InstrwhileContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitDeclint(ifccParser::DeclintContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitDefexpr(ifccParser::DefexprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAffexpr(ifccParser::AffexprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitIfbloc(ifccParser::IfblocContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitWhilebloc(ifccParser::WhileblocContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitPar(ifccParser::ParContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAdd(ifccParser::AddContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitMinus(ifccParser::MinusContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitGeat(ifccParser::GeatContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitSub(ifccParser::SubContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitMult(ifccParser::MultContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitConst(ifccParser::ConstContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitEq(ifccParser::EqContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitNot(ifccParser::NotContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitGeq(ifccParser::GeqContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitLow(ifccParser::LowContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitName(ifccParser::NameContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitLeq(ifccParser::LeqContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitNeq(ifccParser::NeqContext *ctx) override {
    return visitChildren(ctx);
  }


};

