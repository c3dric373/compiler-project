
// Generated from ifcc.g4 by ANTLR 4.7.2


#include "ifccVisitor.h"

#include "ifccParser.h"


using namespace antlrcpp;
using namespace antlr4;

ifccParser::ifccParser(TokenStream *input) : Parser(input) {
  _interpreter = new atn::ParserATNSimulator(this, _atn, _decisionToDFA, _sharedContextCache);
}

ifccParser::~ifccParser() {
  delete _interpreter;
}

std::string ifccParser::getGrammarFileName() const {
  return "ifcc.g4";
}

const std::vector<std::string>& ifccParser::getRuleNames() const {
  return _ruleNames;
}

dfa::Vocabulary& ifccParser::getVocabulary() const {
  return _vocabulary;
}


//----------------- AxiomContext ------------------------------------------------------------------

ifccParser::AxiomContext::AxiomContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

ifccParser::ProgContext* ifccParser::AxiomContext::prog() {
  return getRuleContext<ifccParser::ProgContext>(0);
}


size_t ifccParser::AxiomContext::getRuleIndex() const {
  return ifccParser::RuleAxiom;
}

antlrcpp::Any ifccParser::AxiomContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitAxiom(this);
  else
    return visitor->visitChildren(this);
}

ifccParser::AxiomContext* ifccParser::axiom() {
  AxiomContext *_localctx = _tracker.createInstance<AxiomContext>(_ctx, getState());
  enterRule(_localctx, 0, ifccParser::RuleAxiom);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(20);
    prog();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ProgContext ------------------------------------------------------------------

ifccParser::ProgContext::ProgContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* ifccParser::ProgContext::OPENPAR() {
  return getToken(ifccParser::OPENPAR, 0);
}

tree::TerminalNode* ifccParser::ProgContext::CLOSEPAR() {
  return getToken(ifccParser::CLOSEPAR, 0);
}

tree::TerminalNode* ifccParser::ProgContext::OPENBRACE() {
  return getToken(ifccParser::OPENBRACE, 0);
}

ifccParser::BlocContext* ifccParser::ProgContext::bloc() {
  return getRuleContext<ifccParser::BlocContext>(0);
}

tree::TerminalNode* ifccParser::ProgContext::RETURN() {
  return getToken(ifccParser::RETURN, 0);
}

ifccParser::ExprContext* ifccParser::ProgContext::expr() {
  return getRuleContext<ifccParser::ExprContext>(0);
}

tree::TerminalNode* ifccParser::ProgContext::CLOSEBRACE() {
  return getToken(ifccParser::CLOSEBRACE, 0);
}


size_t ifccParser::ProgContext::getRuleIndex() const {
  return ifccParser::RuleProg;
}

antlrcpp::Any ifccParser::ProgContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitProg(this);
  else
    return visitor->visitChildren(this);
}

ifccParser::ProgContext* ifccParser::prog() {
  ProgContext *_localctx = _tracker.createInstance<ProgContext>(_ctx, getState());
  enterRule(_localctx, 2, ifccParser::RuleProg);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(22);
    match(ifccParser::T__0);
    setState(23);
    match(ifccParser::T__1);
    setState(24);
    match(ifccParser::OPENPAR);
    setState(25);
    match(ifccParser::CLOSEPAR);
    setState(26);
    match(ifccParser::OPENBRACE);
    setState(27);
    bloc();
    setState(28);
    match(ifccParser::RETURN);
    setState(29);
    expr(0);
    setState(30);
    match(ifccParser::T__2);
    setState(31);
    match(ifccParser::CLOSEBRACE);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- BlocContext ------------------------------------------------------------------

ifccParser::BlocContext::BlocContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t ifccParser::BlocContext::getRuleIndex() const {
  return ifccParser::RuleBloc;
}

void ifccParser::BlocContext::copyFrom(BlocContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- BlocinstrContext ------------------------------------------------------------------

std::vector<ifccParser::InstrContext *> ifccParser::BlocinstrContext::instr() {
  return getRuleContexts<ifccParser::InstrContext>();
}

ifccParser::InstrContext* ifccParser::BlocinstrContext::instr(size_t i) {
  return getRuleContext<ifccParser::InstrContext>(i);
}

ifccParser::BlocinstrContext::BlocinstrContext(BlocContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::BlocinstrContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitBlocinstr(this);
  else
    return visitor->visitChildren(this);
}
ifccParser::BlocContext* ifccParser::bloc() {
  BlocContext *_localctx = _tracker.createInstance<BlocContext>(_ctx, getState());
  enterRule(_localctx, 4, ifccParser::RuleBloc);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    _localctx = dynamic_cast<BlocContext *>(_tracker.createInstance<ifccParser::BlocinstrContext>(_localctx));
    enterOuterAlt(_localctx, 1);
    setState(36);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while ((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << ifccParser::T__0)
      | (1ULL << ifccParser::T__5)
      | (1ULL << ifccParser::T__6)
      | (1ULL << ifccParser::NAME))) != 0)) {
      setState(33);
      instr();
      setState(38);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- InstrContext ------------------------------------------------------------------

ifccParser::InstrContext::InstrContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t ifccParser::InstrContext::getRuleIndex() const {
  return ifccParser::RuleInstr;
}

void ifccParser::InstrContext::copyFrom(InstrContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- InstrdeclContext ------------------------------------------------------------------

ifccParser::DeclContext* ifccParser::InstrdeclContext::decl() {
  return getRuleContext<ifccParser::DeclContext>(0);
}

ifccParser::InstrdeclContext::InstrdeclContext(InstrContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::InstrdeclContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitInstrdecl(this);
  else
    return visitor->visitChildren(this);
}
//----------------- InstrwhileContext ------------------------------------------------------------------

ifccParser::WhileinstrContext* ifccParser::InstrwhileContext::whileinstr() {
  return getRuleContext<ifccParser::WhileinstrContext>(0);
}

ifccParser::InstrwhileContext::InstrwhileContext(InstrContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::InstrwhileContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitInstrwhile(this);
  else
    return visitor->visitChildren(this);
}
//----------------- InstraffctContext ------------------------------------------------------------------

ifccParser::AffctContext* ifccParser::InstraffctContext::affct() {
  return getRuleContext<ifccParser::AffctContext>(0);
}

ifccParser::InstraffctContext::InstraffctContext(InstrContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::InstraffctContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitInstraffct(this);
  else
    return visitor->visitChildren(this);
}
//----------------- InstrdefContext ------------------------------------------------------------------

ifccParser::DefContext* ifccParser::InstrdefContext::def() {
  return getRuleContext<ifccParser::DefContext>(0);
}

ifccParser::InstrdefContext::InstrdefContext(InstrContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::InstrdefContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitInstrdef(this);
  else
    return visitor->visitChildren(this);
}
//----------------- InstrifContext ------------------------------------------------------------------

ifccParser::IfinstrContext* ifccParser::InstrifContext::ifinstr() {
  return getRuleContext<ifccParser::IfinstrContext>(0);
}

ifccParser::InstrifContext::InstrifContext(InstrContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::InstrifContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitInstrif(this);
  else
    return visitor->visitChildren(this);
}
ifccParser::InstrContext* ifccParser::instr() {
  InstrContext *_localctx = _tracker.createInstance<InstrContext>(_ctx, getState());
  enterRule(_localctx, 6, ifccParser::RuleInstr);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(44);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 1, _ctx)) {
    case 1: {
      _localctx = dynamic_cast<InstrContext *>(_tracker.createInstance<ifccParser::InstrdeclContext>(_localctx));
      enterOuterAlt(_localctx, 1);
      setState(39);
      decl();
      break;
    }

    case 2: {
      _localctx = dynamic_cast<InstrContext *>(_tracker.createInstance<ifccParser::InstrdefContext>(_localctx));
      enterOuterAlt(_localctx, 2);
      setState(40);
      def();
      break;
    }

    case 3: {
      _localctx = dynamic_cast<InstrContext *>(_tracker.createInstance<ifccParser::InstraffctContext>(_localctx));
      enterOuterAlt(_localctx, 3);
      setState(41);
      affct();
      break;
    }

    case 4: {
      _localctx = dynamic_cast<InstrContext *>(_tracker.createInstance<ifccParser::InstrifContext>(_localctx));
      enterOuterAlt(_localctx, 4);
      setState(42);
      ifinstr();
      break;
    }

    case 5: {
      _localctx = dynamic_cast<InstrContext *>(_tracker.createInstance<ifccParser::InstrwhileContext>(_localctx));
      enterOuterAlt(_localctx, 5);
      setState(43);
      whileinstr();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- DeclContext ------------------------------------------------------------------

ifccParser::DeclContext::DeclContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t ifccParser::DeclContext::getRuleIndex() const {
  return ifccParser::RuleDecl;
}

void ifccParser::DeclContext::copyFrom(DeclContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- DeclintContext ------------------------------------------------------------------

std::vector<tree::TerminalNode *> ifccParser::DeclintContext::NAME() {
  return getTokens(ifccParser::NAME);
}

tree::TerminalNode* ifccParser::DeclintContext::NAME(size_t i) {
  return getToken(ifccParser::NAME, i);
}

ifccParser::DeclintContext::DeclintContext(DeclContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::DeclintContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitDeclint(this);
  else
    return visitor->visitChildren(this);
}
ifccParser::DeclContext* ifccParser::decl() {
  DeclContext *_localctx = _tracker.createInstance<DeclContext>(_ctx, getState());
  enterRule(_localctx, 8, ifccParser::RuleDecl);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    _localctx = dynamic_cast<DeclContext *>(_tracker.createInstance<ifccParser::DeclintContext>(_localctx));
    enterOuterAlt(_localctx, 1);
    setState(46);
    match(ifccParser::T__0);
    setState(47);
    match(ifccParser::NAME);
    setState(52);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while (_la == ifccParser::T__3) {
      setState(48);
      match(ifccParser::T__3);
      setState(49);
      match(ifccParser::NAME);
      setState(54);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
    setState(55);
    match(ifccParser::T__2);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- DefContext ------------------------------------------------------------------

ifccParser::DefContext::DefContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t ifccParser::DefContext::getRuleIndex() const {
  return ifccParser::RuleDef;
}

void ifccParser::DefContext::copyFrom(DefContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- DefexprContext ------------------------------------------------------------------

tree::TerminalNode* ifccParser::DefexprContext::NAME() {
  return getToken(ifccParser::NAME, 0);
}

ifccParser::ExprContext* ifccParser::DefexprContext::expr() {
  return getRuleContext<ifccParser::ExprContext>(0);
}

ifccParser::DefexprContext::DefexprContext(DefContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::DefexprContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitDefexpr(this);
  else
    return visitor->visitChildren(this);
}
ifccParser::DefContext* ifccParser::def() {
  DefContext *_localctx = _tracker.createInstance<DefContext>(_ctx, getState());
  enterRule(_localctx, 10, ifccParser::RuleDef);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    _localctx = dynamic_cast<DefContext *>(_tracker.createInstance<ifccParser::DefexprContext>(_localctx));
    enterOuterAlt(_localctx, 1);
    setState(57);
    match(ifccParser::T__0);
    setState(58);
    match(ifccParser::NAME);
    setState(59);
    match(ifccParser::T__4);
    setState(60);
    expr(0);
    setState(61);
    match(ifccParser::T__2);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- AffctContext ------------------------------------------------------------------

ifccParser::AffctContext::AffctContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t ifccParser::AffctContext::getRuleIndex() const {
  return ifccParser::RuleAffct;
}

void ifccParser::AffctContext::copyFrom(AffctContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- AffexprContext ------------------------------------------------------------------

tree::TerminalNode* ifccParser::AffexprContext::NAME() {
  return getToken(ifccParser::NAME, 0);
}

ifccParser::ExprContext* ifccParser::AffexprContext::expr() {
  return getRuleContext<ifccParser::ExprContext>(0);
}

ifccParser::AffexprContext::AffexprContext(AffctContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::AffexprContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitAffexpr(this);
  else
    return visitor->visitChildren(this);
}
ifccParser::AffctContext* ifccParser::affct() {
  AffctContext *_localctx = _tracker.createInstance<AffctContext>(_ctx, getState());
  enterRule(_localctx, 12, ifccParser::RuleAffct);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    _localctx = dynamic_cast<AffctContext *>(_tracker.createInstance<ifccParser::AffexprContext>(_localctx));
    enterOuterAlt(_localctx, 1);
    setState(63);
    match(ifccParser::NAME);
    setState(64);
    match(ifccParser::T__4);
    setState(65);
    expr(0);
    setState(66);
    match(ifccParser::T__2);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- IfinstrContext ------------------------------------------------------------------

ifccParser::IfinstrContext::IfinstrContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t ifccParser::IfinstrContext::getRuleIndex() const {
  return ifccParser::RuleIfinstr;
}

void ifccParser::IfinstrContext::copyFrom(IfinstrContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- IfblocContext ------------------------------------------------------------------

tree::TerminalNode* ifccParser::IfblocContext::OPENPAR() {
  return getToken(ifccParser::OPENPAR, 0);
}

ifccParser::ExprContext* ifccParser::IfblocContext::expr() {
  return getRuleContext<ifccParser::ExprContext>(0);
}

tree::TerminalNode* ifccParser::IfblocContext::CLOSEPAR() {
  return getToken(ifccParser::CLOSEPAR, 0);
}

tree::TerminalNode* ifccParser::IfblocContext::OPENBRACE() {
  return getToken(ifccParser::OPENBRACE, 0);
}

ifccParser::BlocContext* ifccParser::IfblocContext::bloc() {
  return getRuleContext<ifccParser::BlocContext>(0);
}

tree::TerminalNode* ifccParser::IfblocContext::CLOSEBRACE() {
  return getToken(ifccParser::CLOSEBRACE, 0);
}

ifccParser::IfblocContext::IfblocContext(IfinstrContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::IfblocContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitIfbloc(this);
  else
    return visitor->visitChildren(this);
}
ifccParser::IfinstrContext* ifccParser::ifinstr() {
  IfinstrContext *_localctx = _tracker.createInstance<IfinstrContext>(_ctx, getState());
  enterRule(_localctx, 14, ifccParser::RuleIfinstr);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    _localctx = dynamic_cast<IfinstrContext *>(_tracker.createInstance<ifccParser::IfblocContext>(_localctx));
    enterOuterAlt(_localctx, 1);
    setState(68);
    match(ifccParser::T__5);
    setState(69);
    match(ifccParser::OPENPAR);
    setState(70);
    expr(0);
    setState(71);
    match(ifccParser::CLOSEPAR);
    setState(72);
    match(ifccParser::OPENBRACE);
    setState(73);
    bloc();
    setState(74);
    match(ifccParser::CLOSEBRACE);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- WhileinstrContext ------------------------------------------------------------------

ifccParser::WhileinstrContext::WhileinstrContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t ifccParser::WhileinstrContext::getRuleIndex() const {
  return ifccParser::RuleWhileinstr;
}

void ifccParser::WhileinstrContext::copyFrom(WhileinstrContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- WhileblocContext ------------------------------------------------------------------

tree::TerminalNode* ifccParser::WhileblocContext::OPENPAR() {
  return getToken(ifccParser::OPENPAR, 0);
}

ifccParser::ExprContext* ifccParser::WhileblocContext::expr() {
  return getRuleContext<ifccParser::ExprContext>(0);
}

tree::TerminalNode* ifccParser::WhileblocContext::CLOSEPAR() {
  return getToken(ifccParser::CLOSEPAR, 0);
}

tree::TerminalNode* ifccParser::WhileblocContext::OPENBRACE() {
  return getToken(ifccParser::OPENBRACE, 0);
}

ifccParser::BlocContext* ifccParser::WhileblocContext::bloc() {
  return getRuleContext<ifccParser::BlocContext>(0);
}

tree::TerminalNode* ifccParser::WhileblocContext::CLOSEBRACE() {
  return getToken(ifccParser::CLOSEBRACE, 0);
}

ifccParser::WhileblocContext::WhileblocContext(WhileinstrContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::WhileblocContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitWhilebloc(this);
  else
    return visitor->visitChildren(this);
}
ifccParser::WhileinstrContext* ifccParser::whileinstr() {
  WhileinstrContext *_localctx = _tracker.createInstance<WhileinstrContext>(_ctx, getState());
  enterRule(_localctx, 16, ifccParser::RuleWhileinstr);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    _localctx = dynamic_cast<WhileinstrContext *>(_tracker.createInstance<ifccParser::WhileblocContext>(_localctx));
    enterOuterAlt(_localctx, 1);
    setState(76);
    match(ifccParser::T__6);
    setState(77);
    match(ifccParser::OPENPAR);
    setState(78);
    expr(0);
    setState(79);
    match(ifccParser::CLOSEPAR);
    setState(80);
    match(ifccParser::OPENBRACE);
    setState(81);
    bloc();
    setState(82);
    match(ifccParser::CLOSEBRACE);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ExprContext ------------------------------------------------------------------

ifccParser::ExprContext::ExprContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t ifccParser::ExprContext::getRuleIndex() const {
  return ifccParser::RuleExpr;
}

void ifccParser::ExprContext::copyFrom(ExprContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- ParContext ------------------------------------------------------------------

tree::TerminalNode* ifccParser::ParContext::OPENPAR() {
  return getToken(ifccParser::OPENPAR, 0);
}

ifccParser::ExprContext* ifccParser::ParContext::expr() {
  return getRuleContext<ifccParser::ExprContext>(0);
}

tree::TerminalNode* ifccParser::ParContext::CLOSEPAR() {
  return getToken(ifccParser::CLOSEPAR, 0);
}

ifccParser::ParContext::ParContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::ParContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitPar(this);
  else
    return visitor->visitChildren(this);
}
//----------------- AddContext ------------------------------------------------------------------

std::vector<ifccParser::ExprContext *> ifccParser::AddContext::expr() {
  return getRuleContexts<ifccParser::ExprContext>();
}

ifccParser::ExprContext* ifccParser::AddContext::expr(size_t i) {
  return getRuleContext<ifccParser::ExprContext>(i);
}

ifccParser::AddContext::AddContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::AddContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitAdd(this);
  else
    return visitor->visitChildren(this);
}
//----------------- MinusContext ------------------------------------------------------------------

ifccParser::ExprContext* ifccParser::MinusContext::expr() {
  return getRuleContext<ifccParser::ExprContext>(0);
}

ifccParser::MinusContext::MinusContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::MinusContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitMinus(this);
  else
    return visitor->visitChildren(this);
}
//----------------- GeatContext ------------------------------------------------------------------

std::vector<ifccParser::ExprContext *> ifccParser::GeatContext::expr() {
  return getRuleContexts<ifccParser::ExprContext>();
}

ifccParser::ExprContext* ifccParser::GeatContext::expr(size_t i) {
  return getRuleContext<ifccParser::ExprContext>(i);
}

ifccParser::GeatContext::GeatContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::GeatContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitGeat(this);
  else
    return visitor->visitChildren(this);
}
//----------------- SubContext ------------------------------------------------------------------

std::vector<ifccParser::ExprContext *> ifccParser::SubContext::expr() {
  return getRuleContexts<ifccParser::ExprContext>();
}

ifccParser::ExprContext* ifccParser::SubContext::expr(size_t i) {
  return getRuleContext<ifccParser::ExprContext>(i);
}

ifccParser::SubContext::SubContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::SubContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitSub(this);
  else
    return visitor->visitChildren(this);
}
//----------------- MultContext ------------------------------------------------------------------

std::vector<ifccParser::ExprContext *> ifccParser::MultContext::expr() {
  return getRuleContexts<ifccParser::ExprContext>();
}

ifccParser::ExprContext* ifccParser::MultContext::expr(size_t i) {
  return getRuleContext<ifccParser::ExprContext>(i);
}

ifccParser::MultContext::MultContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::MultContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitMult(this);
  else
    return visitor->visitChildren(this);
}
//----------------- ConstContext ------------------------------------------------------------------

tree::TerminalNode* ifccParser::ConstContext::CONST() {
  return getToken(ifccParser::CONST, 0);
}

ifccParser::ConstContext::ConstContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::ConstContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitConst(this);
  else
    return visitor->visitChildren(this);
}
//----------------- EqContext ------------------------------------------------------------------

std::vector<ifccParser::ExprContext *> ifccParser::EqContext::expr() {
  return getRuleContexts<ifccParser::ExprContext>();
}

ifccParser::ExprContext* ifccParser::EqContext::expr(size_t i) {
  return getRuleContext<ifccParser::ExprContext>(i);
}

ifccParser::EqContext::EqContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::EqContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitEq(this);
  else
    return visitor->visitChildren(this);
}
//----------------- NotContext ------------------------------------------------------------------

ifccParser::ExprContext* ifccParser::NotContext::expr() {
  return getRuleContext<ifccParser::ExprContext>(0);
}

ifccParser::NotContext::NotContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::NotContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitNot(this);
  else
    return visitor->visitChildren(this);
}
//----------------- GeqContext ------------------------------------------------------------------

std::vector<ifccParser::ExprContext *> ifccParser::GeqContext::expr() {
  return getRuleContexts<ifccParser::ExprContext>();
}

ifccParser::ExprContext* ifccParser::GeqContext::expr(size_t i) {
  return getRuleContext<ifccParser::ExprContext>(i);
}

ifccParser::GeqContext::GeqContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::GeqContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitGeq(this);
  else
    return visitor->visitChildren(this);
}
//----------------- LowContext ------------------------------------------------------------------

std::vector<ifccParser::ExprContext *> ifccParser::LowContext::expr() {
  return getRuleContexts<ifccParser::ExprContext>();
}

ifccParser::ExprContext* ifccParser::LowContext::expr(size_t i) {
  return getRuleContext<ifccParser::ExprContext>(i);
}

ifccParser::LowContext::LowContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::LowContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitLow(this);
  else
    return visitor->visitChildren(this);
}
//----------------- NameContext ------------------------------------------------------------------

tree::TerminalNode* ifccParser::NameContext::NAME() {
  return getToken(ifccParser::NAME, 0);
}

ifccParser::NameContext::NameContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::NameContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitName(this);
  else
    return visitor->visitChildren(this);
}
//----------------- LeqContext ------------------------------------------------------------------

std::vector<ifccParser::ExprContext *> ifccParser::LeqContext::expr() {
  return getRuleContexts<ifccParser::ExprContext>();
}

ifccParser::ExprContext* ifccParser::LeqContext::expr(size_t i) {
  return getRuleContext<ifccParser::ExprContext>(i);
}

ifccParser::LeqContext::LeqContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::LeqContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitLeq(this);
  else
    return visitor->visitChildren(this);
}
//----------------- NeqContext ------------------------------------------------------------------

std::vector<ifccParser::ExprContext *> ifccParser::NeqContext::expr() {
  return getRuleContexts<ifccParser::ExprContext>();
}

ifccParser::ExprContext* ifccParser::NeqContext::expr(size_t i) {
  return getRuleContext<ifccParser::ExprContext>(i);
}

ifccParser::NeqContext::NeqContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::NeqContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitNeq(this);
  else
    return visitor->visitChildren(this);
}

ifccParser::ExprContext* ifccParser::expr() {
   return expr(0);
}

ifccParser::ExprContext* ifccParser::expr(int precedence) {
  ParserRuleContext *parentContext = _ctx;
  size_t parentState = getState();
  ifccParser::ExprContext *_localctx = _tracker.createInstance<ExprContext>(_ctx, parentState);
  ifccParser::ExprContext *previousContext = _localctx;
  (void)previousContext; // Silence compiler, in case the context is not used by generated code.
  size_t startState = 18;
  enterRecursionRule(_localctx, 18, ifccParser::RuleExpr, precedence);

    

  auto onExit = finally([=] {
    unrollRecursionContexts(parentContext);
  });
  try {
    size_t alt;
    enterOuterAlt(_localctx, 1);
    setState(95);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case ifccParser::OPENPAR: {
        _localctx = _tracker.createInstance<ParContext>(_localctx);
        _ctx = _localctx;
        previousContext = _localctx;

        setState(85);
        match(ifccParser::OPENPAR);
        setState(86);
        expr(0);
        setState(87);
        match(ifccParser::CLOSEPAR);
        break;
      }

      case ifccParser::T__7: {
        _localctx = _tracker.createInstance<NotContext>(_localctx);
        _ctx = _localctx;
        previousContext = _localctx;
        setState(89);
        match(ifccParser::T__7);
        setState(90);
        expr(13);
        break;
      }

      case ifccParser::T__15: {
        _localctx = _tracker.createInstance<MinusContext>(_localctx);
        _ctx = _localctx;
        previousContext = _localctx;
        setState(91);
        match(ifccParser::T__15);
        setState(92);
        expr(3);
        break;
      }

      case ifccParser::CONST: {
        _localctx = _tracker.createInstance<ConstContext>(_localctx);
        _ctx = _localctx;
        previousContext = _localctx;
        setState(93);
        match(ifccParser::CONST);
        break;
      }

      case ifccParser::NAME: {
        _localctx = _tracker.createInstance<NameContext>(_localctx);
        _ctx = _localctx;
        previousContext = _localctx;
        setState(94);
        match(ifccParser::NAME);
        break;
      }

    default:
      throw NoViableAltException(this);
    }
    _ctx->stop = _input->LT(-1);
    setState(126);
    _errHandler->sync(this);
    alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 5, _ctx);
    while (alt != 2 && alt != atn::ATN::INVALID_ALT_NUMBER) {
      if (alt == 1) {
        if (!_parseListeners.empty())
          triggerExitRuleEvent();
        previousContext = _localctx;
        setState(124);
        _errHandler->sync(this);
        switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 4, _ctx)) {
        case 1: {
          auto newContext = _tracker.createInstance<EqContext>(_tracker.createInstance<ExprContext>(parentContext, parentState));
          _localctx = newContext;
          pushNewRecursionContext(newContext, startState, RuleExpr);
          setState(97);

          if (!(precpred(_ctx, 12))) throw FailedPredicateException(this, "precpred(_ctx, 12)");
          setState(98);
          match(ifccParser::T__8);
          setState(99);
          expr(13);
          break;
        }

        case 2: {
          auto newContext = _tracker.createInstance<NeqContext>(_tracker.createInstance<ExprContext>(parentContext, parentState));
          _localctx = newContext;
          pushNewRecursionContext(newContext, startState, RuleExpr);
          setState(100);

          if (!(precpred(_ctx, 11))) throw FailedPredicateException(this, "precpred(_ctx, 11)");
          setState(101);
          match(ifccParser::T__9);
          setState(102);
          expr(12);
          break;
        }

        case 3: {
          auto newContext = _tracker.createInstance<LeqContext>(_tracker.createInstance<ExprContext>(parentContext, parentState));
          _localctx = newContext;
          pushNewRecursionContext(newContext, startState, RuleExpr);
          setState(103);

          if (!(precpred(_ctx, 10))) throw FailedPredicateException(this, "precpred(_ctx, 10)");
          setState(104);
          match(ifccParser::T__10);
          setState(105);
          expr(11);
          break;
        }

        case 4: {
          auto newContext = _tracker.createInstance<GeqContext>(_tracker.createInstance<ExprContext>(parentContext, parentState));
          _localctx = newContext;
          pushNewRecursionContext(newContext, startState, RuleExpr);
          setState(106);

          if (!(precpred(_ctx, 9))) throw FailedPredicateException(this, "precpred(_ctx, 9)");
          setState(107);
          match(ifccParser::T__11);
          setState(108);
          expr(10);
          break;
        }

        case 5: {
          auto newContext = _tracker.createInstance<LowContext>(_tracker.createInstance<ExprContext>(parentContext, parentState));
          _localctx = newContext;
          pushNewRecursionContext(newContext, startState, RuleExpr);
          setState(109);

          if (!(precpred(_ctx, 8))) throw FailedPredicateException(this, "precpred(_ctx, 8)");
          setState(110);
          match(ifccParser::T__12);
          setState(111);
          expr(9);
          break;
        }

        case 6: {
          auto newContext = _tracker.createInstance<GeatContext>(_tracker.createInstance<ExprContext>(parentContext, parentState));
          _localctx = newContext;
          pushNewRecursionContext(newContext, startState, RuleExpr);
          setState(112);

          if (!(precpred(_ctx, 7))) throw FailedPredicateException(this, "precpred(_ctx, 7)");
          setState(113);
          match(ifccParser::T__13);
          setState(114);
          expr(8);
          break;
        }

        case 7: {
          auto newContext = _tracker.createInstance<MultContext>(_tracker.createInstance<ExprContext>(parentContext, parentState));
          _localctx = newContext;
          pushNewRecursionContext(newContext, startState, RuleExpr);
          setState(115);

          if (!(precpred(_ctx, 6))) throw FailedPredicateException(this, "precpred(_ctx, 6)");
          setState(116);
          match(ifccParser::T__14);
          setState(117);
          expr(7);
          break;
        }

        case 8: {
          auto newContext = _tracker.createInstance<SubContext>(_tracker.createInstance<ExprContext>(parentContext, parentState));
          _localctx = newContext;
          pushNewRecursionContext(newContext, startState, RuleExpr);
          setState(118);

          if (!(precpred(_ctx, 5))) throw FailedPredicateException(this, "precpred(_ctx, 5)");
          setState(119);
          match(ifccParser::T__15);
          setState(120);
          expr(6);
          break;
        }

        case 9: {
          auto newContext = _tracker.createInstance<AddContext>(_tracker.createInstance<ExprContext>(parentContext, parentState));
          _localctx = newContext;
          pushNewRecursionContext(newContext, startState, RuleExpr);
          setState(121);

          if (!(precpred(_ctx, 4))) throw FailedPredicateException(this, "precpred(_ctx, 4)");
          setState(122);
          match(ifccParser::T__16);
          setState(123);
          expr(5);
          break;
        }

        } 
      }
      setState(128);
      _errHandler->sync(this);
      alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 5, _ctx);
    }
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }
  return _localctx;
}

bool ifccParser::sempred(RuleContext *context, size_t ruleIndex, size_t predicateIndex) {
  switch (ruleIndex) {
    case 9: return exprSempred(dynamic_cast<ExprContext *>(context), predicateIndex);

  default:
    break;
  }
  return true;
}

bool ifccParser::exprSempred(ExprContext *_localctx, size_t predicateIndex) {
  switch (predicateIndex) {
    case 0: return precpred(_ctx, 12);
    case 1: return precpred(_ctx, 11);
    case 2: return precpred(_ctx, 10);
    case 3: return precpred(_ctx, 9);
    case 4: return precpred(_ctx, 8);
    case 5: return precpred(_ctx, 7);
    case 6: return precpred(_ctx, 6);
    case 7: return precpred(_ctx, 5);
    case 8: return precpred(_ctx, 4);

  default:
    break;
  }
  return true;
}

// Static vars and initialization.
std::vector<dfa::DFA> ifccParser::_decisionToDFA;
atn::PredictionContextCache ifccParser::_sharedContextCache;

// We own the ATN which in turn owns the ATN states.
atn::ATN ifccParser::_atn;
std::vector<uint16_t> ifccParser::_serializedATN;

std::vector<std::string> ifccParser::_ruleNames = {
  "axiom", "prog", "bloc", "instr", "decl", "def", "affct", "ifinstr", "whileinstr", 
  "expr"
};

std::vector<std::string> ifccParser::_literalNames = {
  "", "'int'", "'main'", "';'", "','", "'='", "'if'", "'while'", "'!'", 
  "'=='", "'!='", "'<='", "'>='", "'<'", "'>'", "'*'", "'-'", "'+'", "'('", 
  "')'", "'{'", "'}'", "'return'"
};

std::vector<std::string> ifccParser::_symbolicNames = {
  "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", 
  "OPENPAR", "CLOSEPAR", "OPENBRACE", "CLOSEBRACE", "RETURN", "CONST", "NAME", 
  "COMMENT1", "COMMENT2", "DIRECTIVE", "WS"
};

dfa::Vocabulary ifccParser::_vocabulary(_literalNames, _symbolicNames);

std::vector<std::string> ifccParser::_tokenNames;

ifccParser::Initializer::Initializer() {
	for (size_t i = 0; i < _symbolicNames.size(); ++i) {
		std::string name = _vocabulary.getLiteralName(i);
		if (name.empty()) {
			name = _vocabulary.getSymbolicName(i);
		}

		if (name.empty()) {
			_tokenNames.push_back("<INVALID>");
		} else {
      _tokenNames.push_back(name);
    }
	}

  _serializedATN = {
    0x3, 0x608b, 0xa72a, 0x8133, 0xb9ed, 0x417c, 0x3be7, 0x7786, 0x5964, 
    0x3, 0x1e, 0x84, 0x4, 0x2, 0x9, 0x2, 0x4, 0x3, 0x9, 0x3, 0x4, 0x4, 0x9, 
    0x4, 0x4, 0x5, 0x9, 0x5, 0x4, 0x6, 0x9, 0x6, 0x4, 0x7, 0x9, 0x7, 0x4, 
    0x8, 0x9, 0x8, 0x4, 0x9, 0x9, 0x9, 0x4, 0xa, 0x9, 0xa, 0x4, 0xb, 0x9, 
    0xb, 0x3, 0x2, 0x3, 0x2, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 
    0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 
    0x4, 0x7, 0x4, 0x25, 0xa, 0x4, 0xc, 0x4, 0xe, 0x4, 0x28, 0xb, 0x4, 0x3, 
    0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x5, 0x5, 0x2f, 0xa, 0x5, 
    0x3, 0x6, 0x3, 0x6, 0x3, 0x6, 0x3, 0x6, 0x7, 0x6, 0x35, 0xa, 0x6, 0xc, 
    0x6, 0xe, 0x6, 0x38, 0xb, 0x6, 0x3, 0x6, 0x3, 0x6, 0x3, 0x7, 0x3, 0x7, 
    0x3, 0x7, 0x3, 0x7, 0x3, 0x7, 0x3, 0x7, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 
    0x3, 0x8, 0x3, 0x8, 0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 
    0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 0x3, 0xa, 0x3, 0xa, 0x3, 0xa, 0x3, 0xa, 
    0x3, 0xa, 0x3, 0xa, 0x3, 0xa, 0x3, 0xa, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 
    0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 
    0x3, 0xb, 0x5, 0xb, 0x62, 0xa, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 
    0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 
    0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 
    0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 
    0xb, 0x3, 0xb, 0x3, 0xb, 0x7, 0xb, 0x7f, 0xa, 0xb, 0xc, 0xb, 0xe, 0xb, 
    0x82, 0xb, 0xb, 0x3, 0xb, 0x2, 0x3, 0x14, 0xc, 0x2, 0x4, 0x6, 0x8, 0xa, 
    0xc, 0xe, 0x10, 0x12, 0x14, 0x2, 0x2, 0x2, 0x8c, 0x2, 0x16, 0x3, 0x2, 
    0x2, 0x2, 0x4, 0x18, 0x3, 0x2, 0x2, 0x2, 0x6, 0x26, 0x3, 0x2, 0x2, 0x2, 
    0x8, 0x2e, 0x3, 0x2, 0x2, 0x2, 0xa, 0x30, 0x3, 0x2, 0x2, 0x2, 0xc, 0x3b, 
    0x3, 0x2, 0x2, 0x2, 0xe, 0x41, 0x3, 0x2, 0x2, 0x2, 0x10, 0x46, 0x3, 
    0x2, 0x2, 0x2, 0x12, 0x4e, 0x3, 0x2, 0x2, 0x2, 0x14, 0x61, 0x3, 0x2, 
    0x2, 0x2, 0x16, 0x17, 0x5, 0x4, 0x3, 0x2, 0x17, 0x3, 0x3, 0x2, 0x2, 
    0x2, 0x18, 0x19, 0x7, 0x3, 0x2, 0x2, 0x19, 0x1a, 0x7, 0x4, 0x2, 0x2, 
    0x1a, 0x1b, 0x7, 0x14, 0x2, 0x2, 0x1b, 0x1c, 0x7, 0x15, 0x2, 0x2, 0x1c, 
    0x1d, 0x7, 0x16, 0x2, 0x2, 0x1d, 0x1e, 0x5, 0x6, 0x4, 0x2, 0x1e, 0x1f, 
    0x7, 0x18, 0x2, 0x2, 0x1f, 0x20, 0x5, 0x14, 0xb, 0x2, 0x20, 0x21, 0x7, 
    0x5, 0x2, 0x2, 0x21, 0x22, 0x7, 0x17, 0x2, 0x2, 0x22, 0x5, 0x3, 0x2, 
    0x2, 0x2, 0x23, 0x25, 0x5, 0x8, 0x5, 0x2, 0x24, 0x23, 0x3, 0x2, 0x2, 
    0x2, 0x25, 0x28, 0x3, 0x2, 0x2, 0x2, 0x26, 0x24, 0x3, 0x2, 0x2, 0x2, 
    0x26, 0x27, 0x3, 0x2, 0x2, 0x2, 0x27, 0x7, 0x3, 0x2, 0x2, 0x2, 0x28, 
    0x26, 0x3, 0x2, 0x2, 0x2, 0x29, 0x2f, 0x5, 0xa, 0x6, 0x2, 0x2a, 0x2f, 
    0x5, 0xc, 0x7, 0x2, 0x2b, 0x2f, 0x5, 0xe, 0x8, 0x2, 0x2c, 0x2f, 0x5, 
    0x10, 0x9, 0x2, 0x2d, 0x2f, 0x5, 0x12, 0xa, 0x2, 0x2e, 0x29, 0x3, 0x2, 
    0x2, 0x2, 0x2e, 0x2a, 0x3, 0x2, 0x2, 0x2, 0x2e, 0x2b, 0x3, 0x2, 0x2, 
    0x2, 0x2e, 0x2c, 0x3, 0x2, 0x2, 0x2, 0x2e, 0x2d, 0x3, 0x2, 0x2, 0x2, 
    0x2f, 0x9, 0x3, 0x2, 0x2, 0x2, 0x30, 0x31, 0x7, 0x3, 0x2, 0x2, 0x31, 
    0x36, 0x7, 0x1a, 0x2, 0x2, 0x32, 0x33, 0x7, 0x6, 0x2, 0x2, 0x33, 0x35, 
    0x7, 0x1a, 0x2, 0x2, 0x34, 0x32, 0x3, 0x2, 0x2, 0x2, 0x35, 0x38, 0x3, 
    0x2, 0x2, 0x2, 0x36, 0x34, 0x3, 0x2, 0x2, 0x2, 0x36, 0x37, 0x3, 0x2, 
    0x2, 0x2, 0x37, 0x39, 0x3, 0x2, 0x2, 0x2, 0x38, 0x36, 0x3, 0x2, 0x2, 
    0x2, 0x39, 0x3a, 0x7, 0x5, 0x2, 0x2, 0x3a, 0xb, 0x3, 0x2, 0x2, 0x2, 
    0x3b, 0x3c, 0x7, 0x3, 0x2, 0x2, 0x3c, 0x3d, 0x7, 0x1a, 0x2, 0x2, 0x3d, 
    0x3e, 0x7, 0x7, 0x2, 0x2, 0x3e, 0x3f, 0x5, 0x14, 0xb, 0x2, 0x3f, 0x40, 
    0x7, 0x5, 0x2, 0x2, 0x40, 0xd, 0x3, 0x2, 0x2, 0x2, 0x41, 0x42, 0x7, 
    0x1a, 0x2, 0x2, 0x42, 0x43, 0x7, 0x7, 0x2, 0x2, 0x43, 0x44, 0x5, 0x14, 
    0xb, 0x2, 0x44, 0x45, 0x7, 0x5, 0x2, 0x2, 0x45, 0xf, 0x3, 0x2, 0x2, 
    0x2, 0x46, 0x47, 0x7, 0x8, 0x2, 0x2, 0x47, 0x48, 0x7, 0x14, 0x2, 0x2, 
    0x48, 0x49, 0x5, 0x14, 0xb, 0x2, 0x49, 0x4a, 0x7, 0x15, 0x2, 0x2, 0x4a, 
    0x4b, 0x7, 0x16, 0x2, 0x2, 0x4b, 0x4c, 0x5, 0x6, 0x4, 0x2, 0x4c, 0x4d, 
    0x7, 0x17, 0x2, 0x2, 0x4d, 0x11, 0x3, 0x2, 0x2, 0x2, 0x4e, 0x4f, 0x7, 
    0x9, 0x2, 0x2, 0x4f, 0x50, 0x7, 0x14, 0x2, 0x2, 0x50, 0x51, 0x5, 0x14, 
    0xb, 0x2, 0x51, 0x52, 0x7, 0x15, 0x2, 0x2, 0x52, 0x53, 0x7, 0x16, 0x2, 
    0x2, 0x53, 0x54, 0x5, 0x6, 0x4, 0x2, 0x54, 0x55, 0x7, 0x17, 0x2, 0x2, 
    0x55, 0x13, 0x3, 0x2, 0x2, 0x2, 0x56, 0x57, 0x8, 0xb, 0x1, 0x2, 0x57, 
    0x58, 0x7, 0x14, 0x2, 0x2, 0x58, 0x59, 0x5, 0x14, 0xb, 0x2, 0x59, 0x5a, 
    0x7, 0x15, 0x2, 0x2, 0x5a, 0x62, 0x3, 0x2, 0x2, 0x2, 0x5b, 0x5c, 0x7, 
    0xa, 0x2, 0x2, 0x5c, 0x62, 0x5, 0x14, 0xb, 0xf, 0x5d, 0x5e, 0x7, 0x12, 
    0x2, 0x2, 0x5e, 0x62, 0x5, 0x14, 0xb, 0x5, 0x5f, 0x62, 0x7, 0x19, 0x2, 
    0x2, 0x60, 0x62, 0x7, 0x1a, 0x2, 0x2, 0x61, 0x56, 0x3, 0x2, 0x2, 0x2, 
    0x61, 0x5b, 0x3, 0x2, 0x2, 0x2, 0x61, 0x5d, 0x3, 0x2, 0x2, 0x2, 0x61, 
    0x5f, 0x3, 0x2, 0x2, 0x2, 0x61, 0x60, 0x3, 0x2, 0x2, 0x2, 0x62, 0x80, 
    0x3, 0x2, 0x2, 0x2, 0x63, 0x64, 0xc, 0xe, 0x2, 0x2, 0x64, 0x65, 0x7, 
    0xb, 0x2, 0x2, 0x65, 0x7f, 0x5, 0x14, 0xb, 0xf, 0x66, 0x67, 0xc, 0xd, 
    0x2, 0x2, 0x67, 0x68, 0x7, 0xc, 0x2, 0x2, 0x68, 0x7f, 0x5, 0x14, 0xb, 
    0xe, 0x69, 0x6a, 0xc, 0xc, 0x2, 0x2, 0x6a, 0x6b, 0x7, 0xd, 0x2, 0x2, 
    0x6b, 0x7f, 0x5, 0x14, 0xb, 0xd, 0x6c, 0x6d, 0xc, 0xb, 0x2, 0x2, 0x6d, 
    0x6e, 0x7, 0xe, 0x2, 0x2, 0x6e, 0x7f, 0x5, 0x14, 0xb, 0xc, 0x6f, 0x70, 
    0xc, 0xa, 0x2, 0x2, 0x70, 0x71, 0x7, 0xf, 0x2, 0x2, 0x71, 0x7f, 0x5, 
    0x14, 0xb, 0xb, 0x72, 0x73, 0xc, 0x9, 0x2, 0x2, 0x73, 0x74, 0x7, 0x10, 
    0x2, 0x2, 0x74, 0x7f, 0x5, 0x14, 0xb, 0xa, 0x75, 0x76, 0xc, 0x8, 0x2, 
    0x2, 0x76, 0x77, 0x7, 0x11, 0x2, 0x2, 0x77, 0x7f, 0x5, 0x14, 0xb, 0x9, 
    0x78, 0x79, 0xc, 0x7, 0x2, 0x2, 0x79, 0x7a, 0x7, 0x12, 0x2, 0x2, 0x7a, 
    0x7f, 0x5, 0x14, 0xb, 0x8, 0x7b, 0x7c, 0xc, 0x6, 0x2, 0x2, 0x7c, 0x7d, 
    0x7, 0x13, 0x2, 0x2, 0x7d, 0x7f, 0x5, 0x14, 0xb, 0x7, 0x7e, 0x63, 0x3, 
    0x2, 0x2, 0x2, 0x7e, 0x66, 0x3, 0x2, 0x2, 0x2, 0x7e, 0x69, 0x3, 0x2, 
    0x2, 0x2, 0x7e, 0x6c, 0x3, 0x2, 0x2, 0x2, 0x7e, 0x6f, 0x3, 0x2, 0x2, 
    0x2, 0x7e, 0x72, 0x3, 0x2, 0x2, 0x2, 0x7e, 0x75, 0x3, 0x2, 0x2, 0x2, 
    0x7e, 0x78, 0x3, 0x2, 0x2, 0x2, 0x7e, 0x7b, 0x3, 0x2, 0x2, 0x2, 0x7f, 
    0x82, 0x3, 0x2, 0x2, 0x2, 0x80, 0x7e, 0x3, 0x2, 0x2, 0x2, 0x80, 0x81, 
    0x3, 0x2, 0x2, 0x2, 0x81, 0x15, 0x3, 0x2, 0x2, 0x2, 0x82, 0x80, 0x3, 
    0x2, 0x2, 0x2, 0x8, 0x26, 0x2e, 0x36, 0x61, 0x7e, 0x80, 
  };

  atn::ATNDeserializer deserializer;
  _atn = deserializer.deserialize(_serializedATN);

  size_t count = _atn.getNumberOfDecisions();
  _decisionToDFA.reserve(count);
  for (size_t i = 0; i < count; i++) { 
    _decisionToDFA.emplace_back(_atn.getDecisionState(i), i);
  }
}

ifccParser::Initializer ifccParser::_init;
