
// Generated from ifcc.g4 by ANTLR 4.7.2

#pragma once


#include "antlr4-runtime.h"
#include "ifccParser.h"



/**
 * This class defines an abstract visitor for a parse tree
 * produced by ifccParser.
 */
class  ifccVisitor : public antlr4::tree::AbstractParseTreeVisitor {
public:

  /**
   * Visit parse trees produced by ifccParser.
   */
    virtual antlrcpp::Any visitAxiom(ifccParser::AxiomContext *context) = 0;

    virtual antlrcpp::Any visitProg(ifccParser::ProgContext *context) = 0;

    virtual antlrcpp::Any visitBlocinstr(ifccParser::BlocinstrContext *context) = 0;

    virtual antlrcpp::Any visitInstrdecl(ifccParser::InstrdeclContext *context) = 0;

    virtual antlrcpp::Any visitInstrdef(ifccParser::InstrdefContext *context) = 0;

    virtual antlrcpp::Any visitInstraffct(ifccParser::InstraffctContext *context) = 0;

    virtual antlrcpp::Any visitInstrif(ifccParser::InstrifContext *context) = 0;

    virtual antlrcpp::Any visitInstrwhile(ifccParser::InstrwhileContext *context) = 0;

    virtual antlrcpp::Any visitDeclint(ifccParser::DeclintContext *context) = 0;

    virtual antlrcpp::Any visitDefexpr(ifccParser::DefexprContext *context) = 0;

    virtual antlrcpp::Any visitAffexpr(ifccParser::AffexprContext *context) = 0;

    virtual antlrcpp::Any visitIfbloc(ifccParser::IfblocContext *context) = 0;

    virtual antlrcpp::Any visitWhilebloc(ifccParser::WhileblocContext *context) = 0;

    virtual antlrcpp::Any visitPar(ifccParser::ParContext *context) = 0;

    virtual antlrcpp::Any visitAdd(ifccParser::AddContext *context) = 0;

    virtual antlrcpp::Any visitMinus(ifccParser::MinusContext *context) = 0;

    virtual antlrcpp::Any visitGeat(ifccParser::GeatContext *context) = 0;

    virtual antlrcpp::Any visitSub(ifccParser::SubContext *context) = 0;

    virtual antlrcpp::Any visitMult(ifccParser::MultContext *context) = 0;

    virtual antlrcpp::Any visitConst(ifccParser::ConstContext *context) = 0;

    virtual antlrcpp::Any visitEq(ifccParser::EqContext *context) = 0;

    virtual antlrcpp::Any visitNot(ifccParser::NotContext *context) = 0;

    virtual antlrcpp::Any visitGeq(ifccParser::GeqContext *context) = 0;

    virtual antlrcpp::Any visitLow(ifccParser::LowContext *context) = 0;

    virtual antlrcpp::Any visitName(ifccParser::NameContext *context) = 0;

    virtual antlrcpp::Any visitLeq(ifccParser::LeqContext *context) = 0;

    virtual antlrcpp::Any visitNeq(ifccParser::NeqContext *context) = 0;


};

