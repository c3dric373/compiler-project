int main(){
    int a = c;
    return a;
}