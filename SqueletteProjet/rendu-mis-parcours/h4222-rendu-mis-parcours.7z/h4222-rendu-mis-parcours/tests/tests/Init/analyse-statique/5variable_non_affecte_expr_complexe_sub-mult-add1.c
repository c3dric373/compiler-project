int main(){
    int a = 8+5-2*c*5;
    return a;
}