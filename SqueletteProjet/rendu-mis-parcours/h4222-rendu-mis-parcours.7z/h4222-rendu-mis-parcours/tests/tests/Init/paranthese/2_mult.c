int main(){
    int a = (5*7*8);
    int b = (5*7);
    return (a*b);
}