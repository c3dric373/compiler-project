int main(){
    int a = -3;
    int b = (5+1+1*1)+(5-5*0)-6;
    int c,d;
    c = 5*b;
    d = 4-1*(5*(1-1)+1);
    return a+b*c-d;
}

