int main(){
    int a = 5-2;
    return a;
}