int main(){
    int a = 8;
	int b = 5;
	int c = a*b;
    return c;
}
