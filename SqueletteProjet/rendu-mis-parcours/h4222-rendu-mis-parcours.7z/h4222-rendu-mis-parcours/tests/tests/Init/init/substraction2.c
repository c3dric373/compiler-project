int main(){
    int a = 5-6;
    return a;
}