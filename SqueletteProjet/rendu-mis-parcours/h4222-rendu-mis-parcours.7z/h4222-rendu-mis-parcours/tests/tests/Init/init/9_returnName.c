int main(){
    int a = 8;
    return a;
}
