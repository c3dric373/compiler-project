int main(){
    return 50;
}
