int main(){
    int a = 1;
    int b = 3;
    int c = 8;
    int d = 2-a*c-b;
    return d;
}
