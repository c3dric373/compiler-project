int main(){
    int a = 7;
    int b = 4;
    int c = 2;
    int d = 2*a-c*b;
    return d;
}
