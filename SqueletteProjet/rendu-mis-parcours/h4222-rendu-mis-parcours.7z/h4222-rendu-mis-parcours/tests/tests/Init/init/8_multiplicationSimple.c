int main(){
    int a = 8*5;
    return a;
}
