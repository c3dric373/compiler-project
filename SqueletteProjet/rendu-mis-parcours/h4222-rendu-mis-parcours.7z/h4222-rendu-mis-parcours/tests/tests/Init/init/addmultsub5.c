int main(){
    int a = 5*8+66-9+6*8-1;
    int b = 5*8-9+6;
    int c = a+b;
    return a+b*10-c;
}