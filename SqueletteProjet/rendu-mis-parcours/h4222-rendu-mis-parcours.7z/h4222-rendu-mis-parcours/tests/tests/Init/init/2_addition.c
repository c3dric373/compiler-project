int main(){
    int a = 5+7;
    return a;
}