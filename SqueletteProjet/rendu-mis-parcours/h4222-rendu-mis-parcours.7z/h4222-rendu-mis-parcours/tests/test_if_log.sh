chmod 755 pld-wrapper.sh
python3 pld-test.py tests/Init/
