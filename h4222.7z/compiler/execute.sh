./ifcc ret42.c
gcc ret42.s
./a.out
echo $?
