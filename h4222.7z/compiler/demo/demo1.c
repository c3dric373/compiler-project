int main() {

    int a = ((5 + 2) * (4 * 2 + 3) + 5 - 8 + 4) - 10;
    char b = ('4' + 's') - 'a' * 'b';
    return (a + b);

}
