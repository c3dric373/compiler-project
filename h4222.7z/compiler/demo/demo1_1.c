int main(){
    char a='a';
    char c='b';
    char b=a*c;
    char d = a +b ;
    return d -a;
}
