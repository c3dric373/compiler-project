int main() {
    int a = 3;
    int b = 2;
    int c = 7;
    if (a == 4) {
        c = 2;
    } else {
        c = 4;
    }
    int d = 5;
    return c;
}
