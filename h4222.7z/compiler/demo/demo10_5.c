void f() {
    int m = 3;
}

int main() {
    return f(z);
}