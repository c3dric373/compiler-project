#include<stdio.h>

int main() {
    putchar('r');
    putchar('e');
    putchar('t');
    putchar('4');
    putchar('2');
    return 42;
}
