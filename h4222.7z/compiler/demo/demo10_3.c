int main() {
    int a = 2;
    while(1 == 1){
        int c =2;
        a =1;
        return 4;
    }
    return a;

}
