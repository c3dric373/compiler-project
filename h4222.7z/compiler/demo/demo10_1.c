int main() {
    int a = 2;
    if (0) {
        a = 5;
    }
    return a;
}
