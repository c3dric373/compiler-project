int f(int z) {
    return;
}

void g(){
    return 4;
}
int main() {
    int z = 10;
    int a = f(z);
    a = g();
}
