int main() {

    int a = 5 + 2;
    int b = 1 * 10;
    int c = a * 0;
    int d = 1 + a + 3;
    return (a + b);

}
