void f() {
    int a = 'a';
    putchar(a);
}

int main() {
    f();
    return 0;
}