int main(){
	
    char a=getchar();
    putchar(a);
    return a;

}
