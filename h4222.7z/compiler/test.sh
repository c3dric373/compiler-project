echo "padawan:"
padawan=source ./execute.sh
echo "gcc:"
gcc=source ./run_gcc.sh
