gcc ret42.c
./a.out
echo $?
