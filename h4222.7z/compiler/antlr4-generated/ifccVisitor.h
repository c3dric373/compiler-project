
// Generated from ifcc.g4 by ANTLR 4.7.2

#pragma once


#include "antlr4-runtime.h"
#include "ifccParser.h"



/**
 * This class defines an abstract visitor for a parse tree
 * produced by ifccParser.
 */
class  ifccVisitor : public antlr4::tree::AbstractParseTreeVisitor {
public:

  /**
   * Visit parse trees produced by ifccParser.
   */
    virtual antlrcpp::Any visitAxiom(ifccParser::AxiomContext *context) = 0;

    virtual antlrcpp::Any visitProg(ifccParser::ProgContext *context) = 0;

    virtual antlrcpp::Any visitBlocinit(ifccParser::BlocinitContext *context) = 0;

    virtual antlrcpp::Any visitDeclproc(ifccParser::DeclprocContext *context) = 0;

    virtual antlrcpp::Any visitDeclfun(ifccParser::DeclfunContext *context) = 0;

    virtual antlrcpp::Any visitDefproc(ifccParser::DefprocContext *context) = 0;

    virtual antlrcpp::Any visitDeffun(ifccParser::DeffunContext *context) = 0;

    virtual antlrcpp::Any visitInt(ifccParser::IntContext *context) = 0;

    virtual antlrcpp::Any visitChar(ifccParser::CharContext *context) = 0;

    virtual antlrcpp::Any visitBlocinstr(ifccParser::BlocinstrContext *context) = 0;

    virtual antlrcpp::Any visitDeclint(ifccParser::DeclintContext *context) = 0;

    virtual antlrcpp::Any visitDeclchar(ifccParser::DeclcharContext *context) = 0;

    virtual antlrcpp::Any visitDeclinttab(ifccParser::DeclinttabContext *context) = 0;

    virtual antlrcpp::Any visitDeclchartab(ifccParser::DeclchartabContext *context) = 0;

    virtual antlrcpp::Any visitDefint(ifccParser::DefintContext *context) = 0;

    virtual antlrcpp::Any visitDefchar(ifccParser::DefcharContext *context) = 0;

    virtual antlrcpp::Any visitAffexpr(ifccParser::AffexprContext *context) = 0;

    virtual antlrcpp::Any visitAfftab(ifccParser::AfftabContext *context) = 0;

    virtual antlrcpp::Any visitIfbloc(ifccParser::IfblocContext *context) = 0;

    virtual antlrcpp::Any visitIfelsebloc(ifccParser::IfelseblocContext *context) = 0;

    virtual antlrcpp::Any visitWhilebloc(ifccParser::WhileblocContext *context) = 0;

    virtual antlrcpp::Any visitForbloc(ifccParser::ForblocContext *context) = 0;

    virtual antlrcpp::Any visitInstrbloc(ifccParser::InstrblocContext *context) = 0;

    virtual antlrcpp::Any visitCallproc(ifccParser::CallprocContext *context) = 0;

    virtual antlrcpp::Any visitPutchar(ifccParser::PutcharContext *context) = 0;

    virtual antlrcpp::Any visitReturn(ifccParser::ReturnContext *context) = 0;

    virtual antlrcpp::Any visitReturnexpr(ifccParser::ReturnexprContext *context) = 0;

    virtual antlrcpp::Any visitFordeclint(ifccParser::FordeclintContext *context) = 0;

    virtual antlrcpp::Any visitFordeclchar(ifccParser::FordeclcharContext *context) = 0;

    virtual antlrcpp::Any visitFordeclinttab(ifccParser::FordeclinttabContext *context) = 0;

    virtual antlrcpp::Any visitFordeclchartab(ifccParser::FordeclchartabContext *context) = 0;

    virtual antlrcpp::Any visitFordefint(ifccParser::FordefintContext *context) = 0;

    virtual antlrcpp::Any visitFordefchar(ifccParser::FordefcharContext *context) = 0;

    virtual antlrcpp::Any visitForaffexpr(ifccParser::ForaffexprContext *context) = 0;

    virtual antlrcpp::Any visitForafftab(ifccParser::ForafftabContext *context) = 0;

    virtual antlrcpp::Any visitLoopaff(ifccParser::LoopaffContext *context) = 0;

    virtual antlrcpp::Any visitLoopafftab(ifccParser::LoopafftabContext *context) = 0;

    virtual antlrcpp::Any visitPar(ifccParser::ParContext *context) = 0;

    virtual antlrcpp::Any visitGetchar(ifccParser::GetcharContext *context) = 0;

    virtual antlrcpp::Any visitAdd(ifccParser::AddContext *context) = 0;

    virtual antlrcpp::Any visitMinus(ifccParser::MinusContext *context) = 0;

    virtual antlrcpp::Any visitSub(ifccParser::SubContext *context) = 0;

    virtual antlrcpp::Any visitGeat(ifccParser::GeatContext *context) = 0;

    virtual antlrcpp::Any visitMult(ifccParser::MultContext *context) = 0;

    virtual antlrcpp::Any visitOr(ifccParser::OrContext *context) = 0;

    virtual antlrcpp::Any visitConst(ifccParser::ConstContext *context) = 0;

    virtual antlrcpp::Any visitTabaccess(ifccParser::TabaccessContext *context) = 0;

    virtual antlrcpp::Any visitConstchar(ifccParser::ConstcharContext *context) = 0;

    virtual antlrcpp::Any visitEq(ifccParser::EqContext *context) = 0;

    virtual antlrcpp::Any visitNot(ifccParser::NotContext *context) = 0;

    virtual antlrcpp::Any visitCallfun(ifccParser::CallfunContext *context) = 0;

    virtual antlrcpp::Any visitGeq(ifccParser::GeqContext *context) = 0;

    virtual antlrcpp::Any visitLow(ifccParser::LowContext *context) = 0;

    virtual antlrcpp::Any visitAnd(ifccParser::AndContext *context) = 0;

    virtual antlrcpp::Any visitName(ifccParser::NameContext *context) = 0;

    virtual antlrcpp::Any visitLeq(ifccParser::LeqContext *context) = 0;

    virtual antlrcpp::Any visitXor(ifccParser::XorContext *context) = 0;

    virtual antlrcpp::Any visitNeq(ifccParser::NeqContext *context) = 0;


};

