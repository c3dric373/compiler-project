
// Generated from ifcc.g4 by ANTLR 4.7.2

#pragma once


#include "antlr4-runtime.h"
#include "ifccVisitor.h"


/**
 * This class provides an empty implementation of ifccVisitor, which can be
 * extended to create a visitor which only needs to handle a subset of the available methods.
 */
class  ifccBaseVisitor : public ifccVisitor {
public:

  virtual antlrcpp::Any visitAxiom(ifccParser::AxiomContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitProg(ifccParser::ProgContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitBlocinit(ifccParser::BlocinitContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitDeclproc(ifccParser::DeclprocContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitDeclfun(ifccParser::DeclfunContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitDefproc(ifccParser::DefprocContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitDeffun(ifccParser::DeffunContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitInt(ifccParser::IntContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitChar(ifccParser::CharContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitBlocinstr(ifccParser::BlocinstrContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitDeclint(ifccParser::DeclintContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitDeclchar(ifccParser::DeclcharContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitDeclinttab(ifccParser::DeclinttabContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitDeclchartab(ifccParser::DeclchartabContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitDefint(ifccParser::DefintContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitDefchar(ifccParser::DefcharContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAffexpr(ifccParser::AffexprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAfftab(ifccParser::AfftabContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitIfbloc(ifccParser::IfblocContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitIfelsebloc(ifccParser::IfelseblocContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitWhilebloc(ifccParser::WhileblocContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitForbloc(ifccParser::ForblocContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitInstrbloc(ifccParser::InstrblocContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitCallproc(ifccParser::CallprocContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitPutchar(ifccParser::PutcharContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitReturn(ifccParser::ReturnContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitReturnexpr(ifccParser::ReturnexprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitFordeclint(ifccParser::FordeclintContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitFordeclchar(ifccParser::FordeclcharContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitFordeclinttab(ifccParser::FordeclinttabContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitFordeclchartab(ifccParser::FordeclchartabContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitFordefint(ifccParser::FordefintContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitFordefchar(ifccParser::FordefcharContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitForaffexpr(ifccParser::ForaffexprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitForafftab(ifccParser::ForafftabContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitLoopaff(ifccParser::LoopaffContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitLoopafftab(ifccParser::LoopafftabContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitPar(ifccParser::ParContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitGetchar(ifccParser::GetcharContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAdd(ifccParser::AddContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitMinus(ifccParser::MinusContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitSub(ifccParser::SubContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitGeat(ifccParser::GeatContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitMult(ifccParser::MultContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOr(ifccParser::OrContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitConst(ifccParser::ConstContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTabaccess(ifccParser::TabaccessContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitConstchar(ifccParser::ConstcharContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitEq(ifccParser::EqContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitNot(ifccParser::NotContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitCallfun(ifccParser::CallfunContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitGeq(ifccParser::GeqContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitLow(ifccParser::LowContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAnd(ifccParser::AndContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitName(ifccParser::NameContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitLeq(ifccParser::LeqContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitXor(ifccParser::XorContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitNeq(ifccParser::NeqContext *ctx) override {
    return visitChildren(ctx);
  }


};

