
// Generated from ifcc.g4 by ANTLR 4.7.2


#include "ifccVisitor.h"

#include "ifccParser.h"


using namespace antlrcpp;
using namespace antlr4;

ifccParser::ifccParser(TokenStream *input) : Parser(input) {
  _interpreter = new atn::ParserATNSimulator(this, _atn, _decisionToDFA, _sharedContextCache);
}

ifccParser::~ifccParser() {
  delete _interpreter;
}

std::string ifccParser::getGrammarFileName() const {
  return "ifcc.g4";
}

const std::vector<std::string>& ifccParser::getRuleNames() const {
  return _ruleNames;
}

dfa::Vocabulary& ifccParser::getVocabulary() const {
  return _vocabulary;
}


//----------------- AxiomContext ------------------------------------------------------------------

ifccParser::AxiomContext::AxiomContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

ifccParser::ProgContext* ifccParser::AxiomContext::prog() {
  return getRuleContext<ifccParser::ProgContext>(0);
}


size_t ifccParser::AxiomContext::getRuleIndex() const {
  return ifccParser::RuleAxiom;
}

antlrcpp::Any ifccParser::AxiomContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitAxiom(this);
  else
    return visitor->visitChildren(this);
}

ifccParser::AxiomContext* ifccParser::axiom() {
  AxiomContext *_localctx = _tracker.createInstance<AxiomContext>(_ctx, getState());
  enterRule(_localctx, 0, ifccParser::RuleAxiom);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(20);
    prog();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ProgContext ------------------------------------------------------------------

ifccParser::ProgContext::ProgContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

ifccParser::InitblocContext* ifccParser::ProgContext::initbloc() {
  return getRuleContext<ifccParser::InitblocContext>(0);
}

tree::TerminalNode* ifccParser::ProgContext::OPENPAR() {
  return getToken(ifccParser::OPENPAR, 0);
}

tree::TerminalNode* ifccParser::ProgContext::CLOSEPAR() {
  return getToken(ifccParser::CLOSEPAR, 0);
}

tree::TerminalNode* ifccParser::ProgContext::OPENBRACE() {
  return getToken(ifccParser::OPENBRACE, 0);
}

ifccParser::BlocContext* ifccParser::ProgContext::bloc() {
  return getRuleContext<ifccParser::BlocContext>(0);
}

tree::TerminalNode* ifccParser::ProgContext::CLOSEBRACE() {
  return getToken(ifccParser::CLOSEBRACE, 0);
}


size_t ifccParser::ProgContext::getRuleIndex() const {
  return ifccParser::RuleProg;
}

antlrcpp::Any ifccParser::ProgContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitProg(this);
  else
    return visitor->visitChildren(this);
}

ifccParser::ProgContext* ifccParser::prog() {
  ProgContext *_localctx = _tracker.createInstance<ProgContext>(_ctx, getState());
  enterRule(_localctx, 2, ifccParser::RuleProg);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(22);
    initbloc();
    setState(23);
    match(ifccParser::T__0);
    setState(24);
    match(ifccParser::T__1);
    setState(25);
    match(ifccParser::OPENPAR);
    setState(26);
    match(ifccParser::CLOSEPAR);
    setState(27);
    match(ifccParser::OPENBRACE);
    setState(28);
    bloc();
    setState(29);
    match(ifccParser::CLOSEBRACE);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- InitblocContext ------------------------------------------------------------------

ifccParser::InitblocContext::InitblocContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t ifccParser::InitblocContext::getRuleIndex() const {
  return ifccParser::RuleInitbloc;
}

void ifccParser::InitblocContext::copyFrom(InitblocContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- BlocinitContext ------------------------------------------------------------------

std::vector<ifccParser::InitfunContext *> ifccParser::BlocinitContext::initfun() {
  return getRuleContexts<ifccParser::InitfunContext>();
}

ifccParser::InitfunContext* ifccParser::BlocinitContext::initfun(size_t i) {
  return getRuleContext<ifccParser::InitfunContext>(i);
}

ifccParser::BlocinitContext::BlocinitContext(InitblocContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::BlocinitContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitBlocinit(this);
  else
    return visitor->visitChildren(this);
}
ifccParser::InitblocContext* ifccParser::initbloc() {
  InitblocContext *_localctx = _tracker.createInstance<InitblocContext>(_ctx, getState());
  enterRule(_localctx, 4, ifccParser::RuleInitbloc);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    size_t alt;
    _localctx = dynamic_cast<InitblocContext *>(_tracker.createInstance<ifccParser::BlocinitContext>(_localctx));
    enterOuterAlt(_localctx, 1);
    setState(34);
    _errHandler->sync(this);
    alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 0, _ctx);
    while (alt != 2 && alt != atn::ATN::INVALID_ALT_NUMBER) {
      if (alt == 1) {
        setState(31);
        initfun(); 
      }
      setState(36);
      _errHandler->sync(this);
      alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 0, _ctx);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- InitfunContext ------------------------------------------------------------------

ifccParser::InitfunContext::InitfunContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t ifccParser::InitfunContext::getRuleIndex() const {
  return ifccParser::RuleInitfun;
}

void ifccParser::InitfunContext::copyFrom(InitfunContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- DeclprocContext ------------------------------------------------------------------

std::vector<tree::TerminalNode *> ifccParser::DeclprocContext::NAME() {
  return getTokens(ifccParser::NAME);
}

tree::TerminalNode* ifccParser::DeclprocContext::NAME(size_t i) {
  return getToken(ifccParser::NAME, i);
}

tree::TerminalNode* ifccParser::DeclprocContext::OPENPAR() {
  return getToken(ifccParser::OPENPAR, 0);
}

tree::TerminalNode* ifccParser::DeclprocContext::CLOSEPAR() {
  return getToken(ifccParser::CLOSEPAR, 0);
}

std::vector<ifccParser::TypeContext *> ifccParser::DeclprocContext::type() {
  return getRuleContexts<ifccParser::TypeContext>();
}

ifccParser::TypeContext* ifccParser::DeclprocContext::type(size_t i) {
  return getRuleContext<ifccParser::TypeContext>(i);
}

ifccParser::DeclprocContext::DeclprocContext(InitfunContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::DeclprocContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitDeclproc(this);
  else
    return visitor->visitChildren(this);
}
//----------------- DefprocContext ------------------------------------------------------------------

std::vector<tree::TerminalNode *> ifccParser::DefprocContext::NAME() {
  return getTokens(ifccParser::NAME);
}

tree::TerminalNode* ifccParser::DefprocContext::NAME(size_t i) {
  return getToken(ifccParser::NAME, i);
}

tree::TerminalNode* ifccParser::DefprocContext::OPENPAR() {
  return getToken(ifccParser::OPENPAR, 0);
}

tree::TerminalNode* ifccParser::DefprocContext::CLOSEPAR() {
  return getToken(ifccParser::CLOSEPAR, 0);
}

tree::TerminalNode* ifccParser::DefprocContext::OPENBRACE() {
  return getToken(ifccParser::OPENBRACE, 0);
}

ifccParser::BlocContext* ifccParser::DefprocContext::bloc() {
  return getRuleContext<ifccParser::BlocContext>(0);
}

tree::TerminalNode* ifccParser::DefprocContext::CLOSEBRACE() {
  return getToken(ifccParser::CLOSEBRACE, 0);
}

std::vector<ifccParser::TypeContext *> ifccParser::DefprocContext::type() {
  return getRuleContexts<ifccParser::TypeContext>();
}

ifccParser::TypeContext* ifccParser::DefprocContext::type(size_t i) {
  return getRuleContext<ifccParser::TypeContext>(i);
}

ifccParser::DefprocContext::DefprocContext(InitfunContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::DefprocContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitDefproc(this);
  else
    return visitor->visitChildren(this);
}
//----------------- DeffunContext ------------------------------------------------------------------

std::vector<ifccParser::TypeContext *> ifccParser::DeffunContext::type() {
  return getRuleContexts<ifccParser::TypeContext>();
}

ifccParser::TypeContext* ifccParser::DeffunContext::type(size_t i) {
  return getRuleContext<ifccParser::TypeContext>(i);
}

std::vector<tree::TerminalNode *> ifccParser::DeffunContext::NAME() {
  return getTokens(ifccParser::NAME);
}

tree::TerminalNode* ifccParser::DeffunContext::NAME(size_t i) {
  return getToken(ifccParser::NAME, i);
}

tree::TerminalNode* ifccParser::DeffunContext::OPENPAR() {
  return getToken(ifccParser::OPENPAR, 0);
}

tree::TerminalNode* ifccParser::DeffunContext::CLOSEPAR() {
  return getToken(ifccParser::CLOSEPAR, 0);
}

tree::TerminalNode* ifccParser::DeffunContext::OPENBRACE() {
  return getToken(ifccParser::OPENBRACE, 0);
}

ifccParser::BlocContext* ifccParser::DeffunContext::bloc() {
  return getRuleContext<ifccParser::BlocContext>(0);
}

tree::TerminalNode* ifccParser::DeffunContext::CLOSEBRACE() {
  return getToken(ifccParser::CLOSEBRACE, 0);
}

ifccParser::DeffunContext::DeffunContext(InitfunContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::DeffunContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitDeffun(this);
  else
    return visitor->visitChildren(this);
}
//----------------- DeclfunContext ------------------------------------------------------------------

std::vector<ifccParser::TypeContext *> ifccParser::DeclfunContext::type() {
  return getRuleContexts<ifccParser::TypeContext>();
}

ifccParser::TypeContext* ifccParser::DeclfunContext::type(size_t i) {
  return getRuleContext<ifccParser::TypeContext>(i);
}

std::vector<tree::TerminalNode *> ifccParser::DeclfunContext::NAME() {
  return getTokens(ifccParser::NAME);
}

tree::TerminalNode* ifccParser::DeclfunContext::NAME(size_t i) {
  return getToken(ifccParser::NAME, i);
}

tree::TerminalNode* ifccParser::DeclfunContext::OPENPAR() {
  return getToken(ifccParser::OPENPAR, 0);
}

tree::TerminalNode* ifccParser::DeclfunContext::CLOSEPAR() {
  return getToken(ifccParser::CLOSEPAR, 0);
}

ifccParser::DeclfunContext::DeclfunContext(InitfunContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::DeclfunContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitDeclfun(this);
  else
    return visitor->visitChildren(this);
}
ifccParser::InitfunContext* ifccParser::initfun() {
  InitfunContext *_localctx = _tracker.createInstance<InitfunContext>(_ctx, getState());
  enterRule(_localctx, 6, ifccParser::RuleInitfun);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(116);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 9, _ctx)) {
    case 1: {
      _localctx = dynamic_cast<InitfunContext *>(_tracker.createInstance<ifccParser::DeclprocContext>(_localctx));
      enterOuterAlt(_localctx, 1);
      setState(37);
      match(ifccParser::T__2);
      setState(38);
      match(ifccParser::NAME);
      setState(39);
      match(ifccParser::OPENPAR);
      setState(51);
      _errHandler->sync(this);

      _la = _input->LA(1);
      if (_la == ifccParser::T__0

      || _la == ifccParser::T__5) {
        setState(40);
        type();
        setState(41);
        match(ifccParser::NAME);
        setState(48);
        _errHandler->sync(this);
        _la = _input->LA(1);
        while (_la == ifccParser::T__3) {
          setState(42);
          match(ifccParser::T__3);
          setState(43);
          type();
          setState(44);
          match(ifccParser::NAME);
          setState(50);
          _errHandler->sync(this);
          _la = _input->LA(1);
        }
      }
      setState(53);
      match(ifccParser::CLOSEPAR);
      setState(54);
      match(ifccParser::T__4);
      break;
    }

    case 2: {
      _localctx = dynamic_cast<InitfunContext *>(_tracker.createInstance<ifccParser::DeclfunContext>(_localctx));
      enterOuterAlt(_localctx, 2);
      setState(55);
      type();
      setState(56);
      match(ifccParser::NAME);
      setState(57);
      match(ifccParser::OPENPAR);
      setState(69);
      _errHandler->sync(this);

      _la = _input->LA(1);
      if (_la == ifccParser::T__0

      || _la == ifccParser::T__5) {
        setState(58);
        type();
        setState(59);
        match(ifccParser::NAME);
        setState(66);
        _errHandler->sync(this);
        _la = _input->LA(1);
        while (_la == ifccParser::T__3) {
          setState(60);
          match(ifccParser::T__3);
          setState(61);
          type();
          setState(62);
          match(ifccParser::NAME);
          setState(68);
          _errHandler->sync(this);
          _la = _input->LA(1);
        }
      }
      setState(71);
      match(ifccParser::CLOSEPAR);
      setState(72);
      match(ifccParser::T__4);
      break;
    }

    case 3: {
      _localctx = dynamic_cast<InitfunContext *>(_tracker.createInstance<ifccParser::DefprocContext>(_localctx));
      enterOuterAlt(_localctx, 3);
      setState(74);
      match(ifccParser::T__2);
      setState(75);
      match(ifccParser::NAME);
      setState(76);
      match(ifccParser::OPENPAR);
      setState(88);
      _errHandler->sync(this);

      _la = _input->LA(1);
      if (_la == ifccParser::T__0

      || _la == ifccParser::T__5) {
        setState(77);
        type();
        setState(78);
        match(ifccParser::NAME);
        setState(85);
        _errHandler->sync(this);
        _la = _input->LA(1);
        while (_la == ifccParser::T__3) {
          setState(79);
          match(ifccParser::T__3);
          setState(80);
          type();
          setState(81);
          match(ifccParser::NAME);
          setState(87);
          _errHandler->sync(this);
          _la = _input->LA(1);
        }
      }
      setState(90);
      match(ifccParser::CLOSEPAR);
      setState(91);
      match(ifccParser::OPENBRACE);
      setState(92);
      bloc();
      setState(93);
      match(ifccParser::CLOSEBRACE);
      break;
    }

    case 4: {
      _localctx = dynamic_cast<InitfunContext *>(_tracker.createInstance<ifccParser::DeffunContext>(_localctx));
      enterOuterAlt(_localctx, 4);
      setState(95);
      type();
      setState(96);
      match(ifccParser::NAME);
      setState(97);
      match(ifccParser::OPENPAR);
      setState(109);
      _errHandler->sync(this);

      _la = _input->LA(1);
      if (_la == ifccParser::T__0

      || _la == ifccParser::T__5) {
        setState(98);
        type();
        setState(99);
        match(ifccParser::NAME);
        setState(106);
        _errHandler->sync(this);
        _la = _input->LA(1);
        while (_la == ifccParser::T__3) {
          setState(100);
          match(ifccParser::T__3);
          setState(101);
          type();
          setState(102);
          match(ifccParser::NAME);
          setState(108);
          _errHandler->sync(this);
          _la = _input->LA(1);
        }
      }
      setState(111);
      match(ifccParser::CLOSEPAR);
      setState(112);
      match(ifccParser::OPENBRACE);
      setState(113);
      bloc();
      setState(114);
      match(ifccParser::CLOSEBRACE);
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- TypeContext ------------------------------------------------------------------

ifccParser::TypeContext::TypeContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t ifccParser::TypeContext::getRuleIndex() const {
  return ifccParser::RuleType;
}

void ifccParser::TypeContext::copyFrom(TypeContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- CharContext ------------------------------------------------------------------

ifccParser::CharContext::CharContext(TypeContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::CharContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitChar(this);
  else
    return visitor->visitChildren(this);
}
//----------------- IntContext ------------------------------------------------------------------

ifccParser::IntContext::IntContext(TypeContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::IntContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitInt(this);
  else
    return visitor->visitChildren(this);
}
ifccParser::TypeContext* ifccParser::type() {
  TypeContext *_localctx = _tracker.createInstance<TypeContext>(_ctx, getState());
  enterRule(_localctx, 8, ifccParser::RuleType);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(120);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case ifccParser::T__0: {
        _localctx = dynamic_cast<TypeContext *>(_tracker.createInstance<ifccParser::IntContext>(_localctx));
        enterOuterAlt(_localctx, 1);
        setState(118);
        match(ifccParser::T__0);
        break;
      }

      case ifccParser::T__5: {
        _localctx = dynamic_cast<TypeContext *>(_tracker.createInstance<ifccParser::CharContext>(_localctx));
        enterOuterAlt(_localctx, 2);
        setState(119);
        match(ifccParser::T__5);
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- BlocContext ------------------------------------------------------------------

ifccParser::BlocContext::BlocContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t ifccParser::BlocContext::getRuleIndex() const {
  return ifccParser::RuleBloc;
}

void ifccParser::BlocContext::copyFrom(BlocContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- BlocinstrContext ------------------------------------------------------------------

std::vector<ifccParser::InstrContext *> ifccParser::BlocinstrContext::instr() {
  return getRuleContexts<ifccParser::InstrContext>();
}

ifccParser::InstrContext* ifccParser::BlocinstrContext::instr(size_t i) {
  return getRuleContext<ifccParser::InstrContext>(i);
}

ifccParser::BlocinstrContext::BlocinstrContext(BlocContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::BlocinstrContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitBlocinstr(this);
  else
    return visitor->visitChildren(this);
}
ifccParser::BlocContext* ifccParser::bloc() {
  BlocContext *_localctx = _tracker.createInstance<BlocContext>(_ctx, getState());
  enterRule(_localctx, 10, ifccParser::RuleBloc);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    _localctx = dynamic_cast<BlocContext *>(_tracker.createInstance<ifccParser::BlocinstrContext>(_localctx));
    enterOuterAlt(_localctx, 1);
    setState(125);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while ((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << ifccParser::T__0)
      | (1ULL << ifccParser::T__5)
      | (1ULL << ifccParser::T__9)
      | (1ULL << ifccParser::T__11)
      | (1ULL << ifccParser::T__12)
      | (1ULL << ifccParser::T__13)
      | (1ULL << ifccParser::OPENBRACE)
      | (1ULL << ifccParser::RETURN)
      | (1ULL << ifccParser::NAME))) != 0)) {
      setState(122);
      instr();
      setState(127);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- InstrContext ------------------------------------------------------------------

ifccParser::InstrContext::InstrContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t ifccParser::InstrContext::getRuleIndex() const {
  return ifccParser::RuleInstr;
}

void ifccParser::InstrContext::copyFrom(InstrContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- AffexprContext ------------------------------------------------------------------

tree::TerminalNode* ifccParser::AffexprContext::NAME() {
  return getToken(ifccParser::NAME, 0);
}

ifccParser::ExprContext* ifccParser::AffexprContext::expr() {
  return getRuleContext<ifccParser::ExprContext>(0);
}

ifccParser::AffexprContext::AffexprContext(InstrContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::AffexprContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitAffexpr(this);
  else
    return visitor->visitChildren(this);
}
//----------------- IfelseblocContext ------------------------------------------------------------------

tree::TerminalNode* ifccParser::IfelseblocContext::OPENPAR() {
  return getToken(ifccParser::OPENPAR, 0);
}

ifccParser::ExprContext* ifccParser::IfelseblocContext::expr() {
  return getRuleContext<ifccParser::ExprContext>(0);
}

tree::TerminalNode* ifccParser::IfelseblocContext::CLOSEPAR() {
  return getToken(ifccParser::CLOSEPAR, 0);
}

std::vector<tree::TerminalNode *> ifccParser::IfelseblocContext::OPENBRACE() {
  return getTokens(ifccParser::OPENBRACE);
}

tree::TerminalNode* ifccParser::IfelseblocContext::OPENBRACE(size_t i) {
  return getToken(ifccParser::OPENBRACE, i);
}

std::vector<ifccParser::BlocContext *> ifccParser::IfelseblocContext::bloc() {
  return getRuleContexts<ifccParser::BlocContext>();
}

ifccParser::BlocContext* ifccParser::IfelseblocContext::bloc(size_t i) {
  return getRuleContext<ifccParser::BlocContext>(i);
}

std::vector<tree::TerminalNode *> ifccParser::IfelseblocContext::CLOSEBRACE() {
  return getTokens(ifccParser::CLOSEBRACE);
}

tree::TerminalNode* ifccParser::IfelseblocContext::CLOSEBRACE(size_t i) {
  return getToken(ifccParser::CLOSEBRACE, i);
}

ifccParser::IfelseblocContext::IfelseblocContext(InstrContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::IfelseblocContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitIfelsebloc(this);
  else
    return visitor->visitChildren(this);
}
//----------------- IfblocContext ------------------------------------------------------------------

tree::TerminalNode* ifccParser::IfblocContext::OPENPAR() {
  return getToken(ifccParser::OPENPAR, 0);
}

ifccParser::ExprContext* ifccParser::IfblocContext::expr() {
  return getRuleContext<ifccParser::ExprContext>(0);
}

tree::TerminalNode* ifccParser::IfblocContext::CLOSEPAR() {
  return getToken(ifccParser::CLOSEPAR, 0);
}

tree::TerminalNode* ifccParser::IfblocContext::OPENBRACE() {
  return getToken(ifccParser::OPENBRACE, 0);
}

ifccParser::BlocContext* ifccParser::IfblocContext::bloc() {
  return getRuleContext<ifccParser::BlocContext>(0);
}

tree::TerminalNode* ifccParser::IfblocContext::CLOSEBRACE() {
  return getToken(ifccParser::CLOSEBRACE, 0);
}

ifccParser::IfblocContext::IfblocContext(InstrContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::IfblocContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitIfbloc(this);
  else
    return visitor->visitChildren(this);
}
//----------------- DeclinttabContext ------------------------------------------------------------------

tree::TerminalNode* ifccParser::DeclinttabContext::NAME() {
  return getToken(ifccParser::NAME, 0);
}

ifccParser::ExprContext* ifccParser::DeclinttabContext::expr() {
  return getRuleContext<ifccParser::ExprContext>(0);
}

ifccParser::DeclinttabContext::DeclinttabContext(InstrContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::DeclinttabContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitDeclinttab(this);
  else
    return visitor->visitChildren(this);
}
//----------------- DeclchartabContext ------------------------------------------------------------------

tree::TerminalNode* ifccParser::DeclchartabContext::NAME() {
  return getToken(ifccParser::NAME, 0);
}

ifccParser::ExprContext* ifccParser::DeclchartabContext::expr() {
  return getRuleContext<ifccParser::ExprContext>(0);
}

ifccParser::DeclchartabContext::DeclchartabContext(InstrContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::DeclchartabContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitDeclchartab(this);
  else
    return visitor->visitChildren(this);
}
//----------------- AfftabContext ------------------------------------------------------------------

tree::TerminalNode* ifccParser::AfftabContext::NAME() {
  return getToken(ifccParser::NAME, 0);
}

std::vector<ifccParser::ExprContext *> ifccParser::AfftabContext::expr() {
  return getRuleContexts<ifccParser::ExprContext>();
}

ifccParser::ExprContext* ifccParser::AfftabContext::expr(size_t i) {
  return getRuleContext<ifccParser::ExprContext>(i);
}

ifccParser::AfftabContext::AfftabContext(InstrContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::AfftabContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitAfftab(this);
  else
    return visitor->visitChildren(this);
}
//----------------- DefintContext ------------------------------------------------------------------

tree::TerminalNode* ifccParser::DefintContext::NAME() {
  return getToken(ifccParser::NAME, 0);
}

ifccParser::ExprContext* ifccParser::DefintContext::expr() {
  return getRuleContext<ifccParser::ExprContext>(0);
}

ifccParser::DefintContext::DefintContext(InstrContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::DefintContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitDefint(this);
  else
    return visitor->visitChildren(this);
}
//----------------- DeclintContext ------------------------------------------------------------------

std::vector<tree::TerminalNode *> ifccParser::DeclintContext::NAME() {
  return getTokens(ifccParser::NAME);
}

tree::TerminalNode* ifccParser::DeclintContext::NAME(size_t i) {
  return getToken(ifccParser::NAME, i);
}

ifccParser::DeclintContext::DeclintContext(InstrContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::DeclintContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitDeclint(this);
  else
    return visitor->visitChildren(this);
}
//----------------- InstrblocContext ------------------------------------------------------------------

tree::TerminalNode* ifccParser::InstrblocContext::OPENBRACE() {
  return getToken(ifccParser::OPENBRACE, 0);
}

ifccParser::BlocContext* ifccParser::InstrblocContext::bloc() {
  return getRuleContext<ifccParser::BlocContext>(0);
}

tree::TerminalNode* ifccParser::InstrblocContext::CLOSEBRACE() {
  return getToken(ifccParser::CLOSEBRACE, 0);
}

ifccParser::InstrblocContext::InstrblocContext(InstrContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::InstrblocContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitInstrbloc(this);
  else
    return visitor->visitChildren(this);
}
//----------------- DefcharContext ------------------------------------------------------------------

tree::TerminalNode* ifccParser::DefcharContext::NAME() {
  return getToken(ifccParser::NAME, 0);
}

ifccParser::ExprContext* ifccParser::DefcharContext::expr() {
  return getRuleContext<ifccParser::ExprContext>(0);
}

ifccParser::DefcharContext::DefcharContext(InstrContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::DefcharContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitDefchar(this);
  else
    return visitor->visitChildren(this);
}
//----------------- WhileblocContext ------------------------------------------------------------------

tree::TerminalNode* ifccParser::WhileblocContext::OPENPAR() {
  return getToken(ifccParser::OPENPAR, 0);
}

ifccParser::ExprContext* ifccParser::WhileblocContext::expr() {
  return getRuleContext<ifccParser::ExprContext>(0);
}

tree::TerminalNode* ifccParser::WhileblocContext::CLOSEPAR() {
  return getToken(ifccParser::CLOSEPAR, 0);
}

tree::TerminalNode* ifccParser::WhileblocContext::OPENBRACE() {
  return getToken(ifccParser::OPENBRACE, 0);
}

ifccParser::BlocContext* ifccParser::WhileblocContext::bloc() {
  return getRuleContext<ifccParser::BlocContext>(0);
}

tree::TerminalNode* ifccParser::WhileblocContext::CLOSEBRACE() {
  return getToken(ifccParser::CLOSEBRACE, 0);
}

ifccParser::WhileblocContext::WhileblocContext(InstrContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::WhileblocContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitWhilebloc(this);
  else
    return visitor->visitChildren(this);
}
//----------------- CallprocContext ------------------------------------------------------------------

std::vector<tree::TerminalNode *> ifccParser::CallprocContext::NAME() {
  return getTokens(ifccParser::NAME);
}

tree::TerminalNode* ifccParser::CallprocContext::NAME(size_t i) {
  return getToken(ifccParser::NAME, i);
}

tree::TerminalNode* ifccParser::CallprocContext::OPENPAR() {
  return getToken(ifccParser::OPENPAR, 0);
}

tree::TerminalNode* ifccParser::CallprocContext::CLOSEPAR() {
  return getToken(ifccParser::CLOSEPAR, 0);
}

ifccParser::CallprocContext::CallprocContext(InstrContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::CallprocContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitCallproc(this);
  else
    return visitor->visitChildren(this);
}
//----------------- PutcharContext ------------------------------------------------------------------

tree::TerminalNode* ifccParser::PutcharContext::OPENPAR() {
  return getToken(ifccParser::OPENPAR, 0);
}

tree::TerminalNode* ifccParser::PutcharContext::NAME() {
  return getToken(ifccParser::NAME, 0);
}

tree::TerminalNode* ifccParser::PutcharContext::CLOSEPAR() {
  return getToken(ifccParser::CLOSEPAR, 0);
}

ifccParser::PutcharContext::PutcharContext(InstrContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::PutcharContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitPutchar(this);
  else
    return visitor->visitChildren(this);
}
//----------------- DeclcharContext ------------------------------------------------------------------

std::vector<tree::TerminalNode *> ifccParser::DeclcharContext::NAME() {
  return getTokens(ifccParser::NAME);
}

tree::TerminalNode* ifccParser::DeclcharContext::NAME(size_t i) {
  return getToken(ifccParser::NAME, i);
}

ifccParser::DeclcharContext::DeclcharContext(InstrContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::DeclcharContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitDeclchar(this);
  else
    return visitor->visitChildren(this);
}
//----------------- ForblocContext ------------------------------------------------------------------

tree::TerminalNode* ifccParser::ForblocContext::OPENPAR() {
  return getToken(ifccParser::OPENPAR, 0);
}

tree::TerminalNode* ifccParser::ForblocContext::CLOSEPAR() {
  return getToken(ifccParser::CLOSEPAR, 0);
}

tree::TerminalNode* ifccParser::ForblocContext::OPENBRACE() {
  return getToken(ifccParser::OPENBRACE, 0);
}

ifccParser::BlocContext* ifccParser::ForblocContext::bloc() {
  return getRuleContext<ifccParser::BlocContext>(0);
}

tree::TerminalNode* ifccParser::ForblocContext::CLOSEBRACE() {
  return getToken(ifccParser::CLOSEBRACE, 0);
}

ifccParser::InitforContext* ifccParser::ForblocContext::initfor() {
  return getRuleContext<ifccParser::InitforContext>(0);
}

ifccParser::ExprContext* ifccParser::ForblocContext::expr() {
  return getRuleContext<ifccParser::ExprContext>(0);
}

std::vector<ifccParser::LoopinstrContext *> ifccParser::ForblocContext::loopinstr() {
  return getRuleContexts<ifccParser::LoopinstrContext>();
}

ifccParser::LoopinstrContext* ifccParser::ForblocContext::loopinstr(size_t i) {
  return getRuleContext<ifccParser::LoopinstrContext>(i);
}

ifccParser::ForblocContext::ForblocContext(InstrContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::ForblocContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitForbloc(this);
  else
    return visitor->visitChildren(this);
}
//----------------- ReturnContext ------------------------------------------------------------------

tree::TerminalNode* ifccParser::ReturnContext::RETURN() {
  return getToken(ifccParser::RETURN, 0);
}

ifccParser::ReturnContext::ReturnContext(InstrContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::ReturnContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitReturn(this);
  else
    return visitor->visitChildren(this);
}
//----------------- ReturnexprContext ------------------------------------------------------------------

tree::TerminalNode* ifccParser::ReturnexprContext::RETURN() {
  return getToken(ifccParser::RETURN, 0);
}

ifccParser::ExprContext* ifccParser::ReturnexprContext::expr() {
  return getRuleContext<ifccParser::ExprContext>(0);
}

ifccParser::ReturnexprContext::ReturnexprContext(InstrContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::ReturnexprContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitReturnexpr(this);
  else
    return visitor->visitChildren(this);
}
ifccParser::InstrContext* ifccParser::instr() {
  InstrContext *_localctx = _tracker.createInstance<InstrContext>(_ctx, getState());
  enterRule(_localctx, 12, ifccParser::RuleInstr);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(269);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 20, _ctx)) {
    case 1: {
      _localctx = dynamic_cast<InstrContext *>(_tracker.createInstance<ifccParser::DeclintContext>(_localctx));
      enterOuterAlt(_localctx, 1);
      setState(128);
      match(ifccParser::T__0);
      setState(129);
      match(ifccParser::NAME);
      setState(134);
      _errHandler->sync(this);
      _la = _input->LA(1);
      while (_la == ifccParser::T__3) {
        setState(130);
        match(ifccParser::T__3);
        setState(131);
        match(ifccParser::NAME);
        setState(136);
        _errHandler->sync(this);
        _la = _input->LA(1);
      }
      setState(137);
      match(ifccParser::T__4);
      break;
    }

    case 2: {
      _localctx = dynamic_cast<InstrContext *>(_tracker.createInstance<ifccParser::DeclcharContext>(_localctx));
      enterOuterAlt(_localctx, 2);
      setState(138);
      match(ifccParser::T__5);
      setState(139);
      match(ifccParser::NAME);
      setState(144);
      _errHandler->sync(this);
      _la = _input->LA(1);
      while (_la == ifccParser::T__3) {
        setState(140);
        match(ifccParser::T__3);
        setState(141);
        match(ifccParser::NAME);
        setState(146);
        _errHandler->sync(this);
        _la = _input->LA(1);
      }
      setState(147);
      match(ifccParser::T__4);
      break;
    }

    case 3: {
      _localctx = dynamic_cast<InstrContext *>(_tracker.createInstance<ifccParser::DeclinttabContext>(_localctx));
      enterOuterAlt(_localctx, 3);
      setState(148);
      match(ifccParser::T__0);
      setState(149);
      match(ifccParser::NAME);
      setState(150);
      match(ifccParser::T__6);
      setState(151);
      expr(0);
      setState(152);
      match(ifccParser::T__7);
      setState(153);
      match(ifccParser::T__4);
      break;
    }

    case 4: {
      _localctx = dynamic_cast<InstrContext *>(_tracker.createInstance<ifccParser::DeclchartabContext>(_localctx));
      enterOuterAlt(_localctx, 4);
      setState(155);
      match(ifccParser::T__5);
      setState(156);
      match(ifccParser::NAME);
      setState(157);
      match(ifccParser::T__6);
      setState(158);
      expr(0);
      setState(159);
      match(ifccParser::T__7);
      setState(160);
      match(ifccParser::T__4);
      break;
    }

    case 5: {
      _localctx = dynamic_cast<InstrContext *>(_tracker.createInstance<ifccParser::DefintContext>(_localctx));
      enterOuterAlt(_localctx, 5);
      setState(162);
      match(ifccParser::T__0);
      setState(163);
      match(ifccParser::NAME);
      setState(164);
      match(ifccParser::T__8);
      setState(165);
      expr(0);
      setState(166);
      match(ifccParser::T__4);
      break;
    }

    case 6: {
      _localctx = dynamic_cast<InstrContext *>(_tracker.createInstance<ifccParser::DefcharContext>(_localctx));
      enterOuterAlt(_localctx, 6);
      setState(168);
      match(ifccParser::T__5);
      setState(169);
      match(ifccParser::NAME);
      setState(170);
      match(ifccParser::T__8);
      setState(171);
      expr(0);
      setState(172);
      match(ifccParser::T__4);
      break;
    }

    case 7: {
      _localctx = dynamic_cast<InstrContext *>(_tracker.createInstance<ifccParser::AffexprContext>(_localctx));
      enterOuterAlt(_localctx, 7);
      setState(174);
      match(ifccParser::NAME);
      setState(175);
      match(ifccParser::T__8);
      setState(176);
      expr(0);
      setState(177);
      match(ifccParser::T__4);
      break;
    }

    case 8: {
      _localctx = dynamic_cast<InstrContext *>(_tracker.createInstance<ifccParser::AfftabContext>(_localctx));
      enterOuterAlt(_localctx, 8);
      setState(179);
      match(ifccParser::NAME);
      setState(180);
      match(ifccParser::T__6);
      setState(181);
      expr(0);
      setState(182);
      match(ifccParser::T__7);
      setState(183);
      match(ifccParser::T__8);
      setState(184);
      expr(0);
      setState(185);
      match(ifccParser::T__4);
      break;
    }

    case 9: {
      _localctx = dynamic_cast<InstrContext *>(_tracker.createInstance<ifccParser::IfblocContext>(_localctx));
      enterOuterAlt(_localctx, 9);
      setState(187);
      match(ifccParser::T__9);
      setState(188);
      match(ifccParser::OPENPAR);
      setState(189);
      expr(0);
      setState(190);
      match(ifccParser::CLOSEPAR);
      setState(191);
      match(ifccParser::OPENBRACE);
      setState(192);
      bloc();
      setState(193);
      match(ifccParser::CLOSEBRACE);
      break;
    }

    case 10: {
      _localctx = dynamic_cast<InstrContext *>(_tracker.createInstance<ifccParser::IfelseblocContext>(_localctx));
      enterOuterAlt(_localctx, 10);
      setState(195);
      match(ifccParser::T__9);
      setState(196);
      match(ifccParser::OPENPAR);
      setState(197);
      expr(0);
      setState(198);
      match(ifccParser::CLOSEPAR);
      setState(199);
      match(ifccParser::OPENBRACE);
      setState(200);
      bloc();
      setState(201);
      match(ifccParser::CLOSEBRACE);
      setState(202);
      match(ifccParser::T__10);
      setState(203);
      match(ifccParser::OPENBRACE);
      setState(204);
      bloc();
      setState(205);
      match(ifccParser::CLOSEBRACE);
      break;
    }

    case 11: {
      _localctx = dynamic_cast<InstrContext *>(_tracker.createInstance<ifccParser::WhileblocContext>(_localctx));
      enterOuterAlt(_localctx, 11);
      setState(207);
      match(ifccParser::T__11);
      setState(208);
      match(ifccParser::OPENPAR);
      setState(209);
      expr(0);
      setState(210);
      match(ifccParser::CLOSEPAR);
      setState(211);
      match(ifccParser::OPENBRACE);
      setState(212);
      bloc();
      setState(213);
      match(ifccParser::CLOSEBRACE);
      break;
    }

    case 12: {
      _localctx = dynamic_cast<InstrContext *>(_tracker.createInstance<ifccParser::ForblocContext>(_localctx));
      enterOuterAlt(_localctx, 12);
      setState(215);
      match(ifccParser::T__12);
      setState(216);
      match(ifccParser::OPENPAR);
      setState(218);
      _errHandler->sync(this);

      _la = _input->LA(1);
      if ((((_la & ~ 0x3fULL) == 0) &&
        ((1ULL << _la) & ((1ULL << ifccParser::T__0)
        | (1ULL << ifccParser::T__5)
        | (1ULL << ifccParser::NAME))) != 0)) {
        setState(217);
        initfor();
      }
      setState(220);
      match(ifccParser::T__4);
      setState(222);
      _errHandler->sync(this);

      _la = _input->LA(1);
      if ((((_la & ~ 0x3fULL) == 0) &&
        ((1ULL << _la) & ((1ULL << ifccParser::T__14)
        | (1ULL << ifccParser::T__17)
        | (1ULL << ifccParser::T__27)
        | (1ULL << ifccParser::OPENPAR)
        | (1ULL << ifccParser::CONST)
        | (1ULL << ifccParser::CONSTCHAR)
        | (1ULL << ifccParser::NAME))) != 0)) {
        setState(221);
        expr(0);
      }
      setState(224);
      match(ifccParser::T__4);
      setState(233);
      _errHandler->sync(this);

      _la = _input->LA(1);
      if (_la == ifccParser::NAME) {
        setState(225);
        loopinstr();
        setState(230);
        _errHandler->sync(this);
        _la = _input->LA(1);
        while (_la == ifccParser::T__3) {
          setState(226);
          match(ifccParser::T__3);
          setState(227);
          loopinstr();
          setState(232);
          _errHandler->sync(this);
          _la = _input->LA(1);
        }
      }
      setState(235);
      match(ifccParser::CLOSEPAR);
      setState(236);
      match(ifccParser::OPENBRACE);
      setState(237);
      bloc();
      setState(238);
      match(ifccParser::CLOSEBRACE);
      break;
    }

    case 13: {
      _localctx = dynamic_cast<InstrContext *>(_tracker.createInstance<ifccParser::InstrblocContext>(_localctx));
      enterOuterAlt(_localctx, 13);
      setState(240);
      match(ifccParser::OPENBRACE);
      setState(241);
      bloc();
      setState(242);
      match(ifccParser::CLOSEBRACE);
      break;
    }

    case 14: {
      _localctx = dynamic_cast<InstrContext *>(_tracker.createInstance<ifccParser::CallprocContext>(_localctx));
      enterOuterAlt(_localctx, 14);
      setState(244);
      match(ifccParser::NAME);
      setState(245);
      match(ifccParser::OPENPAR);
      setState(254);
      _errHandler->sync(this);

      _la = _input->LA(1);
      if (_la == ifccParser::NAME) {
        setState(246);
        match(ifccParser::NAME);
        setState(251);
        _errHandler->sync(this);
        _la = _input->LA(1);
        while (_la == ifccParser::T__3) {
          setState(247);
          match(ifccParser::T__3);
          setState(248);
          match(ifccParser::NAME);
          setState(253);
          _errHandler->sync(this);
          _la = _input->LA(1);
        }
      }
      setState(256);
      match(ifccParser::CLOSEPAR);
      setState(257);
      match(ifccParser::T__4);
      break;
    }

    case 15: {
      _localctx = dynamic_cast<InstrContext *>(_tracker.createInstance<ifccParser::PutcharContext>(_localctx));
      enterOuterAlt(_localctx, 15);
      setState(258);
      match(ifccParser::T__13);
      setState(259);
      match(ifccParser::OPENPAR);
      setState(260);
      match(ifccParser::NAME);
      setState(261);
      match(ifccParser::CLOSEPAR);
      setState(262);
      match(ifccParser::T__4);
      break;
    }

    case 16: {
      _localctx = dynamic_cast<InstrContext *>(_tracker.createInstance<ifccParser::ReturnContext>(_localctx));
      enterOuterAlt(_localctx, 16);
      setState(263);
      match(ifccParser::RETURN);
      setState(264);
      match(ifccParser::T__4);
      break;
    }

    case 17: {
      _localctx = dynamic_cast<InstrContext *>(_tracker.createInstance<ifccParser::ReturnexprContext>(_localctx));
      enterOuterAlt(_localctx, 17);
      setState(265);
      match(ifccParser::RETURN);
      setState(266);
      expr(0);
      setState(267);
      match(ifccParser::T__4);
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- InitforContext ------------------------------------------------------------------

ifccParser::InitforContext::InitforContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t ifccParser::InitforContext::getRuleIndex() const {
  return ifccParser::RuleInitfor;
}

void ifccParser::InitforContext::copyFrom(InitforContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- FordeclinttabContext ------------------------------------------------------------------

tree::TerminalNode* ifccParser::FordeclinttabContext::NAME() {
  return getToken(ifccParser::NAME, 0);
}

ifccParser::ExprContext* ifccParser::FordeclinttabContext::expr() {
  return getRuleContext<ifccParser::ExprContext>(0);
}

ifccParser::FordeclinttabContext::FordeclinttabContext(InitforContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::FordeclinttabContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitFordeclinttab(this);
  else
    return visitor->visitChildren(this);
}
//----------------- FordeclchartabContext ------------------------------------------------------------------

tree::TerminalNode* ifccParser::FordeclchartabContext::NAME() {
  return getToken(ifccParser::NAME, 0);
}

ifccParser::ExprContext* ifccParser::FordeclchartabContext::expr() {
  return getRuleContext<ifccParser::ExprContext>(0);
}

ifccParser::FordeclchartabContext::FordeclchartabContext(InitforContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::FordeclchartabContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitFordeclchartab(this);
  else
    return visitor->visitChildren(this);
}
//----------------- ForaffexprContext ------------------------------------------------------------------

tree::TerminalNode* ifccParser::ForaffexprContext::NAME() {
  return getToken(ifccParser::NAME, 0);
}

ifccParser::ExprContext* ifccParser::ForaffexprContext::expr() {
  return getRuleContext<ifccParser::ExprContext>(0);
}

ifccParser::ForaffexprContext::ForaffexprContext(InitforContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::ForaffexprContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitForaffexpr(this);
  else
    return visitor->visitChildren(this);
}
//----------------- FordeclcharContext ------------------------------------------------------------------

std::vector<tree::TerminalNode *> ifccParser::FordeclcharContext::NAME() {
  return getTokens(ifccParser::NAME);
}

tree::TerminalNode* ifccParser::FordeclcharContext::NAME(size_t i) {
  return getToken(ifccParser::NAME, i);
}

ifccParser::FordeclcharContext::FordeclcharContext(InitforContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::FordeclcharContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitFordeclchar(this);
  else
    return visitor->visitChildren(this);
}
//----------------- FordefintContext ------------------------------------------------------------------

tree::TerminalNode* ifccParser::FordefintContext::NAME() {
  return getToken(ifccParser::NAME, 0);
}

ifccParser::ExprContext* ifccParser::FordefintContext::expr() {
  return getRuleContext<ifccParser::ExprContext>(0);
}

ifccParser::FordefintContext::FordefintContext(InitforContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::FordefintContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitFordefint(this);
  else
    return visitor->visitChildren(this);
}
//----------------- FordefcharContext ------------------------------------------------------------------

tree::TerminalNode* ifccParser::FordefcharContext::NAME() {
  return getToken(ifccParser::NAME, 0);
}

ifccParser::ExprContext* ifccParser::FordefcharContext::expr() {
  return getRuleContext<ifccParser::ExprContext>(0);
}

ifccParser::FordefcharContext::FordefcharContext(InitforContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::FordefcharContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitFordefchar(this);
  else
    return visitor->visitChildren(this);
}
//----------------- ForafftabContext ------------------------------------------------------------------

tree::TerminalNode* ifccParser::ForafftabContext::NAME() {
  return getToken(ifccParser::NAME, 0);
}

std::vector<ifccParser::ExprContext *> ifccParser::ForafftabContext::expr() {
  return getRuleContexts<ifccParser::ExprContext>();
}

ifccParser::ExprContext* ifccParser::ForafftabContext::expr(size_t i) {
  return getRuleContext<ifccParser::ExprContext>(i);
}

ifccParser::ForafftabContext::ForafftabContext(InitforContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::ForafftabContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitForafftab(this);
  else
    return visitor->visitChildren(this);
}
//----------------- FordeclintContext ------------------------------------------------------------------

std::vector<tree::TerminalNode *> ifccParser::FordeclintContext::NAME() {
  return getTokens(ifccParser::NAME);
}

tree::TerminalNode* ifccParser::FordeclintContext::NAME(size_t i) {
  return getToken(ifccParser::NAME, i);
}

ifccParser::FordeclintContext::FordeclintContext(InitforContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::FordeclintContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitFordeclint(this);
  else
    return visitor->visitChildren(this);
}
ifccParser::InitforContext* ifccParser::initfor() {
  InitforContext *_localctx = _tracker.createInstance<InitforContext>(_ctx, getState());
  enterRule(_localctx, 14, ifccParser::RuleInitfor);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(319);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 23, _ctx)) {
    case 1: {
      _localctx = dynamic_cast<InitforContext *>(_tracker.createInstance<ifccParser::FordeclintContext>(_localctx));
      enterOuterAlt(_localctx, 1);
      setState(271);
      match(ifccParser::T__0);
      setState(272);
      match(ifccParser::NAME);
      setState(277);
      _errHandler->sync(this);
      _la = _input->LA(1);
      while (_la == ifccParser::T__3) {
        setState(273);
        match(ifccParser::T__3);
        setState(274);
        match(ifccParser::NAME);
        setState(279);
        _errHandler->sync(this);
        _la = _input->LA(1);
      }
      break;
    }

    case 2: {
      _localctx = dynamic_cast<InitforContext *>(_tracker.createInstance<ifccParser::FordeclcharContext>(_localctx));
      enterOuterAlt(_localctx, 2);
      setState(280);
      match(ifccParser::T__5);
      setState(281);
      match(ifccParser::NAME);
      setState(286);
      _errHandler->sync(this);
      _la = _input->LA(1);
      while (_la == ifccParser::T__3) {
        setState(282);
        match(ifccParser::T__3);
        setState(283);
        match(ifccParser::NAME);
        setState(288);
        _errHandler->sync(this);
        _la = _input->LA(1);
      }
      break;
    }

    case 3: {
      _localctx = dynamic_cast<InitforContext *>(_tracker.createInstance<ifccParser::FordeclinttabContext>(_localctx));
      enterOuterAlt(_localctx, 3);
      setState(289);
      match(ifccParser::T__0);
      setState(290);
      match(ifccParser::NAME);
      setState(291);
      match(ifccParser::T__6);
      setState(292);
      expr(0);
      setState(293);
      match(ifccParser::T__7);
      break;
    }

    case 4: {
      _localctx = dynamic_cast<InitforContext *>(_tracker.createInstance<ifccParser::FordeclchartabContext>(_localctx));
      enterOuterAlt(_localctx, 4);
      setState(295);
      match(ifccParser::T__5);
      setState(296);
      match(ifccParser::NAME);
      setState(297);
      match(ifccParser::T__6);
      setState(298);
      expr(0);
      setState(299);
      match(ifccParser::T__7);
      break;
    }

    case 5: {
      _localctx = dynamic_cast<InitforContext *>(_tracker.createInstance<ifccParser::FordefintContext>(_localctx));
      enterOuterAlt(_localctx, 5);
      setState(301);
      match(ifccParser::T__0);
      setState(302);
      match(ifccParser::NAME);
      setState(303);
      match(ifccParser::T__8);
      setState(304);
      expr(0);
      break;
    }

    case 6: {
      _localctx = dynamic_cast<InitforContext *>(_tracker.createInstance<ifccParser::FordefcharContext>(_localctx));
      enterOuterAlt(_localctx, 6);
      setState(305);
      match(ifccParser::T__5);
      setState(306);
      match(ifccParser::NAME);
      setState(307);
      match(ifccParser::T__8);
      setState(308);
      expr(0);
      break;
    }

    case 7: {
      _localctx = dynamic_cast<InitforContext *>(_tracker.createInstance<ifccParser::ForaffexprContext>(_localctx));
      enterOuterAlt(_localctx, 7);
      setState(309);
      match(ifccParser::NAME);
      setState(310);
      match(ifccParser::T__8);
      setState(311);
      expr(0);
      break;
    }

    case 8: {
      _localctx = dynamic_cast<InitforContext *>(_tracker.createInstance<ifccParser::ForafftabContext>(_localctx));
      enterOuterAlt(_localctx, 8);
      setState(312);
      match(ifccParser::NAME);
      setState(313);
      match(ifccParser::T__6);
      setState(314);
      expr(0);
      setState(315);
      match(ifccParser::T__7);
      setState(316);
      match(ifccParser::T__8);
      setState(317);
      expr(0);
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- LoopinstrContext ------------------------------------------------------------------

ifccParser::LoopinstrContext::LoopinstrContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t ifccParser::LoopinstrContext::getRuleIndex() const {
  return ifccParser::RuleLoopinstr;
}

void ifccParser::LoopinstrContext::copyFrom(LoopinstrContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- LoopaffContext ------------------------------------------------------------------

tree::TerminalNode* ifccParser::LoopaffContext::NAME() {
  return getToken(ifccParser::NAME, 0);
}

ifccParser::ExprContext* ifccParser::LoopaffContext::expr() {
  return getRuleContext<ifccParser::ExprContext>(0);
}

ifccParser::LoopaffContext::LoopaffContext(LoopinstrContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::LoopaffContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitLoopaff(this);
  else
    return visitor->visitChildren(this);
}
//----------------- LoopafftabContext ------------------------------------------------------------------

tree::TerminalNode* ifccParser::LoopafftabContext::NAME() {
  return getToken(ifccParser::NAME, 0);
}

std::vector<ifccParser::ExprContext *> ifccParser::LoopafftabContext::expr() {
  return getRuleContexts<ifccParser::ExprContext>();
}

ifccParser::ExprContext* ifccParser::LoopafftabContext::expr(size_t i) {
  return getRuleContext<ifccParser::ExprContext>(i);
}

ifccParser::LoopafftabContext::LoopafftabContext(LoopinstrContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::LoopafftabContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitLoopafftab(this);
  else
    return visitor->visitChildren(this);
}
ifccParser::LoopinstrContext* ifccParser::loopinstr() {
  LoopinstrContext *_localctx = _tracker.createInstance<LoopinstrContext>(_ctx, getState());
  enterRule(_localctx, 16, ifccParser::RuleLoopinstr);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(331);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 24, _ctx)) {
    case 1: {
      _localctx = dynamic_cast<LoopinstrContext *>(_tracker.createInstance<ifccParser::LoopaffContext>(_localctx));
      enterOuterAlt(_localctx, 1);
      setState(321);
      match(ifccParser::NAME);
      setState(322);
      match(ifccParser::T__8);
      setState(323);
      expr(0);
      break;
    }

    case 2: {
      _localctx = dynamic_cast<LoopinstrContext *>(_tracker.createInstance<ifccParser::LoopafftabContext>(_localctx));
      enterOuterAlt(_localctx, 2);
      setState(324);
      match(ifccParser::NAME);
      setState(325);
      match(ifccParser::T__6);
      setState(326);
      expr(0);
      setState(327);
      match(ifccParser::T__7);
      setState(328);
      match(ifccParser::T__8);
      setState(329);
      expr(0);
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ExprContext ------------------------------------------------------------------

ifccParser::ExprContext::ExprContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t ifccParser::ExprContext::getRuleIndex() const {
  return ifccParser::RuleExpr;
}

void ifccParser::ExprContext::copyFrom(ExprContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- ParContext ------------------------------------------------------------------

tree::TerminalNode* ifccParser::ParContext::OPENPAR() {
  return getToken(ifccParser::OPENPAR, 0);
}

ifccParser::ExprContext* ifccParser::ParContext::expr() {
  return getRuleContext<ifccParser::ExprContext>(0);
}

tree::TerminalNode* ifccParser::ParContext::CLOSEPAR() {
  return getToken(ifccParser::CLOSEPAR, 0);
}

ifccParser::ParContext::ParContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::ParContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitPar(this);
  else
    return visitor->visitChildren(this);
}
//----------------- GetcharContext ------------------------------------------------------------------

tree::TerminalNode* ifccParser::GetcharContext::OPENPAR() {
  return getToken(ifccParser::OPENPAR, 0);
}

tree::TerminalNode* ifccParser::GetcharContext::CLOSEPAR() {
  return getToken(ifccParser::CLOSEPAR, 0);
}

ifccParser::GetcharContext::GetcharContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::GetcharContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitGetchar(this);
  else
    return visitor->visitChildren(this);
}
//----------------- AddContext ------------------------------------------------------------------

std::vector<ifccParser::ExprContext *> ifccParser::AddContext::expr() {
  return getRuleContexts<ifccParser::ExprContext>();
}

ifccParser::ExprContext* ifccParser::AddContext::expr(size_t i) {
  return getRuleContext<ifccParser::ExprContext>(i);
}

ifccParser::AddContext::AddContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::AddContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitAdd(this);
  else
    return visitor->visitChildren(this);
}
//----------------- MinusContext ------------------------------------------------------------------

ifccParser::ExprContext* ifccParser::MinusContext::expr() {
  return getRuleContext<ifccParser::ExprContext>(0);
}

ifccParser::MinusContext::MinusContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::MinusContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitMinus(this);
  else
    return visitor->visitChildren(this);
}
//----------------- SubContext ------------------------------------------------------------------

std::vector<ifccParser::ExprContext *> ifccParser::SubContext::expr() {
  return getRuleContexts<ifccParser::ExprContext>();
}

ifccParser::ExprContext* ifccParser::SubContext::expr(size_t i) {
  return getRuleContext<ifccParser::ExprContext>(i);
}

ifccParser::SubContext::SubContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::SubContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitSub(this);
  else
    return visitor->visitChildren(this);
}
//----------------- GeatContext ------------------------------------------------------------------

std::vector<ifccParser::ExprContext *> ifccParser::GeatContext::expr() {
  return getRuleContexts<ifccParser::ExprContext>();
}

ifccParser::ExprContext* ifccParser::GeatContext::expr(size_t i) {
  return getRuleContext<ifccParser::ExprContext>(i);
}

ifccParser::GeatContext::GeatContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::GeatContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitGeat(this);
  else
    return visitor->visitChildren(this);
}
//----------------- MultContext ------------------------------------------------------------------

std::vector<ifccParser::ExprContext *> ifccParser::MultContext::expr() {
  return getRuleContexts<ifccParser::ExprContext>();
}

ifccParser::ExprContext* ifccParser::MultContext::expr(size_t i) {
  return getRuleContext<ifccParser::ExprContext>(i);
}

ifccParser::MultContext::MultContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::MultContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitMult(this);
  else
    return visitor->visitChildren(this);
}
//----------------- OrContext ------------------------------------------------------------------

std::vector<ifccParser::ExprContext *> ifccParser::OrContext::expr() {
  return getRuleContexts<ifccParser::ExprContext>();
}

ifccParser::ExprContext* ifccParser::OrContext::expr(size_t i) {
  return getRuleContext<ifccParser::ExprContext>(i);
}

ifccParser::OrContext::OrContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::OrContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitOr(this);
  else
    return visitor->visitChildren(this);
}
//----------------- ConstContext ------------------------------------------------------------------

tree::TerminalNode* ifccParser::ConstContext::CONST() {
  return getToken(ifccParser::CONST, 0);
}

ifccParser::ConstContext::ConstContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::ConstContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitConst(this);
  else
    return visitor->visitChildren(this);
}
//----------------- TabaccessContext ------------------------------------------------------------------

tree::TerminalNode* ifccParser::TabaccessContext::NAME() {
  return getToken(ifccParser::NAME, 0);
}

ifccParser::ExprContext* ifccParser::TabaccessContext::expr() {
  return getRuleContext<ifccParser::ExprContext>(0);
}

ifccParser::TabaccessContext::TabaccessContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::TabaccessContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitTabaccess(this);
  else
    return visitor->visitChildren(this);
}
//----------------- ConstcharContext ------------------------------------------------------------------

tree::TerminalNode* ifccParser::ConstcharContext::CONSTCHAR() {
  return getToken(ifccParser::CONSTCHAR, 0);
}

ifccParser::ConstcharContext::ConstcharContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::ConstcharContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitConstchar(this);
  else
    return visitor->visitChildren(this);
}
//----------------- EqContext ------------------------------------------------------------------

std::vector<ifccParser::ExprContext *> ifccParser::EqContext::expr() {
  return getRuleContexts<ifccParser::ExprContext>();
}

ifccParser::ExprContext* ifccParser::EqContext::expr(size_t i) {
  return getRuleContext<ifccParser::ExprContext>(i);
}

ifccParser::EqContext::EqContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::EqContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitEq(this);
  else
    return visitor->visitChildren(this);
}
//----------------- NotContext ------------------------------------------------------------------

ifccParser::ExprContext* ifccParser::NotContext::expr() {
  return getRuleContext<ifccParser::ExprContext>(0);
}

ifccParser::NotContext::NotContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::NotContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitNot(this);
  else
    return visitor->visitChildren(this);
}
//----------------- CallfunContext ------------------------------------------------------------------

std::vector<tree::TerminalNode *> ifccParser::CallfunContext::NAME() {
  return getTokens(ifccParser::NAME);
}

tree::TerminalNode* ifccParser::CallfunContext::NAME(size_t i) {
  return getToken(ifccParser::NAME, i);
}

tree::TerminalNode* ifccParser::CallfunContext::OPENPAR() {
  return getToken(ifccParser::OPENPAR, 0);
}

tree::TerminalNode* ifccParser::CallfunContext::CLOSEPAR() {
  return getToken(ifccParser::CLOSEPAR, 0);
}

ifccParser::CallfunContext::CallfunContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::CallfunContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitCallfun(this);
  else
    return visitor->visitChildren(this);
}
//----------------- GeqContext ------------------------------------------------------------------

std::vector<ifccParser::ExprContext *> ifccParser::GeqContext::expr() {
  return getRuleContexts<ifccParser::ExprContext>();
}

ifccParser::ExprContext* ifccParser::GeqContext::expr(size_t i) {
  return getRuleContext<ifccParser::ExprContext>(i);
}

ifccParser::GeqContext::GeqContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::GeqContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitGeq(this);
  else
    return visitor->visitChildren(this);
}
//----------------- LowContext ------------------------------------------------------------------

std::vector<ifccParser::ExprContext *> ifccParser::LowContext::expr() {
  return getRuleContexts<ifccParser::ExprContext>();
}

ifccParser::ExprContext* ifccParser::LowContext::expr(size_t i) {
  return getRuleContext<ifccParser::ExprContext>(i);
}

ifccParser::LowContext::LowContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::LowContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitLow(this);
  else
    return visitor->visitChildren(this);
}
//----------------- AndContext ------------------------------------------------------------------

std::vector<ifccParser::ExprContext *> ifccParser::AndContext::expr() {
  return getRuleContexts<ifccParser::ExprContext>();
}

ifccParser::ExprContext* ifccParser::AndContext::expr(size_t i) {
  return getRuleContext<ifccParser::ExprContext>(i);
}

ifccParser::AndContext::AndContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::AndContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitAnd(this);
  else
    return visitor->visitChildren(this);
}
//----------------- NameContext ------------------------------------------------------------------

tree::TerminalNode* ifccParser::NameContext::NAME() {
  return getToken(ifccParser::NAME, 0);
}

ifccParser::NameContext::NameContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::NameContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitName(this);
  else
    return visitor->visitChildren(this);
}
//----------------- LeqContext ------------------------------------------------------------------

std::vector<ifccParser::ExprContext *> ifccParser::LeqContext::expr() {
  return getRuleContexts<ifccParser::ExprContext>();
}

ifccParser::ExprContext* ifccParser::LeqContext::expr(size_t i) {
  return getRuleContext<ifccParser::ExprContext>(i);
}

ifccParser::LeqContext::LeqContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::LeqContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitLeq(this);
  else
    return visitor->visitChildren(this);
}
//----------------- XorContext ------------------------------------------------------------------

std::vector<ifccParser::ExprContext *> ifccParser::XorContext::expr() {
  return getRuleContexts<ifccParser::ExprContext>();
}

ifccParser::ExprContext* ifccParser::XorContext::expr(size_t i) {
  return getRuleContext<ifccParser::ExprContext>(i);
}

ifccParser::XorContext::XorContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::XorContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitXor(this);
  else
    return visitor->visitChildren(this);
}
//----------------- NeqContext ------------------------------------------------------------------

std::vector<ifccParser::ExprContext *> ifccParser::NeqContext::expr() {
  return getRuleContexts<ifccParser::ExprContext>();
}

ifccParser::ExprContext* ifccParser::NeqContext::expr(size_t i) {
  return getRuleContext<ifccParser::ExprContext>(i);
}

ifccParser::NeqContext::NeqContext(ExprContext *ctx) { copyFrom(ctx); }

antlrcpp::Any ifccParser::NeqContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<ifccVisitor*>(visitor))
    return parserVisitor->visitNeq(this);
  else
    return visitor->visitChildren(this);
}

ifccParser::ExprContext* ifccParser::expr() {
   return expr(0);
}

ifccParser::ExprContext* ifccParser::expr(int precedence) {
  ParserRuleContext *parentContext = _ctx;
  size_t parentState = getState();
  ifccParser::ExprContext *_localctx = _tracker.createInstance<ExprContext>(_ctx, parentState);
  ifccParser::ExprContext *previousContext = _localctx;
  (void)previousContext; // Silence compiler, in case the context is not used by generated code.
  size_t startState = 18;
  enterRecursionRule(_localctx, 18, ifccParser::RuleExpr, precedence);

    size_t _la = 0;

  auto onExit = finally([=] {
    unrollRecursionContexts(parentContext);
  });
  try {
    size_t alt;
    enterOuterAlt(_localctx, 1);
    setState(366);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 27, _ctx)) {
    case 1: {
      _localctx = _tracker.createInstance<ParContext>(_localctx);
      _ctx = _localctx;
      previousContext = _localctx;

      setState(334);
      match(ifccParser::OPENPAR);
      setState(335);
      expr(0);
      setState(336);
      match(ifccParser::CLOSEPAR);
      break;
    }

    case 2: {
      _localctx = _tracker.createInstance<MinusContext>(_localctx);
      _ctx = _localctx;
      previousContext = _localctx;
      setState(338);
      match(ifccParser::T__14);
      setState(339);
      expr(20);
      break;
    }

    case 3: {
      _localctx = _tracker.createInstance<NotContext>(_localctx);
      _ctx = _localctx;
      previousContext = _localctx;
      setState(340);
      match(ifccParser::T__17);
      setState(341);
      expr(16);
      break;
    }

    case 4: {
      _localctx = _tracker.createInstance<CallfunContext>(_localctx);
      _ctx = _localctx;
      previousContext = _localctx;
      setState(342);
      match(ifccParser::NAME);
      setState(343);
      match(ifccParser::OPENPAR);
      setState(352);
      _errHandler->sync(this);

      _la = _input->LA(1);
      if (_la == ifccParser::NAME) {
        setState(344);
        match(ifccParser::NAME);
        setState(349);
        _errHandler->sync(this);
        _la = _input->LA(1);
        while (_la == ifccParser::T__3) {
          setState(345);
          match(ifccParser::T__3);
          setState(346);
          match(ifccParser::NAME);
          setState(351);
          _errHandler->sync(this);
          _la = _input->LA(1);
        }
      }
      setState(354);
      match(ifccParser::CLOSEPAR);
      break;
    }

    case 5: {
      _localctx = _tracker.createInstance<GetcharContext>(_localctx);
      _ctx = _localctx;
      previousContext = _localctx;
      setState(355);
      match(ifccParser::T__27);
      setState(356);
      match(ifccParser::OPENPAR);
      setState(357);
      match(ifccParser::CLOSEPAR);
      break;
    }

    case 6: {
      _localctx = _tracker.createInstance<ConstContext>(_localctx);
      _ctx = _localctx;
      previousContext = _localctx;
      setState(358);
      match(ifccParser::CONST);
      break;
    }

    case 7: {
      _localctx = _tracker.createInstance<ConstcharContext>(_localctx);
      _ctx = _localctx;
      previousContext = _localctx;
      setState(359);
      match(ifccParser::CONSTCHAR);
      break;
    }

    case 8: {
      _localctx = _tracker.createInstance<NameContext>(_localctx);
      _ctx = _localctx;
      previousContext = _localctx;
      setState(360);
      match(ifccParser::NAME);
      break;
    }

    case 9: {
      _localctx = _tracker.createInstance<TabaccessContext>(_localctx);
      _ctx = _localctx;
      previousContext = _localctx;
      setState(361);
      match(ifccParser::NAME);
      setState(362);
      match(ifccParser::T__6);
      setState(363);
      expr(0);
      setState(364);
      match(ifccParser::T__7);
      break;
    }

    }
    _ctx->stop = _input->LT(-1);
    setState(406);
    _errHandler->sync(this);
    alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 29, _ctx);
    while (alt != 2 && alt != atn::ATN::INVALID_ALT_NUMBER) {
      if (alt == 1) {
        if (!_parseListeners.empty())
          triggerExitRuleEvent();
        previousContext = _localctx;
        setState(404);
        _errHandler->sync(this);
        switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 28, _ctx)) {
        case 1: {
          auto newContext = _tracker.createInstance<MultContext>(_tracker.createInstance<ExprContext>(parentContext, parentState));
          _localctx = newContext;
          pushNewRecursionContext(newContext, startState, RuleExpr);
          setState(368);

          if (!(precpred(_ctx, 19))) throw FailedPredicateException(this, "precpred(_ctx, 19)");
          setState(369);
          match(ifccParser::T__15);
          setState(370);
          expr(20);
          break;
        }

        case 2: {
          auto newContext = _tracker.createInstance<SubContext>(_tracker.createInstance<ExprContext>(parentContext, parentState));
          _localctx = newContext;
          pushNewRecursionContext(newContext, startState, RuleExpr);
          setState(371);

          if (!(precpred(_ctx, 18))) throw FailedPredicateException(this, "precpred(_ctx, 18)");
          setState(372);
          match(ifccParser::T__14);
          setState(373);
          expr(19);
          break;
        }

        case 3: {
          auto newContext = _tracker.createInstance<AddContext>(_tracker.createInstance<ExprContext>(parentContext, parentState));
          _localctx = newContext;
          pushNewRecursionContext(newContext, startState, RuleExpr);
          setState(374);

          if (!(precpred(_ctx, 17))) throw FailedPredicateException(this, "precpred(_ctx, 17)");
          setState(375);
          match(ifccParser::T__16);
          setState(376);
          expr(18);
          break;
        }

        case 4: {
          auto newContext = _tracker.createInstance<EqContext>(_tracker.createInstance<ExprContext>(parentContext, parentState));
          _localctx = newContext;
          pushNewRecursionContext(newContext, startState, RuleExpr);
          setState(377);

          if (!(precpred(_ctx, 15))) throw FailedPredicateException(this, "precpred(_ctx, 15)");
          setState(378);
          match(ifccParser::T__18);
          setState(379);
          expr(16);
          break;
        }

        case 5: {
          auto newContext = _tracker.createInstance<NeqContext>(_tracker.createInstance<ExprContext>(parentContext, parentState));
          _localctx = newContext;
          pushNewRecursionContext(newContext, startState, RuleExpr);
          setState(380);

          if (!(precpred(_ctx, 14))) throw FailedPredicateException(this, "precpred(_ctx, 14)");
          setState(381);
          match(ifccParser::T__19);
          setState(382);
          expr(15);
          break;
        }

        case 6: {
          auto newContext = _tracker.createInstance<LeqContext>(_tracker.createInstance<ExprContext>(parentContext, parentState));
          _localctx = newContext;
          pushNewRecursionContext(newContext, startState, RuleExpr);
          setState(383);

          if (!(precpred(_ctx, 13))) throw FailedPredicateException(this, "precpred(_ctx, 13)");
          setState(384);
          match(ifccParser::T__20);
          setState(385);
          expr(14);
          break;
        }

        case 7: {
          auto newContext = _tracker.createInstance<GeqContext>(_tracker.createInstance<ExprContext>(parentContext, parentState));
          _localctx = newContext;
          pushNewRecursionContext(newContext, startState, RuleExpr);
          setState(386);

          if (!(precpred(_ctx, 12))) throw FailedPredicateException(this, "precpred(_ctx, 12)");
          setState(387);
          match(ifccParser::T__21);
          setState(388);
          expr(13);
          break;
        }

        case 8: {
          auto newContext = _tracker.createInstance<LowContext>(_tracker.createInstance<ExprContext>(parentContext, parentState));
          _localctx = newContext;
          pushNewRecursionContext(newContext, startState, RuleExpr);
          setState(389);

          if (!(precpred(_ctx, 11))) throw FailedPredicateException(this, "precpred(_ctx, 11)");
          setState(390);
          match(ifccParser::T__22);
          setState(391);
          expr(12);
          break;
        }

        case 9: {
          auto newContext = _tracker.createInstance<GeatContext>(_tracker.createInstance<ExprContext>(parentContext, parentState));
          _localctx = newContext;
          pushNewRecursionContext(newContext, startState, RuleExpr);
          setState(392);

          if (!(precpred(_ctx, 10))) throw FailedPredicateException(this, "precpred(_ctx, 10)");
          setState(393);
          match(ifccParser::T__23);
          setState(394);
          expr(11);
          break;
        }

        case 10: {
          auto newContext = _tracker.createInstance<AndContext>(_tracker.createInstance<ExprContext>(parentContext, parentState));
          _localctx = newContext;
          pushNewRecursionContext(newContext, startState, RuleExpr);
          setState(395);

          if (!(precpred(_ctx, 9))) throw FailedPredicateException(this, "precpred(_ctx, 9)");
          setState(396);
          match(ifccParser::T__24);
          setState(397);
          expr(10);
          break;
        }

        case 11: {
          auto newContext = _tracker.createInstance<XorContext>(_tracker.createInstance<ExprContext>(parentContext, parentState));
          _localctx = newContext;
          pushNewRecursionContext(newContext, startState, RuleExpr);
          setState(398);

          if (!(precpred(_ctx, 8))) throw FailedPredicateException(this, "precpred(_ctx, 8)");
          setState(399);
          match(ifccParser::T__25);
          setState(400);
          expr(9);
          break;
        }

        case 12: {
          auto newContext = _tracker.createInstance<OrContext>(_tracker.createInstance<ExprContext>(parentContext, parentState));
          _localctx = newContext;
          pushNewRecursionContext(newContext, startState, RuleExpr);
          setState(401);

          if (!(precpred(_ctx, 7))) throw FailedPredicateException(this, "precpred(_ctx, 7)");
          setState(402);
          match(ifccParser::T__26);
          setState(403);
          expr(8);
          break;
        }

        } 
      }
      setState(408);
      _errHandler->sync(this);
      alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 29, _ctx);
    }
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }
  return _localctx;
}

bool ifccParser::sempred(RuleContext *context, size_t ruleIndex, size_t predicateIndex) {
  switch (ruleIndex) {
    case 9: return exprSempred(dynamic_cast<ExprContext *>(context), predicateIndex);

  default:
    break;
  }
  return true;
}

bool ifccParser::exprSempred(ExprContext *_localctx, size_t predicateIndex) {
  switch (predicateIndex) {
    case 0: return precpred(_ctx, 19);
    case 1: return precpred(_ctx, 18);
    case 2: return precpred(_ctx, 17);
    case 3: return precpred(_ctx, 15);
    case 4: return precpred(_ctx, 14);
    case 5: return precpred(_ctx, 13);
    case 6: return precpred(_ctx, 12);
    case 7: return precpred(_ctx, 11);
    case 8: return precpred(_ctx, 10);
    case 9: return precpred(_ctx, 9);
    case 10: return precpred(_ctx, 8);
    case 11: return precpred(_ctx, 7);

  default:
    break;
  }
  return true;
}

// Static vars and initialization.
std::vector<dfa::DFA> ifccParser::_decisionToDFA;
atn::PredictionContextCache ifccParser::_sharedContextCache;

// We own the ATN which in turn owns the ATN states.
atn::ATN ifccParser::_atn;
std::vector<uint16_t> ifccParser::_serializedATN;

std::vector<std::string> ifccParser::_ruleNames = {
  "axiom", "prog", "initbloc", "initfun", "type", "bloc", "instr", "initfor", 
  "loopinstr", "expr"
};

std::vector<std::string> ifccParser::_literalNames = {
  "", "'int'", "'main'", "'void'", "','", "';'", "'char'", "'['", "']'", 
  "'='", "'if'", "'else'", "'while'", "'for'", "'putchar'", "'-'", "'*'", 
  "'+'", "'!'", "'=='", "'!='", "'<='", "'>='", "'<'", "'>'", "'&'", "'^'", 
  "'|'", "'getchar'", "'('", "')'", "'{'", "'}'", "'return'"
};

std::vector<std::string> ifccParser::_symbolicNames = {
  "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", 
  "", "", "", "", "", "", "", "", "", "", "", "OPENPAR", "CLOSEPAR", "OPENBRACE", 
  "CLOSEBRACE", "RETURN", "CONST", "CONSTCHAR", "NAME", "COMMENT1", "COMMENT2", 
  "DIRECTIVE", "WS"
};

dfa::Vocabulary ifccParser::_vocabulary(_literalNames, _symbolicNames);

std::vector<std::string> ifccParser::_tokenNames;

ifccParser::Initializer::Initializer() {
	for (size_t i = 0; i < _symbolicNames.size(); ++i) {
		std::string name = _vocabulary.getLiteralName(i);
		if (name.empty()) {
			name = _vocabulary.getSymbolicName(i);
		}

		if (name.empty()) {
			_tokenNames.push_back("<INVALID>");
		} else {
      _tokenNames.push_back(name);
    }
	}

  _serializedATN = {
    0x3, 0x608b, 0xa72a, 0x8133, 0xb9ed, 0x417c, 0x3be7, 0x7786, 0x5964, 
    0x3, 0x2a, 0x19c, 0x4, 0x2, 0x9, 0x2, 0x4, 0x3, 0x9, 0x3, 0x4, 0x4, 
    0x9, 0x4, 0x4, 0x5, 0x9, 0x5, 0x4, 0x6, 0x9, 0x6, 0x4, 0x7, 0x9, 0x7, 
    0x4, 0x8, 0x9, 0x8, 0x4, 0x9, 0x9, 0x9, 0x4, 0xa, 0x9, 0xa, 0x4, 0xb, 
    0x9, 0xb, 0x3, 0x2, 0x3, 0x2, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 
    0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x4, 0x7, 0x4, 
    0x23, 0xa, 0x4, 0xc, 0x4, 0xe, 0x4, 0x26, 0xb, 0x4, 0x3, 0x5, 0x3, 0x5, 
    0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 
    0x7, 0x5, 0x31, 0xa, 0x5, 0xc, 0x5, 0xe, 0x5, 0x34, 0xb, 0x5, 0x5, 0x5, 
    0x36, 0xa, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 
    0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x7, 0x5, 0x43, 
    0xa, 0x5, 0xc, 0x5, 0xe, 0x5, 0x46, 0xb, 0x5, 0x5, 0x5, 0x48, 0xa, 0x5, 
    0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 
    0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x7, 0x5, 0x56, 0xa, 
    0x5, 0xc, 0x5, 0xe, 0x5, 0x59, 0xb, 0x5, 0x5, 0x5, 0x5b, 0xa, 0x5, 0x3, 
    0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 
    0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x7, 
    0x5, 0x6b, 0xa, 0x5, 0xc, 0x5, 0xe, 0x5, 0x6e, 0xb, 0x5, 0x5, 0x5, 0x70, 
    0xa, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x5, 0x5, 
    0x77, 0xa, 0x5, 0x3, 0x6, 0x3, 0x6, 0x5, 0x6, 0x7b, 0xa, 0x6, 0x3, 0x7, 
    0x7, 0x7, 0x7e, 0xa, 0x7, 0xc, 0x7, 0xe, 0x7, 0x81, 0xb, 0x7, 0x3, 0x8, 
    0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x7, 0x8, 0x87, 0xa, 0x8, 0xc, 0x8, 0xe, 
    0x8, 0x8a, 0xb, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 
    0x7, 0x8, 0x91, 0xa, 0x8, 0xc, 0x8, 0xe, 0x8, 0x94, 0xb, 0x8, 0x3, 0x8, 
    0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 
    0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 
    0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 
    0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 
    0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 
    0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 
    0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 
    0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 
    0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 
    0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 
    0x5, 0x8, 0xdd, 0xa, 0x8, 0x3, 0x8, 0x3, 0x8, 0x5, 0x8, 0xe1, 0xa, 0x8, 
    0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x7, 0x8, 0xe7, 0xa, 0x8, 0xc, 
    0x8, 0xe, 0x8, 0xea, 0xb, 0x8, 0x5, 0x8, 0xec, 0xa, 0x8, 0x3, 0x8, 0x3, 
    0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 
    0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x7, 0x8, 0xfc, 
    0xa, 0x8, 0xc, 0x8, 0xe, 0x8, 0xff, 0xb, 0x8, 0x5, 0x8, 0x101, 0xa, 
    0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 
    0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x5, 
    0x8, 0x110, 0xa, 0x8, 0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 0x7, 0x9, 
    0x116, 0xa, 0x9, 0xc, 0x9, 0xe, 0x9, 0x119, 0xb, 0x9, 0x3, 0x9, 0x3, 
    0x9, 0x3, 0x9, 0x3, 0x9, 0x7, 0x9, 0x11f, 0xa, 0x9, 0xc, 0x9, 0xe, 0x9, 
    0x122, 0xb, 0x9, 0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 0x3, 
    0x9, 0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 0x3, 
    0x9, 0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 0x3, 
    0x9, 0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 0x3, 
    0x9, 0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 0x5, 0x9, 0x142, 0xa, 0x9, 0x3, 0xa, 
    0x3, 0xa, 0x3, 0xa, 0x3, 0xa, 0x3, 0xa, 0x3, 0xa, 0x3, 0xa, 0x3, 0xa, 
    0x3, 0xa, 0x3, 0xa, 0x5, 0xa, 0x14e, 0xa, 0xa, 0x3, 0xb, 0x3, 0xb, 0x3, 
    0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 
    0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x7, 0xb, 0x15e, 0xa, 0xb, 
    0xc, 0xb, 0xe, 0xb, 0x161, 0xb, 0xb, 0x5, 0xb, 0x163, 0xa, 0xb, 0x3, 
    0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 
    0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x5, 0xb, 0x171, 0xa, 0xb, 
    0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 
    0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 
    0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 
    0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 
    0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 
    0x3, 0xb, 0x7, 0xb, 0x197, 0xa, 0xb, 0xc, 0xb, 0xe, 0xb, 0x19a, 0xb, 
    0xb, 0x3, 0xb, 0x2, 0x3, 0x14, 0xc, 0x2, 0x4, 0x6, 0x8, 0xa, 0xc, 0xe, 
    0x10, 0x12, 0x14, 0x2, 0x2, 0x2, 0x1d7, 0x2, 0x16, 0x3, 0x2, 0x2, 0x2, 
    0x4, 0x18, 0x3, 0x2, 0x2, 0x2, 0x6, 0x24, 0x3, 0x2, 0x2, 0x2, 0x8, 0x76, 
    0x3, 0x2, 0x2, 0x2, 0xa, 0x7a, 0x3, 0x2, 0x2, 0x2, 0xc, 0x7f, 0x3, 0x2, 
    0x2, 0x2, 0xe, 0x10f, 0x3, 0x2, 0x2, 0x2, 0x10, 0x141, 0x3, 0x2, 0x2, 
    0x2, 0x12, 0x14d, 0x3, 0x2, 0x2, 0x2, 0x14, 0x170, 0x3, 0x2, 0x2, 0x2, 
    0x16, 0x17, 0x5, 0x4, 0x3, 0x2, 0x17, 0x3, 0x3, 0x2, 0x2, 0x2, 0x18, 
    0x19, 0x5, 0x6, 0x4, 0x2, 0x19, 0x1a, 0x7, 0x3, 0x2, 0x2, 0x1a, 0x1b, 
    0x7, 0x4, 0x2, 0x2, 0x1b, 0x1c, 0x7, 0x1f, 0x2, 0x2, 0x1c, 0x1d, 0x7, 
    0x20, 0x2, 0x2, 0x1d, 0x1e, 0x7, 0x21, 0x2, 0x2, 0x1e, 0x1f, 0x5, 0xc, 
    0x7, 0x2, 0x1f, 0x20, 0x7, 0x22, 0x2, 0x2, 0x20, 0x5, 0x3, 0x2, 0x2, 
    0x2, 0x21, 0x23, 0x5, 0x8, 0x5, 0x2, 0x22, 0x21, 0x3, 0x2, 0x2, 0x2, 
    0x23, 0x26, 0x3, 0x2, 0x2, 0x2, 0x24, 0x22, 0x3, 0x2, 0x2, 0x2, 0x24, 
    0x25, 0x3, 0x2, 0x2, 0x2, 0x25, 0x7, 0x3, 0x2, 0x2, 0x2, 0x26, 0x24, 
    0x3, 0x2, 0x2, 0x2, 0x27, 0x28, 0x7, 0x5, 0x2, 0x2, 0x28, 0x29, 0x7, 
    0x26, 0x2, 0x2, 0x29, 0x35, 0x7, 0x1f, 0x2, 0x2, 0x2a, 0x2b, 0x5, 0xa, 
    0x6, 0x2, 0x2b, 0x32, 0x7, 0x26, 0x2, 0x2, 0x2c, 0x2d, 0x7, 0x6, 0x2, 
    0x2, 0x2d, 0x2e, 0x5, 0xa, 0x6, 0x2, 0x2e, 0x2f, 0x7, 0x26, 0x2, 0x2, 
    0x2f, 0x31, 0x3, 0x2, 0x2, 0x2, 0x30, 0x2c, 0x3, 0x2, 0x2, 0x2, 0x31, 
    0x34, 0x3, 0x2, 0x2, 0x2, 0x32, 0x30, 0x3, 0x2, 0x2, 0x2, 0x32, 0x33, 
    0x3, 0x2, 0x2, 0x2, 0x33, 0x36, 0x3, 0x2, 0x2, 0x2, 0x34, 0x32, 0x3, 
    0x2, 0x2, 0x2, 0x35, 0x2a, 0x3, 0x2, 0x2, 0x2, 0x35, 0x36, 0x3, 0x2, 
    0x2, 0x2, 0x36, 0x37, 0x3, 0x2, 0x2, 0x2, 0x37, 0x38, 0x7, 0x20, 0x2, 
    0x2, 0x38, 0x77, 0x7, 0x7, 0x2, 0x2, 0x39, 0x3a, 0x5, 0xa, 0x6, 0x2, 
    0x3a, 0x3b, 0x7, 0x26, 0x2, 0x2, 0x3b, 0x47, 0x7, 0x1f, 0x2, 0x2, 0x3c, 
    0x3d, 0x5, 0xa, 0x6, 0x2, 0x3d, 0x44, 0x7, 0x26, 0x2, 0x2, 0x3e, 0x3f, 
    0x7, 0x6, 0x2, 0x2, 0x3f, 0x40, 0x5, 0xa, 0x6, 0x2, 0x40, 0x41, 0x7, 
    0x26, 0x2, 0x2, 0x41, 0x43, 0x3, 0x2, 0x2, 0x2, 0x42, 0x3e, 0x3, 0x2, 
    0x2, 0x2, 0x43, 0x46, 0x3, 0x2, 0x2, 0x2, 0x44, 0x42, 0x3, 0x2, 0x2, 
    0x2, 0x44, 0x45, 0x3, 0x2, 0x2, 0x2, 0x45, 0x48, 0x3, 0x2, 0x2, 0x2, 
    0x46, 0x44, 0x3, 0x2, 0x2, 0x2, 0x47, 0x3c, 0x3, 0x2, 0x2, 0x2, 0x47, 
    0x48, 0x3, 0x2, 0x2, 0x2, 0x48, 0x49, 0x3, 0x2, 0x2, 0x2, 0x49, 0x4a, 
    0x7, 0x20, 0x2, 0x2, 0x4a, 0x4b, 0x7, 0x7, 0x2, 0x2, 0x4b, 0x77, 0x3, 
    0x2, 0x2, 0x2, 0x4c, 0x4d, 0x7, 0x5, 0x2, 0x2, 0x4d, 0x4e, 0x7, 0x26, 
    0x2, 0x2, 0x4e, 0x5a, 0x7, 0x1f, 0x2, 0x2, 0x4f, 0x50, 0x5, 0xa, 0x6, 
    0x2, 0x50, 0x57, 0x7, 0x26, 0x2, 0x2, 0x51, 0x52, 0x7, 0x6, 0x2, 0x2, 
    0x52, 0x53, 0x5, 0xa, 0x6, 0x2, 0x53, 0x54, 0x7, 0x26, 0x2, 0x2, 0x54, 
    0x56, 0x3, 0x2, 0x2, 0x2, 0x55, 0x51, 0x3, 0x2, 0x2, 0x2, 0x56, 0x59, 
    0x3, 0x2, 0x2, 0x2, 0x57, 0x55, 0x3, 0x2, 0x2, 0x2, 0x57, 0x58, 0x3, 
    0x2, 0x2, 0x2, 0x58, 0x5b, 0x3, 0x2, 0x2, 0x2, 0x59, 0x57, 0x3, 0x2, 
    0x2, 0x2, 0x5a, 0x4f, 0x3, 0x2, 0x2, 0x2, 0x5a, 0x5b, 0x3, 0x2, 0x2, 
    0x2, 0x5b, 0x5c, 0x3, 0x2, 0x2, 0x2, 0x5c, 0x5d, 0x7, 0x20, 0x2, 0x2, 
    0x5d, 0x5e, 0x7, 0x21, 0x2, 0x2, 0x5e, 0x5f, 0x5, 0xc, 0x7, 0x2, 0x5f, 
    0x60, 0x7, 0x22, 0x2, 0x2, 0x60, 0x77, 0x3, 0x2, 0x2, 0x2, 0x61, 0x62, 
    0x5, 0xa, 0x6, 0x2, 0x62, 0x63, 0x7, 0x26, 0x2, 0x2, 0x63, 0x6f, 0x7, 
    0x1f, 0x2, 0x2, 0x64, 0x65, 0x5, 0xa, 0x6, 0x2, 0x65, 0x6c, 0x7, 0x26, 
    0x2, 0x2, 0x66, 0x67, 0x7, 0x6, 0x2, 0x2, 0x67, 0x68, 0x5, 0xa, 0x6, 
    0x2, 0x68, 0x69, 0x7, 0x26, 0x2, 0x2, 0x69, 0x6b, 0x3, 0x2, 0x2, 0x2, 
    0x6a, 0x66, 0x3, 0x2, 0x2, 0x2, 0x6b, 0x6e, 0x3, 0x2, 0x2, 0x2, 0x6c, 
    0x6a, 0x3, 0x2, 0x2, 0x2, 0x6c, 0x6d, 0x3, 0x2, 0x2, 0x2, 0x6d, 0x70, 
    0x3, 0x2, 0x2, 0x2, 0x6e, 0x6c, 0x3, 0x2, 0x2, 0x2, 0x6f, 0x64, 0x3, 
    0x2, 0x2, 0x2, 0x6f, 0x70, 0x3, 0x2, 0x2, 0x2, 0x70, 0x71, 0x3, 0x2, 
    0x2, 0x2, 0x71, 0x72, 0x7, 0x20, 0x2, 0x2, 0x72, 0x73, 0x7, 0x21, 0x2, 
    0x2, 0x73, 0x74, 0x5, 0xc, 0x7, 0x2, 0x74, 0x75, 0x7, 0x22, 0x2, 0x2, 
    0x75, 0x77, 0x3, 0x2, 0x2, 0x2, 0x76, 0x27, 0x3, 0x2, 0x2, 0x2, 0x76, 
    0x39, 0x3, 0x2, 0x2, 0x2, 0x76, 0x4c, 0x3, 0x2, 0x2, 0x2, 0x76, 0x61, 
    0x3, 0x2, 0x2, 0x2, 0x77, 0x9, 0x3, 0x2, 0x2, 0x2, 0x78, 0x7b, 0x7, 
    0x3, 0x2, 0x2, 0x79, 0x7b, 0x7, 0x8, 0x2, 0x2, 0x7a, 0x78, 0x3, 0x2, 
    0x2, 0x2, 0x7a, 0x79, 0x3, 0x2, 0x2, 0x2, 0x7b, 0xb, 0x3, 0x2, 0x2, 
    0x2, 0x7c, 0x7e, 0x5, 0xe, 0x8, 0x2, 0x7d, 0x7c, 0x3, 0x2, 0x2, 0x2, 
    0x7e, 0x81, 0x3, 0x2, 0x2, 0x2, 0x7f, 0x7d, 0x3, 0x2, 0x2, 0x2, 0x7f, 
    0x80, 0x3, 0x2, 0x2, 0x2, 0x80, 0xd, 0x3, 0x2, 0x2, 0x2, 0x81, 0x7f, 
    0x3, 0x2, 0x2, 0x2, 0x82, 0x83, 0x7, 0x3, 0x2, 0x2, 0x83, 0x88, 0x7, 
    0x26, 0x2, 0x2, 0x84, 0x85, 0x7, 0x6, 0x2, 0x2, 0x85, 0x87, 0x7, 0x26, 
    0x2, 0x2, 0x86, 0x84, 0x3, 0x2, 0x2, 0x2, 0x87, 0x8a, 0x3, 0x2, 0x2, 
    0x2, 0x88, 0x86, 0x3, 0x2, 0x2, 0x2, 0x88, 0x89, 0x3, 0x2, 0x2, 0x2, 
    0x89, 0x8b, 0x3, 0x2, 0x2, 0x2, 0x8a, 0x88, 0x3, 0x2, 0x2, 0x2, 0x8b, 
    0x110, 0x7, 0x7, 0x2, 0x2, 0x8c, 0x8d, 0x7, 0x8, 0x2, 0x2, 0x8d, 0x92, 
    0x7, 0x26, 0x2, 0x2, 0x8e, 0x8f, 0x7, 0x6, 0x2, 0x2, 0x8f, 0x91, 0x7, 
    0x26, 0x2, 0x2, 0x90, 0x8e, 0x3, 0x2, 0x2, 0x2, 0x91, 0x94, 0x3, 0x2, 
    0x2, 0x2, 0x92, 0x90, 0x3, 0x2, 0x2, 0x2, 0x92, 0x93, 0x3, 0x2, 0x2, 
    0x2, 0x93, 0x95, 0x3, 0x2, 0x2, 0x2, 0x94, 0x92, 0x3, 0x2, 0x2, 0x2, 
    0x95, 0x110, 0x7, 0x7, 0x2, 0x2, 0x96, 0x97, 0x7, 0x3, 0x2, 0x2, 0x97, 
    0x98, 0x7, 0x26, 0x2, 0x2, 0x98, 0x99, 0x7, 0x9, 0x2, 0x2, 0x99, 0x9a, 
    0x5, 0x14, 0xb, 0x2, 0x9a, 0x9b, 0x7, 0xa, 0x2, 0x2, 0x9b, 0x9c, 0x7, 
    0x7, 0x2, 0x2, 0x9c, 0x110, 0x3, 0x2, 0x2, 0x2, 0x9d, 0x9e, 0x7, 0x8, 
    0x2, 0x2, 0x9e, 0x9f, 0x7, 0x26, 0x2, 0x2, 0x9f, 0xa0, 0x7, 0x9, 0x2, 
    0x2, 0xa0, 0xa1, 0x5, 0x14, 0xb, 0x2, 0xa1, 0xa2, 0x7, 0xa, 0x2, 0x2, 
    0xa2, 0xa3, 0x7, 0x7, 0x2, 0x2, 0xa3, 0x110, 0x3, 0x2, 0x2, 0x2, 0xa4, 
    0xa5, 0x7, 0x3, 0x2, 0x2, 0xa5, 0xa6, 0x7, 0x26, 0x2, 0x2, 0xa6, 0xa7, 
    0x7, 0xb, 0x2, 0x2, 0xa7, 0xa8, 0x5, 0x14, 0xb, 0x2, 0xa8, 0xa9, 0x7, 
    0x7, 0x2, 0x2, 0xa9, 0x110, 0x3, 0x2, 0x2, 0x2, 0xaa, 0xab, 0x7, 0x8, 
    0x2, 0x2, 0xab, 0xac, 0x7, 0x26, 0x2, 0x2, 0xac, 0xad, 0x7, 0xb, 0x2, 
    0x2, 0xad, 0xae, 0x5, 0x14, 0xb, 0x2, 0xae, 0xaf, 0x7, 0x7, 0x2, 0x2, 
    0xaf, 0x110, 0x3, 0x2, 0x2, 0x2, 0xb0, 0xb1, 0x7, 0x26, 0x2, 0x2, 0xb1, 
    0xb2, 0x7, 0xb, 0x2, 0x2, 0xb2, 0xb3, 0x5, 0x14, 0xb, 0x2, 0xb3, 0xb4, 
    0x7, 0x7, 0x2, 0x2, 0xb4, 0x110, 0x3, 0x2, 0x2, 0x2, 0xb5, 0xb6, 0x7, 
    0x26, 0x2, 0x2, 0xb6, 0xb7, 0x7, 0x9, 0x2, 0x2, 0xb7, 0xb8, 0x5, 0x14, 
    0xb, 0x2, 0xb8, 0xb9, 0x7, 0xa, 0x2, 0x2, 0xb9, 0xba, 0x7, 0xb, 0x2, 
    0x2, 0xba, 0xbb, 0x5, 0x14, 0xb, 0x2, 0xbb, 0xbc, 0x7, 0x7, 0x2, 0x2, 
    0xbc, 0x110, 0x3, 0x2, 0x2, 0x2, 0xbd, 0xbe, 0x7, 0xc, 0x2, 0x2, 0xbe, 
    0xbf, 0x7, 0x1f, 0x2, 0x2, 0xbf, 0xc0, 0x5, 0x14, 0xb, 0x2, 0xc0, 0xc1, 
    0x7, 0x20, 0x2, 0x2, 0xc1, 0xc2, 0x7, 0x21, 0x2, 0x2, 0xc2, 0xc3, 0x5, 
    0xc, 0x7, 0x2, 0xc3, 0xc4, 0x7, 0x22, 0x2, 0x2, 0xc4, 0x110, 0x3, 0x2, 
    0x2, 0x2, 0xc5, 0xc6, 0x7, 0xc, 0x2, 0x2, 0xc6, 0xc7, 0x7, 0x1f, 0x2, 
    0x2, 0xc7, 0xc8, 0x5, 0x14, 0xb, 0x2, 0xc8, 0xc9, 0x7, 0x20, 0x2, 0x2, 
    0xc9, 0xca, 0x7, 0x21, 0x2, 0x2, 0xca, 0xcb, 0x5, 0xc, 0x7, 0x2, 0xcb, 
    0xcc, 0x7, 0x22, 0x2, 0x2, 0xcc, 0xcd, 0x7, 0xd, 0x2, 0x2, 0xcd, 0xce, 
    0x7, 0x21, 0x2, 0x2, 0xce, 0xcf, 0x5, 0xc, 0x7, 0x2, 0xcf, 0xd0, 0x7, 
    0x22, 0x2, 0x2, 0xd0, 0x110, 0x3, 0x2, 0x2, 0x2, 0xd1, 0xd2, 0x7, 0xe, 
    0x2, 0x2, 0xd2, 0xd3, 0x7, 0x1f, 0x2, 0x2, 0xd3, 0xd4, 0x5, 0x14, 0xb, 
    0x2, 0xd4, 0xd5, 0x7, 0x20, 0x2, 0x2, 0xd5, 0xd6, 0x7, 0x21, 0x2, 0x2, 
    0xd6, 0xd7, 0x5, 0xc, 0x7, 0x2, 0xd7, 0xd8, 0x7, 0x22, 0x2, 0x2, 0xd8, 
    0x110, 0x3, 0x2, 0x2, 0x2, 0xd9, 0xda, 0x7, 0xf, 0x2, 0x2, 0xda, 0xdc, 
    0x7, 0x1f, 0x2, 0x2, 0xdb, 0xdd, 0x5, 0x10, 0x9, 0x2, 0xdc, 0xdb, 0x3, 
    0x2, 0x2, 0x2, 0xdc, 0xdd, 0x3, 0x2, 0x2, 0x2, 0xdd, 0xde, 0x3, 0x2, 
    0x2, 0x2, 0xde, 0xe0, 0x7, 0x7, 0x2, 0x2, 0xdf, 0xe1, 0x5, 0x14, 0xb, 
    0x2, 0xe0, 0xdf, 0x3, 0x2, 0x2, 0x2, 0xe0, 0xe1, 0x3, 0x2, 0x2, 0x2, 
    0xe1, 0xe2, 0x3, 0x2, 0x2, 0x2, 0xe2, 0xeb, 0x7, 0x7, 0x2, 0x2, 0xe3, 
    0xe8, 0x5, 0x12, 0xa, 0x2, 0xe4, 0xe5, 0x7, 0x6, 0x2, 0x2, 0xe5, 0xe7, 
    0x5, 0x12, 0xa, 0x2, 0xe6, 0xe4, 0x3, 0x2, 0x2, 0x2, 0xe7, 0xea, 0x3, 
    0x2, 0x2, 0x2, 0xe8, 0xe6, 0x3, 0x2, 0x2, 0x2, 0xe8, 0xe9, 0x3, 0x2, 
    0x2, 0x2, 0xe9, 0xec, 0x3, 0x2, 0x2, 0x2, 0xea, 0xe8, 0x3, 0x2, 0x2, 
    0x2, 0xeb, 0xe3, 0x3, 0x2, 0x2, 0x2, 0xeb, 0xec, 0x3, 0x2, 0x2, 0x2, 
    0xec, 0xed, 0x3, 0x2, 0x2, 0x2, 0xed, 0xee, 0x7, 0x20, 0x2, 0x2, 0xee, 
    0xef, 0x7, 0x21, 0x2, 0x2, 0xef, 0xf0, 0x5, 0xc, 0x7, 0x2, 0xf0, 0xf1, 
    0x7, 0x22, 0x2, 0x2, 0xf1, 0x110, 0x3, 0x2, 0x2, 0x2, 0xf2, 0xf3, 0x7, 
    0x21, 0x2, 0x2, 0xf3, 0xf4, 0x5, 0xc, 0x7, 0x2, 0xf4, 0xf5, 0x7, 0x22, 
    0x2, 0x2, 0xf5, 0x110, 0x3, 0x2, 0x2, 0x2, 0xf6, 0xf7, 0x7, 0x26, 0x2, 
    0x2, 0xf7, 0x100, 0x7, 0x1f, 0x2, 0x2, 0xf8, 0xfd, 0x7, 0x26, 0x2, 0x2, 
    0xf9, 0xfa, 0x7, 0x6, 0x2, 0x2, 0xfa, 0xfc, 0x7, 0x26, 0x2, 0x2, 0xfb, 
    0xf9, 0x3, 0x2, 0x2, 0x2, 0xfc, 0xff, 0x3, 0x2, 0x2, 0x2, 0xfd, 0xfb, 
    0x3, 0x2, 0x2, 0x2, 0xfd, 0xfe, 0x3, 0x2, 0x2, 0x2, 0xfe, 0x101, 0x3, 
    0x2, 0x2, 0x2, 0xff, 0xfd, 0x3, 0x2, 0x2, 0x2, 0x100, 0xf8, 0x3, 0x2, 
    0x2, 0x2, 0x100, 0x101, 0x3, 0x2, 0x2, 0x2, 0x101, 0x102, 0x3, 0x2, 
    0x2, 0x2, 0x102, 0x103, 0x7, 0x20, 0x2, 0x2, 0x103, 0x110, 0x7, 0x7, 
    0x2, 0x2, 0x104, 0x105, 0x7, 0x10, 0x2, 0x2, 0x105, 0x106, 0x7, 0x1f, 
    0x2, 0x2, 0x106, 0x107, 0x7, 0x26, 0x2, 0x2, 0x107, 0x108, 0x7, 0x20, 
    0x2, 0x2, 0x108, 0x110, 0x7, 0x7, 0x2, 0x2, 0x109, 0x10a, 0x7, 0x23, 
    0x2, 0x2, 0x10a, 0x110, 0x7, 0x7, 0x2, 0x2, 0x10b, 0x10c, 0x7, 0x23, 
    0x2, 0x2, 0x10c, 0x10d, 0x5, 0x14, 0xb, 0x2, 0x10d, 0x10e, 0x7, 0x7, 
    0x2, 0x2, 0x10e, 0x110, 0x3, 0x2, 0x2, 0x2, 0x10f, 0x82, 0x3, 0x2, 0x2, 
    0x2, 0x10f, 0x8c, 0x3, 0x2, 0x2, 0x2, 0x10f, 0x96, 0x3, 0x2, 0x2, 0x2, 
    0x10f, 0x9d, 0x3, 0x2, 0x2, 0x2, 0x10f, 0xa4, 0x3, 0x2, 0x2, 0x2, 0x10f, 
    0xaa, 0x3, 0x2, 0x2, 0x2, 0x10f, 0xb0, 0x3, 0x2, 0x2, 0x2, 0x10f, 0xb5, 
    0x3, 0x2, 0x2, 0x2, 0x10f, 0xbd, 0x3, 0x2, 0x2, 0x2, 0x10f, 0xc5, 0x3, 
    0x2, 0x2, 0x2, 0x10f, 0xd1, 0x3, 0x2, 0x2, 0x2, 0x10f, 0xd9, 0x3, 0x2, 
    0x2, 0x2, 0x10f, 0xf2, 0x3, 0x2, 0x2, 0x2, 0x10f, 0xf6, 0x3, 0x2, 0x2, 
    0x2, 0x10f, 0x104, 0x3, 0x2, 0x2, 0x2, 0x10f, 0x109, 0x3, 0x2, 0x2, 
    0x2, 0x10f, 0x10b, 0x3, 0x2, 0x2, 0x2, 0x110, 0xf, 0x3, 0x2, 0x2, 0x2, 
    0x111, 0x112, 0x7, 0x3, 0x2, 0x2, 0x112, 0x117, 0x7, 0x26, 0x2, 0x2, 
    0x113, 0x114, 0x7, 0x6, 0x2, 0x2, 0x114, 0x116, 0x7, 0x26, 0x2, 0x2, 
    0x115, 0x113, 0x3, 0x2, 0x2, 0x2, 0x116, 0x119, 0x3, 0x2, 0x2, 0x2, 
    0x117, 0x115, 0x3, 0x2, 0x2, 0x2, 0x117, 0x118, 0x3, 0x2, 0x2, 0x2, 
    0x118, 0x142, 0x3, 0x2, 0x2, 0x2, 0x119, 0x117, 0x3, 0x2, 0x2, 0x2, 
    0x11a, 0x11b, 0x7, 0x8, 0x2, 0x2, 0x11b, 0x120, 0x7, 0x26, 0x2, 0x2, 
    0x11c, 0x11d, 0x7, 0x6, 0x2, 0x2, 0x11d, 0x11f, 0x7, 0x26, 0x2, 0x2, 
    0x11e, 0x11c, 0x3, 0x2, 0x2, 0x2, 0x11f, 0x122, 0x3, 0x2, 0x2, 0x2, 
    0x120, 0x11e, 0x3, 0x2, 0x2, 0x2, 0x120, 0x121, 0x3, 0x2, 0x2, 0x2, 
    0x121, 0x142, 0x3, 0x2, 0x2, 0x2, 0x122, 0x120, 0x3, 0x2, 0x2, 0x2, 
    0x123, 0x124, 0x7, 0x3, 0x2, 0x2, 0x124, 0x125, 0x7, 0x26, 0x2, 0x2, 
    0x125, 0x126, 0x7, 0x9, 0x2, 0x2, 0x126, 0x127, 0x5, 0x14, 0xb, 0x2, 
    0x127, 0x128, 0x7, 0xa, 0x2, 0x2, 0x128, 0x142, 0x3, 0x2, 0x2, 0x2, 
    0x129, 0x12a, 0x7, 0x8, 0x2, 0x2, 0x12a, 0x12b, 0x7, 0x26, 0x2, 0x2, 
    0x12b, 0x12c, 0x7, 0x9, 0x2, 0x2, 0x12c, 0x12d, 0x5, 0x14, 0xb, 0x2, 
    0x12d, 0x12e, 0x7, 0xa, 0x2, 0x2, 0x12e, 0x142, 0x3, 0x2, 0x2, 0x2, 
    0x12f, 0x130, 0x7, 0x3, 0x2, 0x2, 0x130, 0x131, 0x7, 0x26, 0x2, 0x2, 
    0x131, 0x132, 0x7, 0xb, 0x2, 0x2, 0x132, 0x142, 0x5, 0x14, 0xb, 0x2, 
    0x133, 0x134, 0x7, 0x8, 0x2, 0x2, 0x134, 0x135, 0x7, 0x26, 0x2, 0x2, 
    0x135, 0x136, 0x7, 0xb, 0x2, 0x2, 0x136, 0x142, 0x5, 0x14, 0xb, 0x2, 
    0x137, 0x138, 0x7, 0x26, 0x2, 0x2, 0x138, 0x139, 0x7, 0xb, 0x2, 0x2, 
    0x139, 0x142, 0x5, 0x14, 0xb, 0x2, 0x13a, 0x13b, 0x7, 0x26, 0x2, 0x2, 
    0x13b, 0x13c, 0x7, 0x9, 0x2, 0x2, 0x13c, 0x13d, 0x5, 0x14, 0xb, 0x2, 
    0x13d, 0x13e, 0x7, 0xa, 0x2, 0x2, 0x13e, 0x13f, 0x7, 0xb, 0x2, 0x2, 
    0x13f, 0x140, 0x5, 0x14, 0xb, 0x2, 0x140, 0x142, 0x3, 0x2, 0x2, 0x2, 
    0x141, 0x111, 0x3, 0x2, 0x2, 0x2, 0x141, 0x11a, 0x3, 0x2, 0x2, 0x2, 
    0x141, 0x123, 0x3, 0x2, 0x2, 0x2, 0x141, 0x129, 0x3, 0x2, 0x2, 0x2, 
    0x141, 0x12f, 0x3, 0x2, 0x2, 0x2, 0x141, 0x133, 0x3, 0x2, 0x2, 0x2, 
    0x141, 0x137, 0x3, 0x2, 0x2, 0x2, 0x141, 0x13a, 0x3, 0x2, 0x2, 0x2, 
    0x142, 0x11, 0x3, 0x2, 0x2, 0x2, 0x143, 0x144, 0x7, 0x26, 0x2, 0x2, 
    0x144, 0x145, 0x7, 0xb, 0x2, 0x2, 0x145, 0x14e, 0x5, 0x14, 0xb, 0x2, 
    0x146, 0x147, 0x7, 0x26, 0x2, 0x2, 0x147, 0x148, 0x7, 0x9, 0x2, 0x2, 
    0x148, 0x149, 0x5, 0x14, 0xb, 0x2, 0x149, 0x14a, 0x7, 0xa, 0x2, 0x2, 
    0x14a, 0x14b, 0x7, 0xb, 0x2, 0x2, 0x14b, 0x14c, 0x5, 0x14, 0xb, 0x2, 
    0x14c, 0x14e, 0x3, 0x2, 0x2, 0x2, 0x14d, 0x143, 0x3, 0x2, 0x2, 0x2, 
    0x14d, 0x146, 0x3, 0x2, 0x2, 0x2, 0x14e, 0x13, 0x3, 0x2, 0x2, 0x2, 0x14f, 
    0x150, 0x8, 0xb, 0x1, 0x2, 0x150, 0x151, 0x7, 0x1f, 0x2, 0x2, 0x151, 
    0x152, 0x5, 0x14, 0xb, 0x2, 0x152, 0x153, 0x7, 0x20, 0x2, 0x2, 0x153, 
    0x171, 0x3, 0x2, 0x2, 0x2, 0x154, 0x155, 0x7, 0x11, 0x2, 0x2, 0x155, 
    0x171, 0x5, 0x14, 0xb, 0x16, 0x156, 0x157, 0x7, 0x14, 0x2, 0x2, 0x157, 
    0x171, 0x5, 0x14, 0xb, 0x12, 0x158, 0x159, 0x7, 0x26, 0x2, 0x2, 0x159, 
    0x162, 0x7, 0x1f, 0x2, 0x2, 0x15a, 0x15f, 0x7, 0x26, 0x2, 0x2, 0x15b, 
    0x15c, 0x7, 0x6, 0x2, 0x2, 0x15c, 0x15e, 0x7, 0x26, 0x2, 0x2, 0x15d, 
    0x15b, 0x3, 0x2, 0x2, 0x2, 0x15e, 0x161, 0x3, 0x2, 0x2, 0x2, 0x15f, 
    0x15d, 0x3, 0x2, 0x2, 0x2, 0x15f, 0x160, 0x3, 0x2, 0x2, 0x2, 0x160, 
    0x163, 0x3, 0x2, 0x2, 0x2, 0x161, 0x15f, 0x3, 0x2, 0x2, 0x2, 0x162, 
    0x15a, 0x3, 0x2, 0x2, 0x2, 0x162, 0x163, 0x3, 0x2, 0x2, 0x2, 0x163, 
    0x164, 0x3, 0x2, 0x2, 0x2, 0x164, 0x171, 0x7, 0x20, 0x2, 0x2, 0x165, 
    0x166, 0x7, 0x1e, 0x2, 0x2, 0x166, 0x167, 0x7, 0x1f, 0x2, 0x2, 0x167, 
    0x171, 0x7, 0x20, 0x2, 0x2, 0x168, 0x171, 0x7, 0x24, 0x2, 0x2, 0x169, 
    0x171, 0x7, 0x25, 0x2, 0x2, 0x16a, 0x171, 0x7, 0x26, 0x2, 0x2, 0x16b, 
    0x16c, 0x7, 0x26, 0x2, 0x2, 0x16c, 0x16d, 0x7, 0x9, 0x2, 0x2, 0x16d, 
    0x16e, 0x5, 0x14, 0xb, 0x2, 0x16e, 0x16f, 0x7, 0xa, 0x2, 0x2, 0x16f, 
    0x171, 0x3, 0x2, 0x2, 0x2, 0x170, 0x14f, 0x3, 0x2, 0x2, 0x2, 0x170, 
    0x154, 0x3, 0x2, 0x2, 0x2, 0x170, 0x156, 0x3, 0x2, 0x2, 0x2, 0x170, 
    0x158, 0x3, 0x2, 0x2, 0x2, 0x170, 0x165, 0x3, 0x2, 0x2, 0x2, 0x170, 
    0x168, 0x3, 0x2, 0x2, 0x2, 0x170, 0x169, 0x3, 0x2, 0x2, 0x2, 0x170, 
    0x16a, 0x3, 0x2, 0x2, 0x2, 0x170, 0x16b, 0x3, 0x2, 0x2, 0x2, 0x171, 
    0x198, 0x3, 0x2, 0x2, 0x2, 0x172, 0x173, 0xc, 0x15, 0x2, 0x2, 0x173, 
    0x174, 0x7, 0x12, 0x2, 0x2, 0x174, 0x197, 0x5, 0x14, 0xb, 0x16, 0x175, 
    0x176, 0xc, 0x14, 0x2, 0x2, 0x176, 0x177, 0x7, 0x11, 0x2, 0x2, 0x177, 
    0x197, 0x5, 0x14, 0xb, 0x15, 0x178, 0x179, 0xc, 0x13, 0x2, 0x2, 0x179, 
    0x17a, 0x7, 0x13, 0x2, 0x2, 0x17a, 0x197, 0x5, 0x14, 0xb, 0x14, 0x17b, 
    0x17c, 0xc, 0x11, 0x2, 0x2, 0x17c, 0x17d, 0x7, 0x15, 0x2, 0x2, 0x17d, 
    0x197, 0x5, 0x14, 0xb, 0x12, 0x17e, 0x17f, 0xc, 0x10, 0x2, 0x2, 0x17f, 
    0x180, 0x7, 0x16, 0x2, 0x2, 0x180, 0x197, 0x5, 0x14, 0xb, 0x11, 0x181, 
    0x182, 0xc, 0xf, 0x2, 0x2, 0x182, 0x183, 0x7, 0x17, 0x2, 0x2, 0x183, 
    0x197, 0x5, 0x14, 0xb, 0x10, 0x184, 0x185, 0xc, 0xe, 0x2, 0x2, 0x185, 
    0x186, 0x7, 0x18, 0x2, 0x2, 0x186, 0x197, 0x5, 0x14, 0xb, 0xf, 0x187, 
    0x188, 0xc, 0xd, 0x2, 0x2, 0x188, 0x189, 0x7, 0x19, 0x2, 0x2, 0x189, 
    0x197, 0x5, 0x14, 0xb, 0xe, 0x18a, 0x18b, 0xc, 0xc, 0x2, 0x2, 0x18b, 
    0x18c, 0x7, 0x1a, 0x2, 0x2, 0x18c, 0x197, 0x5, 0x14, 0xb, 0xd, 0x18d, 
    0x18e, 0xc, 0xb, 0x2, 0x2, 0x18e, 0x18f, 0x7, 0x1b, 0x2, 0x2, 0x18f, 
    0x197, 0x5, 0x14, 0xb, 0xc, 0x190, 0x191, 0xc, 0xa, 0x2, 0x2, 0x191, 
    0x192, 0x7, 0x1c, 0x2, 0x2, 0x192, 0x197, 0x5, 0x14, 0xb, 0xb, 0x193, 
    0x194, 0xc, 0x9, 0x2, 0x2, 0x194, 0x195, 0x7, 0x1d, 0x2, 0x2, 0x195, 
    0x197, 0x5, 0x14, 0xb, 0xa, 0x196, 0x172, 0x3, 0x2, 0x2, 0x2, 0x196, 
    0x175, 0x3, 0x2, 0x2, 0x2, 0x196, 0x178, 0x3, 0x2, 0x2, 0x2, 0x196, 
    0x17b, 0x3, 0x2, 0x2, 0x2, 0x196, 0x17e, 0x3, 0x2, 0x2, 0x2, 0x196, 
    0x181, 0x3, 0x2, 0x2, 0x2, 0x196, 0x184, 0x3, 0x2, 0x2, 0x2, 0x196, 
    0x187, 0x3, 0x2, 0x2, 0x2, 0x196, 0x18a, 0x3, 0x2, 0x2, 0x2, 0x196, 
    0x18d, 0x3, 0x2, 0x2, 0x2, 0x196, 0x190, 0x3, 0x2, 0x2, 0x2, 0x196, 
    0x193, 0x3, 0x2, 0x2, 0x2, 0x197, 0x19a, 0x3, 0x2, 0x2, 0x2, 0x198, 
    0x196, 0x3, 0x2, 0x2, 0x2, 0x198, 0x199, 0x3, 0x2, 0x2, 0x2, 0x199, 
    0x15, 0x3, 0x2, 0x2, 0x2, 0x19a, 0x198, 0x3, 0x2, 0x2, 0x2, 0x20, 0x24, 
    0x32, 0x35, 0x44, 0x47, 0x57, 0x5a, 0x6c, 0x6f, 0x76, 0x7a, 0x7f, 0x88, 
    0x92, 0xdc, 0xe0, 0xe8, 0xeb, 0xfd, 0x100, 0x10f, 0x117, 0x120, 0x141, 
    0x14d, 0x15f, 0x162, 0x170, 0x196, 0x198, 
  };

  atn::ATNDeserializer deserializer;
  _atn = deserializer.deserialize(_serializedATN);

  size_t count = _atn.getNumberOfDecisions();
  _decisionToDFA.reserve(count);
  for (size_t i = 0; i < count; i++) { 
    _decisionToDFA.emplace_back(_atn.getDecisionState(i), i);
  }
}

ifccParser::Initializer ifccParser::_init;
