
// Generated from ifcc.g4 by ANTLR 4.7.2

#pragma once


#include "antlr4-runtime.h"




class  ifccParser : public antlr4::Parser {
public:
  enum {
    T__0 = 1, T__1 = 2, T__2 = 3, T__3 = 4, T__4 = 5, T__5 = 6, T__6 = 7, 
    T__7 = 8, T__8 = 9, T__9 = 10, T__10 = 11, T__11 = 12, T__12 = 13, T__13 = 14, 
    T__14 = 15, T__15 = 16, T__16 = 17, T__17 = 18, T__18 = 19, T__19 = 20, 
    T__20 = 21, T__21 = 22, T__22 = 23, T__23 = 24, T__24 = 25, T__25 = 26, 
    T__26 = 27, T__27 = 28, OPENPAR = 29, CLOSEPAR = 30, OPENBRACE = 31, 
    CLOSEBRACE = 32, RETURN = 33, CONST = 34, CONSTCHAR = 35, NAME = 36, 
    COMMENT1 = 37, COMMENT2 = 38, DIRECTIVE = 39, WS = 40
  };

  enum {
    RuleAxiom = 0, RuleProg = 1, RuleInitbloc = 2, RuleInitfun = 3, RuleType = 4, 
    RuleBloc = 5, RuleInstr = 6, RuleInitfor = 7, RuleLoopinstr = 8, RuleExpr = 9
  };

  ifccParser(antlr4::TokenStream *input);
  ~ifccParser();

  virtual std::string getGrammarFileName() const override;
  virtual const antlr4::atn::ATN& getATN() const override { return _atn; };
  virtual const std::vector<std::string>& getTokenNames() const override { return _tokenNames; }; // deprecated: use vocabulary instead.
  virtual const std::vector<std::string>& getRuleNames() const override;
  virtual antlr4::dfa::Vocabulary& getVocabulary() const override;


  class AxiomContext;
  class ProgContext;
  class InitblocContext;
  class InitfunContext;
  class TypeContext;
  class BlocContext;
  class InstrContext;
  class InitforContext;
  class LoopinstrContext;
  class ExprContext; 

  class  AxiomContext : public antlr4::ParserRuleContext {
  public:
    AxiomContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ProgContext *prog();

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  AxiomContext* axiom();

  class  ProgContext : public antlr4::ParserRuleContext {
  public:
    ProgContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    InitblocContext *initbloc();
    antlr4::tree::TerminalNode *OPENPAR();
    antlr4::tree::TerminalNode *CLOSEPAR();
    antlr4::tree::TerminalNode *OPENBRACE();
    BlocContext *bloc();
    antlr4::tree::TerminalNode *CLOSEBRACE();

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ProgContext* prog();

  class  InitblocContext : public antlr4::ParserRuleContext {
  public:
    InitblocContext(antlr4::ParserRuleContext *parent, size_t invokingState);
   
    InitblocContext() = default;
    void copyFrom(InitblocContext *context);
    using antlr4::ParserRuleContext::copyFrom;

    virtual size_t getRuleIndex() const override;

   
  };

  class  BlocinitContext : public InitblocContext {
  public:
    BlocinitContext(InitblocContext *ctx);

    std::vector<InitfunContext *> initfun();
    InitfunContext* initfun(size_t i);
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  InitblocContext* initbloc();

  class  InitfunContext : public antlr4::ParserRuleContext {
  public:
    InitfunContext(antlr4::ParserRuleContext *parent, size_t invokingState);
   
    InitfunContext() = default;
    void copyFrom(InitfunContext *context);
    using antlr4::ParserRuleContext::copyFrom;

    virtual size_t getRuleIndex() const override;

   
  };

  class  DeclprocContext : public InitfunContext {
  public:
    DeclprocContext(InitfunContext *ctx);

    std::vector<antlr4::tree::TerminalNode *> NAME();
    antlr4::tree::TerminalNode* NAME(size_t i);
    antlr4::tree::TerminalNode *OPENPAR();
    antlr4::tree::TerminalNode *CLOSEPAR();
    std::vector<TypeContext *> type();
    TypeContext* type(size_t i);
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  DefprocContext : public InitfunContext {
  public:
    DefprocContext(InitfunContext *ctx);

    std::vector<antlr4::tree::TerminalNode *> NAME();
    antlr4::tree::TerminalNode* NAME(size_t i);
    antlr4::tree::TerminalNode *OPENPAR();
    antlr4::tree::TerminalNode *CLOSEPAR();
    antlr4::tree::TerminalNode *OPENBRACE();
    BlocContext *bloc();
    antlr4::tree::TerminalNode *CLOSEBRACE();
    std::vector<TypeContext *> type();
    TypeContext* type(size_t i);
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  DeffunContext : public InitfunContext {
  public:
    DeffunContext(InitfunContext *ctx);

    std::vector<TypeContext *> type();
    TypeContext* type(size_t i);
    std::vector<antlr4::tree::TerminalNode *> NAME();
    antlr4::tree::TerminalNode* NAME(size_t i);
    antlr4::tree::TerminalNode *OPENPAR();
    antlr4::tree::TerminalNode *CLOSEPAR();
    antlr4::tree::TerminalNode *OPENBRACE();
    BlocContext *bloc();
    antlr4::tree::TerminalNode *CLOSEBRACE();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  DeclfunContext : public InitfunContext {
  public:
    DeclfunContext(InitfunContext *ctx);

    std::vector<TypeContext *> type();
    TypeContext* type(size_t i);
    std::vector<antlr4::tree::TerminalNode *> NAME();
    antlr4::tree::TerminalNode* NAME(size_t i);
    antlr4::tree::TerminalNode *OPENPAR();
    antlr4::tree::TerminalNode *CLOSEPAR();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  InitfunContext* initfun();

  class  TypeContext : public antlr4::ParserRuleContext {
  public:
    TypeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
   
    TypeContext() = default;
    void copyFrom(TypeContext *context);
    using antlr4::ParserRuleContext::copyFrom;

    virtual size_t getRuleIndex() const override;

   
  };

  class  CharContext : public TypeContext {
  public:
    CharContext(TypeContext *ctx);

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  IntContext : public TypeContext {
  public:
    IntContext(TypeContext *ctx);

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  TypeContext* type();

  class  BlocContext : public antlr4::ParserRuleContext {
  public:
    BlocContext(antlr4::ParserRuleContext *parent, size_t invokingState);
   
    BlocContext() = default;
    void copyFrom(BlocContext *context);
    using antlr4::ParserRuleContext::copyFrom;

    virtual size_t getRuleIndex() const override;

   
  };

  class  BlocinstrContext : public BlocContext {
  public:
    BlocinstrContext(BlocContext *ctx);

    std::vector<InstrContext *> instr();
    InstrContext* instr(size_t i);
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  BlocContext* bloc();

  class  InstrContext : public antlr4::ParserRuleContext {
  public:
    InstrContext(antlr4::ParserRuleContext *parent, size_t invokingState);
   
    InstrContext() = default;
    void copyFrom(InstrContext *context);
    using antlr4::ParserRuleContext::copyFrom;

    virtual size_t getRuleIndex() const override;

   
  };

  class  AffexprContext : public InstrContext {
  public:
    AffexprContext(InstrContext *ctx);

    antlr4::tree::TerminalNode *NAME();
    ExprContext *expr();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  IfelseblocContext : public InstrContext {
  public:
    IfelseblocContext(InstrContext *ctx);

    antlr4::tree::TerminalNode *OPENPAR();
    ExprContext *expr();
    antlr4::tree::TerminalNode *CLOSEPAR();
    std::vector<antlr4::tree::TerminalNode *> OPENBRACE();
    antlr4::tree::TerminalNode* OPENBRACE(size_t i);
    std::vector<BlocContext *> bloc();
    BlocContext* bloc(size_t i);
    std::vector<antlr4::tree::TerminalNode *> CLOSEBRACE();
    antlr4::tree::TerminalNode* CLOSEBRACE(size_t i);
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  IfblocContext : public InstrContext {
  public:
    IfblocContext(InstrContext *ctx);

    antlr4::tree::TerminalNode *OPENPAR();
    ExprContext *expr();
    antlr4::tree::TerminalNode *CLOSEPAR();
    antlr4::tree::TerminalNode *OPENBRACE();
    BlocContext *bloc();
    antlr4::tree::TerminalNode *CLOSEBRACE();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  DeclinttabContext : public InstrContext {
  public:
    DeclinttabContext(InstrContext *ctx);

    antlr4::tree::TerminalNode *NAME();
    ExprContext *expr();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  DeclchartabContext : public InstrContext {
  public:
    DeclchartabContext(InstrContext *ctx);

    antlr4::tree::TerminalNode *NAME();
    ExprContext *expr();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  AfftabContext : public InstrContext {
  public:
    AfftabContext(InstrContext *ctx);

    antlr4::tree::TerminalNode *NAME();
    std::vector<ExprContext *> expr();
    ExprContext* expr(size_t i);
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  DefintContext : public InstrContext {
  public:
    DefintContext(InstrContext *ctx);

    antlr4::tree::TerminalNode *NAME();
    ExprContext *expr();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  DeclintContext : public InstrContext {
  public:
    DeclintContext(InstrContext *ctx);

    std::vector<antlr4::tree::TerminalNode *> NAME();
    antlr4::tree::TerminalNode* NAME(size_t i);
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  InstrblocContext : public InstrContext {
  public:
    InstrblocContext(InstrContext *ctx);

    antlr4::tree::TerminalNode *OPENBRACE();
    BlocContext *bloc();
    antlr4::tree::TerminalNode *CLOSEBRACE();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  DefcharContext : public InstrContext {
  public:
    DefcharContext(InstrContext *ctx);

    antlr4::tree::TerminalNode *NAME();
    ExprContext *expr();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  WhileblocContext : public InstrContext {
  public:
    WhileblocContext(InstrContext *ctx);

    antlr4::tree::TerminalNode *OPENPAR();
    ExprContext *expr();
    antlr4::tree::TerminalNode *CLOSEPAR();
    antlr4::tree::TerminalNode *OPENBRACE();
    BlocContext *bloc();
    antlr4::tree::TerminalNode *CLOSEBRACE();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  CallprocContext : public InstrContext {
  public:
    CallprocContext(InstrContext *ctx);

    std::vector<antlr4::tree::TerminalNode *> NAME();
    antlr4::tree::TerminalNode* NAME(size_t i);
    antlr4::tree::TerminalNode *OPENPAR();
    antlr4::tree::TerminalNode *CLOSEPAR();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  PutcharContext : public InstrContext {
  public:
    PutcharContext(InstrContext *ctx);

    antlr4::tree::TerminalNode *OPENPAR();
    antlr4::tree::TerminalNode *NAME();
    antlr4::tree::TerminalNode *CLOSEPAR();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  DeclcharContext : public InstrContext {
  public:
    DeclcharContext(InstrContext *ctx);

    std::vector<antlr4::tree::TerminalNode *> NAME();
    antlr4::tree::TerminalNode* NAME(size_t i);
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  ForblocContext : public InstrContext {
  public:
    ForblocContext(InstrContext *ctx);

    antlr4::tree::TerminalNode *OPENPAR();
    antlr4::tree::TerminalNode *CLOSEPAR();
    antlr4::tree::TerminalNode *OPENBRACE();
    BlocContext *bloc();
    antlr4::tree::TerminalNode *CLOSEBRACE();
    InitforContext *initfor();
    ExprContext *expr();
    std::vector<LoopinstrContext *> loopinstr();
    LoopinstrContext* loopinstr(size_t i);
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  ReturnContext : public InstrContext {
  public:
    ReturnContext(InstrContext *ctx);

    antlr4::tree::TerminalNode *RETURN();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  ReturnexprContext : public InstrContext {
  public:
    ReturnexprContext(InstrContext *ctx);

    antlr4::tree::TerminalNode *RETURN();
    ExprContext *expr();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  InstrContext* instr();

  class  InitforContext : public antlr4::ParserRuleContext {
  public:
    InitforContext(antlr4::ParserRuleContext *parent, size_t invokingState);
   
    InitforContext() = default;
    void copyFrom(InitforContext *context);
    using antlr4::ParserRuleContext::copyFrom;

    virtual size_t getRuleIndex() const override;

   
  };

  class  FordeclinttabContext : public InitforContext {
  public:
    FordeclinttabContext(InitforContext *ctx);

    antlr4::tree::TerminalNode *NAME();
    ExprContext *expr();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  FordeclchartabContext : public InitforContext {
  public:
    FordeclchartabContext(InitforContext *ctx);

    antlr4::tree::TerminalNode *NAME();
    ExprContext *expr();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  ForaffexprContext : public InitforContext {
  public:
    ForaffexprContext(InitforContext *ctx);

    antlr4::tree::TerminalNode *NAME();
    ExprContext *expr();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  FordeclcharContext : public InitforContext {
  public:
    FordeclcharContext(InitforContext *ctx);

    std::vector<antlr4::tree::TerminalNode *> NAME();
    antlr4::tree::TerminalNode* NAME(size_t i);
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  FordefintContext : public InitforContext {
  public:
    FordefintContext(InitforContext *ctx);

    antlr4::tree::TerminalNode *NAME();
    ExprContext *expr();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  FordefcharContext : public InitforContext {
  public:
    FordefcharContext(InitforContext *ctx);

    antlr4::tree::TerminalNode *NAME();
    ExprContext *expr();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  ForafftabContext : public InitforContext {
  public:
    ForafftabContext(InitforContext *ctx);

    antlr4::tree::TerminalNode *NAME();
    std::vector<ExprContext *> expr();
    ExprContext* expr(size_t i);
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  FordeclintContext : public InitforContext {
  public:
    FordeclintContext(InitforContext *ctx);

    std::vector<antlr4::tree::TerminalNode *> NAME();
    antlr4::tree::TerminalNode* NAME(size_t i);
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  InitforContext* initfor();

  class  LoopinstrContext : public antlr4::ParserRuleContext {
  public:
    LoopinstrContext(antlr4::ParserRuleContext *parent, size_t invokingState);
   
    LoopinstrContext() = default;
    void copyFrom(LoopinstrContext *context);
    using antlr4::ParserRuleContext::copyFrom;

    virtual size_t getRuleIndex() const override;

   
  };

  class  LoopaffContext : public LoopinstrContext {
  public:
    LoopaffContext(LoopinstrContext *ctx);

    antlr4::tree::TerminalNode *NAME();
    ExprContext *expr();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  LoopafftabContext : public LoopinstrContext {
  public:
    LoopafftabContext(LoopinstrContext *ctx);

    antlr4::tree::TerminalNode *NAME();
    std::vector<ExprContext *> expr();
    ExprContext* expr(size_t i);
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  LoopinstrContext* loopinstr();

  class  ExprContext : public antlr4::ParserRuleContext {
  public:
    ExprContext(antlr4::ParserRuleContext *parent, size_t invokingState);
   
    ExprContext() = default;
    void copyFrom(ExprContext *context);
    using antlr4::ParserRuleContext::copyFrom;

    virtual size_t getRuleIndex() const override;

   
  };

  class  ParContext : public ExprContext {
  public:
    ParContext(ExprContext *ctx);

    antlr4::tree::TerminalNode *OPENPAR();
    ExprContext *expr();
    antlr4::tree::TerminalNode *CLOSEPAR();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  GetcharContext : public ExprContext {
  public:
    GetcharContext(ExprContext *ctx);

    antlr4::tree::TerminalNode *OPENPAR();
    antlr4::tree::TerminalNode *CLOSEPAR();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  AddContext : public ExprContext {
  public:
    AddContext(ExprContext *ctx);

    std::vector<ExprContext *> expr();
    ExprContext* expr(size_t i);
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  MinusContext : public ExprContext {
  public:
    MinusContext(ExprContext *ctx);

    ExprContext *expr();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  SubContext : public ExprContext {
  public:
    SubContext(ExprContext *ctx);

    std::vector<ExprContext *> expr();
    ExprContext* expr(size_t i);
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  GeatContext : public ExprContext {
  public:
    GeatContext(ExprContext *ctx);

    std::vector<ExprContext *> expr();
    ExprContext* expr(size_t i);
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  MultContext : public ExprContext {
  public:
    MultContext(ExprContext *ctx);

    std::vector<ExprContext *> expr();
    ExprContext* expr(size_t i);
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  OrContext : public ExprContext {
  public:
    OrContext(ExprContext *ctx);

    std::vector<ExprContext *> expr();
    ExprContext* expr(size_t i);
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  ConstContext : public ExprContext {
  public:
    ConstContext(ExprContext *ctx);

    antlr4::tree::TerminalNode *CONST();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  TabaccessContext : public ExprContext {
  public:
    TabaccessContext(ExprContext *ctx);

    antlr4::tree::TerminalNode *NAME();
    ExprContext *expr();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  ConstcharContext : public ExprContext {
  public:
    ConstcharContext(ExprContext *ctx);

    antlr4::tree::TerminalNode *CONSTCHAR();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  EqContext : public ExprContext {
  public:
    EqContext(ExprContext *ctx);

    std::vector<ExprContext *> expr();
    ExprContext* expr(size_t i);
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  NotContext : public ExprContext {
  public:
    NotContext(ExprContext *ctx);

    ExprContext *expr();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  CallfunContext : public ExprContext {
  public:
    CallfunContext(ExprContext *ctx);

    std::vector<antlr4::tree::TerminalNode *> NAME();
    antlr4::tree::TerminalNode* NAME(size_t i);
    antlr4::tree::TerminalNode *OPENPAR();
    antlr4::tree::TerminalNode *CLOSEPAR();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  GeqContext : public ExprContext {
  public:
    GeqContext(ExprContext *ctx);

    std::vector<ExprContext *> expr();
    ExprContext* expr(size_t i);
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  LowContext : public ExprContext {
  public:
    LowContext(ExprContext *ctx);

    std::vector<ExprContext *> expr();
    ExprContext* expr(size_t i);
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  AndContext : public ExprContext {
  public:
    AndContext(ExprContext *ctx);

    std::vector<ExprContext *> expr();
    ExprContext* expr(size_t i);
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  NameContext : public ExprContext {
  public:
    NameContext(ExprContext *ctx);

    antlr4::tree::TerminalNode *NAME();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  LeqContext : public ExprContext {
  public:
    LeqContext(ExprContext *ctx);

    std::vector<ExprContext *> expr();
    ExprContext* expr(size_t i);
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  XorContext : public ExprContext {
  public:
    XorContext(ExprContext *ctx);

    std::vector<ExprContext *> expr();
    ExprContext* expr(size_t i);
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  NeqContext : public ExprContext {
  public:
    NeqContext(ExprContext *ctx);

    std::vector<ExprContext *> expr();
    ExprContext* expr(size_t i);
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  ExprContext* expr();
  ExprContext* expr(int precedence);

  virtual bool sempred(antlr4::RuleContext *_localctx, size_t ruleIndex, size_t predicateIndex) override;
  bool exprSempred(ExprContext *_localctx, size_t predicateIndex);

private:
  static std::vector<antlr4::dfa::DFA> _decisionToDFA;
  static antlr4::atn::PredictionContextCache _sharedContextCache;
  static std::vector<std::string> _ruleNames;
  static std::vector<std::string> _tokenNames;

  static std::vector<std::string> _literalNames;
  static std::vector<std::string> _symbolicNames;
  static antlr4::dfa::Vocabulary _vocabulary;
  static antlr4::atn::ATN _atn;
  static std::vector<uint16_t> _serializedATN;


  struct Initializer {
    Initializer();
  };
  static Initializer _init;
};

