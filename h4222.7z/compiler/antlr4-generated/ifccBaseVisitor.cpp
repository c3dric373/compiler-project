
// Generated from ifcc.g4 by ANTLR 4.7.2


#include "ifccBaseVisitor.h"


