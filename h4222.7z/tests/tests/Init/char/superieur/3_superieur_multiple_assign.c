int main(){
    char a = 'a';
    char b = 'b';
	char c = 'e';
	char d = a>b;
	char e = c>d;
	char i = e +d;
    return i;
}

