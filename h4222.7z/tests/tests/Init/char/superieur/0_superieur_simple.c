int main(){
    char a = 'a';
    char b = 'b';
    char c = a>b;
    return c;
}

