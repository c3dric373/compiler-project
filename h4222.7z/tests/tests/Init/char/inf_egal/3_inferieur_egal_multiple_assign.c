int main(){
    char a = 'a';
    char b = 'b';
	char c = 'e';
	char d = a<=b;
	char e = d<=c;
	char i = e +d;
    return i;
}

