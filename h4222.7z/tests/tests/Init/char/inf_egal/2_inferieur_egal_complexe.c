int main(){
    char a = 'a';
    char b = 'b';
	char c = 'e';
    if ((a<=b) <= (c<=a){
       c = 'c';
    }
    return c;
}

