int main(){
    char a='a';
    char c='b';
    
    return a*c;
}
