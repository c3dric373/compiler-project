int main(){
    char a='a';
    char c='b';
    char b=a*c;
    return b;
}
