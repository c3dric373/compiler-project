int main(){
    char a = 8*5;
    return a;
}
