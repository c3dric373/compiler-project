int main(){
    char a = 8*5;
    int b = a+9;
    char c = b-3;
    return c;
}
