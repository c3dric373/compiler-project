int main(){
    char a = 8*5;
    int b = a+9; 
    char c = 'x';
    if(b>'b'){
	c = 98;
    }
    return c;
}
