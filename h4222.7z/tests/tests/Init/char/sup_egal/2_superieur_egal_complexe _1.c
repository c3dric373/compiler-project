int main(){
    char a = 'a';
    char b = 'b';
	char c = 'e';
    if ((a>=b) >= (b>=c){
       c = 'c';
    }
    return c;
}

