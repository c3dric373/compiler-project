int main(){
    char a = 'a';
    char b = 'b';
	char c = 'e';
    if (a<b){
       c = 'c';
    }
    return c;
}

