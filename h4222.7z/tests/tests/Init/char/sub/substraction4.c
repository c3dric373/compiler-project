int main(){
    char a = 'd';
    char c='e';
    return a-c;
}
