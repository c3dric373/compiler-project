int main(){
    char a = 5-6;
    return a;
}
