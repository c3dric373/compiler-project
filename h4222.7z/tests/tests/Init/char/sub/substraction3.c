int main(){
    char a = 1-6-6;
    return a;
}
