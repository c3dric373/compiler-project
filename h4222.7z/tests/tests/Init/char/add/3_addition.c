int main(){
    char a = 5+7+8;
    return a;
}
