int main(){
    char a = 155;
    char b =155;
    return a+b;
}
