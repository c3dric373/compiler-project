int main(){
    char a = 5+7;
    return a;
}
