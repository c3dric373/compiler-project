int main(){
    char a = -(3+4)*2;
    return a;
}
