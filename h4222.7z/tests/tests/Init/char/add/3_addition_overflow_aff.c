int main(){
    char a = 155;
    char b =155;
    char c=a+b;
    return c;
}
