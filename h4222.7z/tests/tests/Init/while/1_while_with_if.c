int main(){
    int a = 1;
    int b =0;
    while (a == 1){
        if(b==0){
            a = 2;
        }
    }
    return a;
}
