int main(){
    int a = 1;
    while (a < 5){
        a  = a +1;
    }
    return a;
}
