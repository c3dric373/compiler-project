int main(){
    int a = 10;
    while (a > 5){
        a  = a -1;
    }
    return a;
}
