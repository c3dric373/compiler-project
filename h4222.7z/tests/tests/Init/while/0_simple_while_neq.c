int main(){
    int a = 5;
    while (a != 1){
        a  = a - 1;
    }
    return a;
}
