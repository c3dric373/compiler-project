int main(){
    int a = 1;
    int b =0;
    int d =2;
    while (a == 1){
        if(b==0){
            a = 2;
        }
        while(b < 3){
            int c = 1;
            b = b +c;
            if(b == 2){
                d =3
            }else{
                d =1;
                int l = 33;
                a = l;
            }
        }
        d = b +d;
    }
    return l-d;
}
