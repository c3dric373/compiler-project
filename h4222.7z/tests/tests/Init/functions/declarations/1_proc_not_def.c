
void z(int a);

int main() {
    int a = 5;
    z(a);
    char d = 2;
    return d;
}