
int main() {
    int a =5;
    int b = z(a);
    char d = 2;
    return d;
}