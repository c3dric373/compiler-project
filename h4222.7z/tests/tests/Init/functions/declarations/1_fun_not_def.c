
int  z(int a);

int main() {
    int a = 5;
    int f = z(a);
    char d = 2;
    return d;
}