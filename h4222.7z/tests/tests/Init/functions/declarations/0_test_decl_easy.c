#include <stdio.h>
int v(int a);
int x  (int c);
void z();
int u(int a) {
    int x = v(a);
    return x -1;
}

int v(int valeur) {
    int a = 5;
    int b = 5;
    return 34;
}

int main() {
    int a = 8;
    int b;
    b = v(a);
    char d = 2;
    return d;
}