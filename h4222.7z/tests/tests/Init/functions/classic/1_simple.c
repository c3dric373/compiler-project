int f(int i){
    i=i+1;
    return i;
}



int main(){
    int a=1;
    int b = f(a);
    return  b;
}
