char f(int i, char c,int b,int e,int f,int h,int d,char tt){
    int carre=tt;
    return carre;
}

int main(){
    int a=1;
    char b='f';
    b=f(a,b,a,a,a,a,a,b);
    return  b;
}
