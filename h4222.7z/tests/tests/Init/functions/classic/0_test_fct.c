int test(int c,int b){
    int g = c + b;
    return g;

}
int main(){
    int a =20;
    int f = 4;
    int b = test(a,f);
    return b;
}
