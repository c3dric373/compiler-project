int f(){
	a=42;
	return a;	

}



int main(){
    return a ;
}
