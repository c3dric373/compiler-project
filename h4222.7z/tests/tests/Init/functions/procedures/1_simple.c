void f(int i){
    i=i+1;
}



int main(){
    int a=1;
    f(a);
    return  a;
}
