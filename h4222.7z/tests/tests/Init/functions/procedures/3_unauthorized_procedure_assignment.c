void f(int i){
    i=i+1;
    putchar('a')
}


int main(){
    int a=1;
    a = f(a);
    return  a;
}
