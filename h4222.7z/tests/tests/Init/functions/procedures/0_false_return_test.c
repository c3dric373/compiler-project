void f(){
	a=42;
	return a;	

}



int main(){
    f ();
    return  ;
}
