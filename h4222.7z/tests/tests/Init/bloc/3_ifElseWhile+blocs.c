int main() {
    int a = 3;
    int c = 0;
    while (a > 1) {
        int b= 2;
        b = a +1;
        a = a -1;
        c = b +2;
    }

    return c;
}