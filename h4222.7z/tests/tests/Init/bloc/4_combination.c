int main(){
    int a = 6 ;
    int b = 8 | a;
    int d =2;
    while (a != 1){
        if(b==0){
            a = 2;
        }
        while(b < 3){
            int c = 1;
            b = b +(c +1)*0;
            if(b == 2){
                d =3
            }else{
                d =1;
                int l = 33;
                a = l;
            }
            a = a-1;
            d = 6-a;
        }
        if(d ==2){
            a = 1;
        }else{
            while(b > 0){
                int f = 7;
                b = 0*f - 5;
            }
        }
    }
    return l-d;
}
