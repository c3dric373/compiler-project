 
int main(){
    char a[2];
    a[0]='a';
    a[1]=1;
    return a[0]+a[1];
}
 
