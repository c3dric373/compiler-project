 
int main(){
    char a[2];
    a[0]='a';
    a[1]='a';
    return a[0]+a[1];
}
 
