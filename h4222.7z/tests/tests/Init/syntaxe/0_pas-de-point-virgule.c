int main(){
    int b = 5
    return b;
}