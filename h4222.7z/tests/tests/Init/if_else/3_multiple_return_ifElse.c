int main() {
    int a = 5;
    int b, c;
    if (a == 5) {
       return a;
    }else{
	
	b=4;
	c=2;
	return b;
    }
    return c;
}
