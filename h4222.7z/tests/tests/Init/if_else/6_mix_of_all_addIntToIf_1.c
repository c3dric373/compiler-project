int main() {
    int a = 20;
    int b = 4;
    int c = 9;
    int d = c * b - a;
    int e = d * 4;
    int f = (b > e) | (d <= a);
    int g = (c < b) * (e > a) * a;
    int m = 125;
    if ((a < b) & (e > d) * (f > e) | (c > d) + 257) {
        m = (b == c) * (e & a) + a;
        int w = 78;
    }
    return m;
}
