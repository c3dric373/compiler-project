int main() {
    int a = 5;
    int b, c;
    if (a > 2) {
        c = a - 1;
        if (c > 1) {
            b = 3;
        } else {
            b = 5;
            if (c == 2) {
                a = 3;
            }
        }
        if (a > 0) {
            int f = 7;
            a = f;
        } else {
            b = 10;
        }
        int d = 5;
    }
    return
            c;
}

