int main() {
    int a = 5;
    int b, c;
if(a ==5){
    b = 2;
    if(b ==2){
        int f =7;
        if(f !=2){
            a =2
        }else{
            int g = 3;
            f = 2+6*g*0;
        }
    }else{
        int r  = 1;

    }if(a <0){
        c =10;
    }else{
        a =1 ;
        c = 10 -a + b ;
    }
}
    return  c;
}
