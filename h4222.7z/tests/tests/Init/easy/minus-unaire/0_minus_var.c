int main(){
    int a = 5*-42;
    int c = -a;
    return c+-a;
}