int main(){
    int a = 5*42;
    return -a;
}