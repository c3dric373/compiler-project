int main(){
    int a = -42;
    return a;
}