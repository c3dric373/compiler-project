int main(){
    int a = 6 & 6;
    return a;
}
