int main(){
    int a = 6 | 6;
    int b = 8 ^ a | 10;
    int c = 8 ^ a + 10;
    return a + b +c;
}
