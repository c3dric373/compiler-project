int main(){
    int a = 6 & 6;
    int b = 8 & a;
    return a + b;
}
