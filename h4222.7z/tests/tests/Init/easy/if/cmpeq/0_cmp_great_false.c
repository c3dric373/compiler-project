int main(){
    int a = 5;
    int  c =1;
    if(a==1){
        c =2;
    }
    return c;
}

