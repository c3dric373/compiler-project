int main(){
    int a = 5;
    int  b,c;
    if(a==5){
        c =2;
        if(c != 2) {
            b =3;
        }
        int d = 5;
    }
    return c;
}
