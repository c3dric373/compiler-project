int main() {
    int a = 5;
    int b, c, e;
    int result = 0;
    if (a >= 2) {
        c = 2;
        if (c > 1) {
            b = 3;
        }
        if (b <= 3) {
            int f = 2;
            if (f == 2) {
                e = f;
            }
            if (f != 2) {
                e = 0;
            }
        }
        int d = 5;
        if (e < d) {
            result = d;
        }
    }
    return result;
}
