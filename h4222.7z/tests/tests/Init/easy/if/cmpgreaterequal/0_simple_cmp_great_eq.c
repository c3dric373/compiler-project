int main(){
    int a = 5;
    int  b,c;
    if(a >= 3){
        c =2;
    }
    return c;
}

