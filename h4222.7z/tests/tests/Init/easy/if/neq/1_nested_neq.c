int main(){
    int a = 5;
    int  b,c;
    if(a != 2){
        c =2;
        if(c != 1) {
            b =3;
        }
        int d = 5;
    }
    return c;
}
