int main(){
    int a = 3;
    int  b,c;
    if(a!=5){
        c =2;
    }
    return c;
}

