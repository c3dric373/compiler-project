int main(){
    int a = 8*5*9;
    return a;
}
