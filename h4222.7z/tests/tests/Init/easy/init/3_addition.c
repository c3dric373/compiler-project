int main(){
    int a = 5+7+8;
    return a;
}