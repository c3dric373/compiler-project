int main(){
    int a = 1;
    int b = 2;
    int c = 4;
    int d = a<b;
    int e = d<c;
    int i = e +d;
    return i;
}