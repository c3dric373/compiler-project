int main(){
    int a = 5;
    return a;
}