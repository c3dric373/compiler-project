int main(){
    int a = 3+5-2+6-1;
    return a;
}