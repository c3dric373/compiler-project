int main(){
    int a = 3+5-2+90;
    return a;
}