int main(){
    int a = 1+55+3+10-5-32-31;
    int b = 2+a;
    int c= 3+a*b*5+5;
    return c;
}
