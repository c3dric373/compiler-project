int main(){
    int a = 7;
    int b = 8;
    int c = 6;
    int d = 2+a*c+b;
    return d;
}
