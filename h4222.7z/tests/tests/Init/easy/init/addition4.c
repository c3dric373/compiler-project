int main(){
    int a = 5+1+6+6;
    return a;
}