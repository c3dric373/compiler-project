int main(){
    int a = -(5+2-(38*2));
    return a;
}