int main(){
    int a = 8;
	int b = 5;
	int c = 2;
	int d = a*b*c;
    return d;
}
