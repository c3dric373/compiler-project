int main(){
    int a = (5*1+1*1)+(6*1+6*1+1*1);
    // mettre em place des registres pour stocker des resultats temporaire
    return a;
}
