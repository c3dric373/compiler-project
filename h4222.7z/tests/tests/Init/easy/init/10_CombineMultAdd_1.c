int main(){
    int a = 7*8+6*9;
    return a;
}
