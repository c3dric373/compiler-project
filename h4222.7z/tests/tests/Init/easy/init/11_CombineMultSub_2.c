int main(){
    int a = 7-8*2-9;
    return a;
}
