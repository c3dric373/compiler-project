int main(){
    int a=0;
    for( int i=0; i<10; ){
        a=a+1;
        i = i +1;
    }
    return a;
}
