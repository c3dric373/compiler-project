int main(){
    int a=0;
    int i =0;
    for( ;i<10; i=i+1){
        a=a+1;
    }
    return a;
}
