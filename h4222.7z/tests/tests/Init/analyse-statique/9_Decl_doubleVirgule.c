int main(){
    int a,b,,c,d,e,f,g,v;
    return 0;
}
