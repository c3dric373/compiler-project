int main(){
    int a=5;
    while(a<10){
	a=c;
	a=a+1;
    }
    return a;
}
