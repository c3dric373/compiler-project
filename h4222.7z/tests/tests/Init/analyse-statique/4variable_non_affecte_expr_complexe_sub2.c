int main(){
    int a = c-5-8;
    return a;
}