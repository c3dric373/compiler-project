int main(){
    int a=5;
    if(a>3){
	a=c;
    }
    return a;
}
