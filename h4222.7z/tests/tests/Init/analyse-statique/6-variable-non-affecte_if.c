int main(){
    if(a>3){}
    return a;
}
