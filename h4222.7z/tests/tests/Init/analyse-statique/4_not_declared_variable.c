int main() {
    int a = 5;
    int b, c;
    if (a == 5) {
       int d=3;
    }else{
       b=4;
    }
    return d;
}
