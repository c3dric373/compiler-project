int main(){
    int a = 5+c+6;
    return a;
}