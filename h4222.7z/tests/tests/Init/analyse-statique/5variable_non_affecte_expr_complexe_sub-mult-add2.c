int main(){
    int a = 8+5-2*5+c+6;
    return a;
}