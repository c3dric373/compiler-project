int main(){
    while(a>3){}
    return a;
}
