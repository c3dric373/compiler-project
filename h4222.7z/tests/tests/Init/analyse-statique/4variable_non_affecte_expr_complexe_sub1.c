int main(){
    int a = 8-c-5;
    return a;
}