int main(){
    int a = 8+5+c;
    return a;
}