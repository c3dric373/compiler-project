int main(){
    int a = 9;
    int b = 2;
	int c = 3;
    if ((a<=b) <= (b<=c){
       c = 9;
    }
    return c;
}

