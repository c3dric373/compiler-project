int main(){
    int a = 1;
    int b = 1;
	int c = 1;
    if ((a==b) == (c==a){
       c = 8;
    }
    return c;
}

