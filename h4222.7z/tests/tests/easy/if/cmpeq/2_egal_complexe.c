int main(){
    int a = 1;
    int b = 2;
	int c = 3;
    if ((a==b) == (c==a){
       c = 8;
    }
    return c;
}

