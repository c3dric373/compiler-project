int main(){
    int a = 2;
    int b = 4;
	int c = 7;
    if ((a>b) > (b>c){
       c = 8;
    }
    return c;
}

