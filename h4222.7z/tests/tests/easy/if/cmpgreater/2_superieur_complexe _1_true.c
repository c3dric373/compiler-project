int main(){
    int a = 5;
    int b = 4;
	int c = 7;
    if ((a>b) > (b>c){
       c = 8;
    }
    return c;
}

